/* v20 app: render cards / detail / filters / pagination from window.V20_DATA.
   Rules ported from v19-fix2:
   - Every <article> gets all attributes INSIDE its opening tag (never after a closing div).
   - Real photos are embedded directly in the HTML string for the 18 profiles that have one;
     the other 2 (th-04, th-10 — no retrievable public photo) keep a placeholder glyph,
     never a fabricated photo. photoSrc says where a photo came from: "post" (the model's
     own public post) or "profile" (the model's public Facebook profile picture).
   - Visible text never contains an internal id (th-xx): ids live only in data and in ?id= URLs.
   - Contact rule (v26, user-approved 2026-11-05 13:26, spec §8, audit contact-audit-v26.md):
     `contacts` in data.js holds ONLY items the model/shop published themselves in
     their public post or on their public channel, each with source_url. Those are
     rendered in full (Zalo as zalo.me link, phone as tel: link, email as mailto:,
     Facebook/TikTok/Shopee as external links) with the note "Các bên chủ động liên
     hệ trao đổi, thông tin là công khai." and the CHƯA XÁC NHẬN label + removal
     request. Anything not in `contacts` (no public source) is never rendered —
     no private phone/Zalo/email is ever shown, invented or guessed. */
(function(){
'use strict';
var D = window.V20_DATA || {models:[], articles:[], provinces:[], categories:[]};
var PH = window.V20_PHOTOS || {};
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]});}
function clean(s){return String(s||'').replace(/\s*·\s*$/,'').trim() || 'Chưa cập nhật';}
function photoHTML(m, cls){
  if(m.photoUrl) return '<img src="'+esc(m.photoUrl)+'" alt="'+(m.photoSrc==='profile' ? 'Ảnh đại diện công khai của ' : 'Ảnh thật từ bài gốc của ')+esc(m.name)+'" loading="lazy" decoding="async">';
  // v101: the rut gon 5 cot — mau khong anh hien tinh tim viec trong o anh
  // thay cho icon 👤 (chi khi goi voi cls='compact', tuc the danh sach;
  // the mini o trang chi tiet + anh lon o trang chi tiet giu 👤).
  // v118 (P2-3): BO hien tinh trong o anh — tinh da hien o dong 1 duoi anh
  // (modelLocationLine) nen hien ca 2 cho bi lap 2 lan tren cung 1 the.
  // The khong anh gio dung 👤 nhu the mini/trang chi tiet (nhat quan).
  if(cls === 'compact') return '<span class="ph-holder" aria-hidden="true">👤</span>';
  return '<span class="ph-holder" aria-hidden="true">👤</span>';
}
function photoNote(m){return m.photoUrl ? (m.photoSrc==='profile' ? 'Ảnh đại diện công khai' : 'Ảnh thật từ bài gốc') : (m.photoHas ? 'Có ảnh trong bài gốc' : 'Ảnh minh họa tạm — chưa phải ảnh thật');}
/* v28 — thẻ 5 giây (thiết kế 2026-11-05, design-2026-11-05-the-ho-so-5-giay.md):
   Mặt thẻ CHỈ render hàng có giá trị thật. Hàng nào là "Chưa cập nhật" hoặc
   rỗng thì không render — không hiện tiêu đề hàng kèm chữ chiếm chỗ. Lương
   "Thỏa thuận" không phải một hàng: nó thành 1 chip xám "Lương thỏa thuận"
   cạnh tag lĩnh vực. "Doanh thu cao nhất" rời khỏi mặt thẻ cho tới khi có
   hồ sơ có số thật (hiện tại 0/20, nên chưa thẻ nào hiện hàng này); khi mẫu
   tự đăng ký nhập được doanh thu đã kiểm chứng thì hàng tự xuất hiện lại,
   không cần sửa code. Không suy ra nhãn mới từ dữ liệu cũ (không chip
   "khung vàng", "còn trống 11.11"); không hiện lượt xem/bình luận (đang
   0/0). Trang chi tiết GIỮ NGUYÊN bảng đầy đủ 4 hàng kể cả "Chưa cập nhật"
   (initDetail không chạm tới đây) — chỉ dọn mặt thẻ, không giấu thông tin. */
function hasReal(v){ var s = String(v==null?'':v).trim(); return s !== '' && s !== 'Chưa cập nhật'; }
/* v99 (§1b/§1c dac ta the rut gon + sao len top): quy tac hien thi
   2 dong duoi anh cho ca 5 loai the. Cac ham *Line tra ve HTML AN TOAN
   (chu da esc, hoac link <a> "Chi tiet") — noi goi dung truc tiep,
   KHONG esc them. Diem chung: thieu dia diem thi dong 1 gan link nguon
   kem chu "Chi tiet" (khong ghi chung chung); fallback "Thoa thuan"
   chi cho dong 2 (luong shop, mat hang xuong). */
var CAT_LABELS = {'quan-ao':'Quần áo','nam':'Nam','nu':'Nữ','tre-em':'Trẻ em','giay-dep':'Giày dép','my-pham':'Mỹ phẩm','phu-kien':'Phụ kiện','tpcn':'TPCN','gia-dung':'Gia dụng & Đời sống','idol':'Idol / Streamer','cong-nghe':'Công nghệ','khac':'Khác','toan-bo-cua-hang':'Toàn bộ cửa hàng','sang-mat-bang':'Sang mặt bằng','hang-ton-kho':'Hàng tồn kho','do-dac-thiet-bi':'Đồ đạc, thiết bị'};
function catLabel(code){ var s = String(code==null?'':code).trim(); return CAT_LABELS[s] || s; }
function sourceDetailLink(url){ var u = String(url||'').trim(); if(!u) return 'Chi tiết'; return '<a class="card-line-link" href="'+esc(u)+'" target="_blank" rel="noopener">Chi tiết</a>'; }
// v99: tim tinh/thanh trong chuoi tu do (tieu de/meta lo) — khop ten dai
// nhat trong D.provinces; chi dung cho lo (khong co truong prov rieng).
// 'TP.HCM' la cach viet tat pho bien trong bai goc (khong co trong
// D.provinces) nen them alias hien dung nhu trong nguon.
function findProvinceInText(text){
  var t = String(text||''); if(!t) return '';
  var best = '';
  (D.provinces||[]).forEach(function(p){ if(p && t.indexOf(p) >= 0 && p.length > best.length) best = p; });
  if(!best && t.indexOf('TP.HCM') >= 0) best = 'TP.HCM';
  return best;
}
/* v111: ten tinh sau sap nhap (2025) — du lieu cu van dung ten cu
   (Binh Duong/Nam Dinh/Hai Duong/Bac Giang) va viet tat 'TP.HCM'; quy ve
   ten moi trong D.provinces khi loc/dem de dropdown khong con ten cu ma
   van khop du lieu cu. Vi du: 3 xuong 'Nam Dinh' (gom TBC) dem ve
   'Ninh Binh (3)'. */
var MERGED_PROV = {'TP.HCM':'TP. Hồ Chí Minh','Bình Dương':'TP. Hồ Chí Minh','Nam Định':'Ninh Bình','Hải Dương':'Hải Phòng','Bắc Giang':'Bắc Ninh',
/* v214 (14/11/2026 — F1 test full: 2 cach viet lech khong khop option tinh):
   'Thành phố Hồ Chí Minh' (3 tin agency) ve 'TP. Hồ Chí Minh'; 'Online'
   (5 lop live + 4 su kien + 1 lop makeup) ve 'Toàn quốc / Live online'
   (ten chuan trong D.provinces). Ca dem (newObjProvCount) va loc
   (newObjMatches) deu di qua normProv nen 1 cho nay sua ca 2. */
'Thành phố Hồ Chí Minh':'TP. Hồ Chí Minh','Online':'Toàn quốc / Live online',
/* v223 (S2-5, 14/11/2026): 'Toàn quốc' (12 shop, ghi thô trong data.js) ve
   'Toàn quốc / Live online' — truoc day 12 shop nay khong khop option tinh nao
   nen bo loc tinh Shop cong chi 258/270. */
'Toàn quốc':'Toàn quốc / Live online'};
function normProv(p){ var s = String(p == null ? '' : p).trim(); return MERGED_PROV[s] || s; }
/* v166 (N8, 12/11/2026): chuẩn hóa tỉnh RIÊNG cho Kiot — chỉ gộp bí
   danh 'TP.HCM' → 'TP. Hồ Chí Minh', KHÔNG áp bản đồ sáp nhập
   MERGED_PROV. Gốc lỗi: MERGED_PROV gộp 'Bình Dương' → 'TP. Hồ Chí
   Minh' (sáp nhập 2025) nên lọc TP.HCM khớp cả 36 kiot (17 'TP.HCM'
   + 17 'TP. Hồ Chí Minh' + 2 Bình Dương, gồm LEILA Thủ Dầu Một),
   trong khi số đếm ở dropdown (initOptionCounts, so sánh prov thô)
   chỉ ghi 17 — đếm và lọc lệch nhau. Kiot là tin rao theo địa điểm
   thật (Thủ Dầu Một, Bình Dương là thành phố riêng trong mắt người
   dùng) nên giữ tỉnh gốc; Lô/Xưởng vẫn dùng normProv (bản đồ sáp
   nhập) như cũ — đổi toàn site cần quyết riêng vì 12 xưởng đang gộp
   Bình Dương vào TP.HCM. */
function normProvKiot(p){ var s = String(p == null ? '' : p).trim(); return s === 'TP.HCM' ? 'TP. Hồ Chí Minh' : s; }
/* v124: tin user LUÔN có trường prov (đặc tả §6.2) nên ưu tiên prov riêng
   trước khi quét tỉnh trong tiêu đề/meta như lô thu thập cũ. */
function lotProvOf(l){ if(l && hasReal(l.prov)) return normProv(l.prov); return normProv(findProvinceInText(((l && l.title) ? l.title + ' ' : '') + ((l && l.meta) || ''))); }
function modelFields(m){
  // Cac linh vuc cua ho so: uu tien mang fields (neu co), roi cat don,
  // roi chuoi tu do desired_product_types (ho so tu dang ky).
  var out = [];
  var push = function(v){ String(v||'').split(',').forEach(function(x){ var s = x.trim(); if(s && out.indexOf(s) < 0) out.push(s); }); };
  if(m && m.fields && m.fields.length) m.fields.forEach(push);
  else { push(m && m.cat); push(m && m.desired_product_types); }
  return out;
}
function modelFieldLine(m){
  var pri = m && (m.priority_field || m.priorityField);
  if(hasReal(pri)) return esc(catLabel(pri));
  var fs = modelFields(m);
  if(!fs.length) return 'Nhiều lĩnh vực';
  if(fs.length === 1) return esc(catLabel(fs[0]));
  return 'Live được ' + fs.length + ' lĩnh vực';
}
function modelLocationLine(m){
  if(m && hasReal(m.province)) return esc(m.province);
  return sourceDetailLink(m && m.src);
}
function shopLocationLine(s){
  if(s && hasReal(s.province)){
    var loc = esc(s.province);
    if(s.district && s.district !== 'Chưa cập nhật') loc += ' — ' + esc(s.district);
    return loc;
  }
  return sourceDetailLink(s && s.src);
}
function shopSalaryLine(s){
  if(s && hasReal(s.salary)) return esc(s.salary);
  return 'Thoả thuận';
}
function lotLocationLine(l){
  if(l && hasReal(l.prov)) return esc(l.prov);
  var p = findProvinceInText((l && l.title ? l.title + ' ' : '') + (l && l.meta ? l.meta : ''));
  if(p) return esc(p);
  return sourceDetailLink(l && l.url);
}
function lotValueLine(l){
  // Quy tac 08/11 19:20 (dac ta the rut gon §1c, anh chot): dong 2 the lo =
  // tong gia tri, hoac loai mat hang, hoac so luong (uu tien tong gia tri
  // -> loai mat hang -> so luong).
  // - Du gia + so luong: tong gia tri (don gia x so luong).
  // - Chi co don gia (thieu so luong): don gia /cai (hoac don vi rieng).
  // - Khong co gia: loai mat hang (catLabel); khong co loai thi so luong.
  // - Khong co gi: "Chưa cập nhật".
  // (v118 tung doi thanh CHI HIEN GIA / "Chưa cập nhật" khi thieu gia —
  // khoi phuc fallback theo quy tac 08/11 theo chi dao 10/11. Ten nganh
  // van hien trong o anh ("Xả kho: Quần áo" / "Thu mua: Quần áo").)
  if(l && typeof l.priceNum === 'number' && typeof l.qty === 'number' && l.qty > 0) return fmtVnd(l.priceNum * l.qty) + 'đ';
  if(l && typeof l.priceNum === 'number' && l.priceNum > 0) return fmtVnd(l.priceNum) + 'đ/' + (l.priceUnit || 'cái');
  if(l && hasReal(l.cat)) return esc(catLabel(l.cat));
  if(l && typeof l.qty === 'number' && l.qty > 0) return fmtVnd(l.qty) + ' cái';
  return 'Chưa cập nhật';
}
function factoryLocationLine(f){
  if(f && hasReal(f.prov)) return esc(f.prov);
  return sourceDetailLink(f && f.url);
}
function factoryItemsLine(f){
  var items = String((f && f.items) || '').split(',');
  var first = items.length ? items[0].trim() : '';
  if(first) return esc(first);
  return 'Thoả thuận';
}
function kiotLocationLine(k){
  if(k && hasReal(k.prov)) return esc(k.prov);
  return sourceDetailLink(k && k.url);
}
function kiotTypeLine(k){
  if(k && hasReal(k.cat)) return esc(catLabel(k.cat));
  return sourceDetailLink(k && k.url);
}
/* v85 (M1 đã chạy 13:57 07/11, 3 cột highest_revenue_*): doanh thu chỉ
   tính/hiển thị khi đã xác minh (highest_revenue_verified = true) và có
   số (highest_revenue_amount > 0). Số tự khai chưa xác minh, số trong
   chuỗi topRevenue cũ và "Chưa cập nhật" đều không tính — không bịa số,
   không hiện số tự khai như số đã xác minh. Dữ liệu tĩnh data.js chưa có
   hồ sơ nào có số đã xác minh nên hiện tại mọi nơi vẫn hiện "Chưa cập
   nhật" như trước; khi mẫu tự đăng ký nhập số + admin xác minh thì số tự
   hiện, không cần sửa code. */
function verifiedRevenue(m){
  if(m && m.highest_revenue_verified === true && typeof m.highest_revenue_amount === 'number' && m.highest_revenue_amount > 0) return m.highest_revenue_amount;
  return null;
}
function revenueText(m){
  var v = verifiedRevenue(m);
  if(v === null) return 'Chưa cập nhật';
  var note = hasReal(m.highest_revenue_note) ? ' (' + String(m.highest_revenue_note).trim() + ')' : '';
  return fmtVnd(v) + 'đ' + note;
}
function isNegotiableSalary(m){ return String(m.salary||'').trim() === 'Thỏa thuận'; }
/* v37: ALWAYS render all decision boxes, even when a value is missing
   (shown muted as "Chưa cập nhật"). Hiding empty values made the inner blocks
   start at different heights in every row (same root cause as the shop cards,
   visual QA 05/11). */
function decisionHTML(m){
  var sal = (hasReal(m.salary) && !isNegotiableSalary(m)) ? esc(m.salary) : (isNegotiableSalary(m) ? 'Thỏa thuận' : 'Chưa cập nhật');
  var sch = hasReal(m.schedule) ? esc(m.schedule) : 'Chưa cập nhật';
  var rev = esc(revenueText(m));
  var exp = hasReal(m.exp) ? esc(m.exp) : 'Chưa cập nhật';
  var miss = function(v){ return v === 'Chưa cập nhật' ? ' muted' : ''; };
  return '<div class="decision">'
  + '<div class="decision-row">'
  + '<div class="decision-item"><span class="decision-label">💰 Lương</span><b class="decision-value'+miss(sal)+'">'+sal+'</b></div>'
  + '<div class="decision-item"><span class="decision-label">🕒 Lịch</span><span class="decision-value'+miss(sch)+'">'+sch+'</span></div>'
  + '</div>'
  + '<div class="decision-row"><div class="decision-item"><span class="decision-label">📈 Doanh thu cao nhất</span><b class="decision-value'+miss(rev)+'">'+rev+'</b></div></div>'
  + '<div class="decision-exp"><span class="decision-label">Kinh nghiệm</span><span class="decision-value'+miss(exp)+'">'+exp+'</span></div>'
  + '</div>';
}
/* v40: dong mien tru trach nhiem o cuoi moi the mau/shop (yeu cau nguoi dung
   toi 05/11/2026, ban viet lai da chot) — dat sau nut hanh dong, o day the.
   v177 (12/11/2026, anh Thọ chốt): them cau ket noi cung cau do chu noi
   dung public cong khai + cau ghim sao o cuoi; ap dung cho ca 5 loai ho so
   (mau/shop chi tiet day du + modal dung chung lotFactoryKiotDetailHTML).
   v180 (12/11/2026, anh Thọ giao 20:28): them dong "ghim lau hon" + nut
   dang ky o CUOI mien tru (PIN_LONGER_HTML) — moi dang ky/dang nhap de ghim
   lau hon. Hien LUON (ke ca da dang nhap): khong co ham kiem tra dang nhap
   DONG BO trong duong render modal (pointsSessionUser() la async; dung de
   an sau render se gay chop; currentUser chi la bien cuc bo trong ham
   transfer). Dong nay nho, o cuoi muc ghi chu, khong anh huong nguoi da
   dang nhap. Voi 5 danh muc moi (khong nut sao), dong nay van hien nhu loi
   moi dang ky, khong nhac sao (replace o modal chi bo cau ghim sao). */
var PIN_LONGER_HTML = '<br><span class="pin-longer-text">Muốn ghim hồ sơ lên top lâu hơn? <a href="dang-ky.html">Đăng ký</a> / <a href="dang-nhap.html">Đăng nhập</a> để ghim lâu hơn.</span><br><a class="btn btn-primary btn-sm pin-longer-btn" href="dang-ky.html">Đăng ký để ghim lâu hơn</a>';
var DISCLAIMER = 'Miễn trừ trách nhiệm: Chúng tôi hỗ trợ kết nối cung cầu do chủ nội dung public công khai. Thông tin được tổng hợp từ bài đăng công khai của cộng đồng, giữ nguyên nội dung gốc. Thông tin liên hệ hiển thị để các bên tự trao đổi công việc trực tiếp với nhau. Ver2Solution không thu bất kỳ phí dịch vụ nào — đây chỉ là trang cộng đồng kết nối. Để ghim hồ sơ này lên top, hãy ấn sao ★ (mỗi sao lên top 60 phút).' + PIN_LONGER_HTML;
/* v42: dong huong dan chu so huu o cuoi moi the (yeu cau nguoi dung 06/11/2026),
   ngay DUOI .disclaimer, la phan tu cuoi cung cua the. Khop quy tac so huu ho
   so chot 05/11/2026 23:38: chi chu ho so dang ky tai khoan, khop thong tin
   lien he moi duoc sua/huy ho so — dong nay huong dan chu ho so cach sua
   (dang ky/dang nhap) hoac go (lien he Zalo). Link dang ky/dang nhap dung loai:
   the mau -> danh-sach-shop.html#dang-nhap-mau, the shop ->
   danh-sach-mau.html#dang-nhap-shop (duong dan tuong doi day du de link dung
   tu moi trang: trang chu, trang danh sach, trang chi tiet).
   v85: link "Đăng ký" tro dung trang dang ky RIENG dang-ky.html (kem
   ?type= theo loai the); link "Đăng nhập" giu neo muc dang nhap tren
   trang danh sach (form dang nhap nhanh tai cho, van hoat dong).
   v165 (claim V1, 12/11/2026): them tham so profileId (tuy chon) —
   khi co id thi render them <span class="claim-slot"> de js/claim.js
   dien nut "Day la ho so cua ban? Nhan so huu" khi SDT cua user dang
   dang nhap trung lien he cua ho so dang xem. Khong co id (the danh
   sach khong goi ham nay) thi chi hien dong chu nhu cu. */
function ownerNoteHTML(kind, profileId){
  var type = kind === 'shop' ? 'shop' : 'model';
  var loginHref = kind === 'shop' ? 'danh-sach-mau.html#dang-nhap-shop' : 'danh-sach-shop.html#dang-nhap-mau'; // A3 10/11 un-swap v96
  var slot = profileId ? ' <span class="claim-slot" data-claim-profile="'+esc(profileId)+'" data-claim-kind="'+type+'"></span>' : '';
  return '<p class="owner-note"><a href="dang-ky.html?type='+type+'">Đăng ký</a> &gt; <a href="'+loginHref+'">Đăng nhập</a> để sửa hồ sơ này, hoặc liên hệ <a href="https://zalo.me/0329983699" target="_blank" rel="noopener">Zalo</a> để được gỡ bỏ.</p>' + slot;
}
/* ---- Xu thưởng v2 (GĐ2, 07/11/2026) — nút thích/chia sẻ, ghim, xếp ghim ----
   Xem goals/.../diem-thuong-v2-2026-11-07.md. Client chỉ gọi RPC M7 qua
   window.Ver2Reward (awardInteraction / pinPost / getMyPointsBalance);
   RPC chưa có thì nút báo "chưa bật", không vỡ trang. Khách vãng lai: 0 xu,
   bấm nút chỉ thấy ghi chú đăng nhập. */
function pointsButtonsHTML(targetType, targetId){
  // v111 (NEW-07): khoi phuc trang thai "Da thich" khi render lai (doc tu
  // localStorage v2s_likes_v1, giong co che sao v2s_stars_v1).
  // v114 (P3-6): khoi phuc ca "Da chia se" (v2s_shares_v1).
  var liked = likedToday(targetType, targetId);
  var shared = sharedToday(targetType, targetId);
  return '<span class="v2s-points-row" data-v2s-target-type="'+esc(targetType)+'" data-v2s-target-id="'+esc(targetId)+'">'
  + '<button class="btn btn-ghost btn-sm' + (liked ? ' v2s-liked' : '') + '" type="button" data-v2s-like' + (liked ? ' disabled aria-pressed="true"' : '') + '>' + (liked ? '👍 Đã thích' : '👍 Thích · +1') + '</button>'
  + '<button class="btn btn-ghost btn-sm' + (shared ? ' v2s-shared' : '') + '" type="button" data-v2s-share' + (shared ? ' disabled aria-pressed="true"' : '') + '>' + (shared ? '↗ Đã chia sẻ' : '↗ Chia sẻ · +2') + '</button>'
  + '<button class="btn btn-ghost btn-sm" type="button" data-v2s-pin>📌 Ghim lên top</button>'
  + '<span class="v2s-points-msg" role="status"></span></span>';
}
function articleRef(a){
  var h = articleHref(a) || '';
  var parts = String(h).split('/');
  return parts[parts.length - 1] || h;
}
// v92 (BUG-14): nút Thích phải đổi trạng thái NGAY sau khi bấm — đổi nhãn
// thành "👍 Đã thích", thêm class v2s-liked, vô hiệu nút (không bấm lặp
// trong cùng lượt render). Chỉ gọi khi RPC awardInteraction đã trả ok.
function markLiked(btn){
  try {
    if (!btn) return;
    if (btn.classList && btn.classList.add) btn.classList.add('v2s-liked');
    btn.textContent = '👍 Đã thích';
    btn.disabled = true;
    if (btn.setAttribute) btn.setAttribute('aria-pressed', 'true');
    // v111 (NEW-07): ghi lai trang thai da thich (giong co che sao
    // v2s_stars_v1) de render lai sau tai trang hien "Da thich".
    try {
      var row = (btn.closest) ? btn.closest('.v2s-points-row') : null;
      if (row && row.getAttribute) markLikedToday(row.getAttribute('data-v2s-target-type'), row.getAttribute('data-v2s-target-id'));
    } catch (e2) {}
  } catch (e) {}
}
/* v111 (NEW-07): trang thai Thich luu localStorage theo ngay (giong sao).
   Gioi han server la 1 lan/ngay/loai (awardInteraction) nen 1 nut chi
   hien "Da thich" trong ngay da bam; sang ngay moi duoc thich lai. */
var LIKE_STORE_KEY = 'v2s_likes_v1';
function likeStoreRead(){
  try { var raw = (typeof localStorage !== 'undefined') ? localStorage.getItem(LIKE_STORE_KEY) : null; return raw ? JSON.parse(raw) : {}; } catch (e) { return {}; }
}
function likeStoreWrite(map){
  try { if (typeof localStorage !== 'undefined') localStorage.setItem(LIKE_STORE_KEY, JSON.stringify(map)); } catch (e) {}
}
function likeKey(type, id){ return String(type || '') + ':' + String(id || ''); }
function likedToday(type, id, today){
  if (!type || !id) return false;
  var map = likeStoreRead();
  return map[likeKey(type, id)] === (today || starTodayStr());
}
function markLikedToday(type, id){
  if (!type || !id) return;
  var map = likeStoreRead(); map[likeKey(type, id)] = starTodayStr(); likeStoreWrite(map);
}
/* v114 (P3-6): trang thai Chia se luu localStorage theo ngay (giong Thich).
   Gioi han server la 1 lan/ngay/loai (awardInteraction) nen 1 nut chi
   hien "Da chia se" trong ngay da bam; sang ngay moi duoc chia se lai. */
var SHARE_STORE_KEY = 'v2s_shares_v1';
function shareStoreRead(){
  try { var raw = (typeof localStorage !== 'undefined') ? localStorage.getItem(SHARE_STORE_KEY) : null; return raw ? JSON.parse(raw) : {}; } catch (e) { return {}; }
}
function shareStoreWrite(map){
  try { if (typeof localStorage !== 'undefined') localStorage.setItem(SHARE_STORE_KEY, JSON.stringify(map)); } catch (e) {}
}
function shareKey(type, id){ return String(type || '') + ':' + String(id || ''); }
function sharedToday(type, id, today){
  if (!type || !id) return false;
  var map = shareStoreRead();
  return map[shareKey(type, id)] === (today || starTodayStr());
}
function markSharedToday(type, id){
  if (!type || !id) return;
  var map = shareStoreRead(); map[shareKey(type, id)] = starTodayStr(); shareStoreWrite(map);
}
// v114 (P3-6): nut Chia se doi trang thai NGAY sau khi bam — doi nhan
// thanh "↗ Da chia se", them class v2s-shared, vo hieu nut (khong bam lap
// trong cung luot render). Chi goi khi RPC awardInteraction da tra ok.
function markShared(btn){
  try {
    if (!btn) return;
    if (btn.classList && btn.classList.add) btn.classList.add('v2s-shared');
    btn.textContent = '↗ Đã chia sẻ';
    btn.disabled = true;
    if (btn.setAttribute) btn.setAttribute('aria-pressed', 'true');
    try {
      var row = (btn.closest) ? btn.closest('.v2s-points-row') : null;
      if (row && row.getAttribute) markSharedToday(row.getAttribute('data-v2s-target-type'), row.getAttribute('data-v2s-target-id'));
    } catch (e2) {}
  } catch (e) {}
}
/* v99 (§2 dac ta sao len top) + v183 (anh chot A 21:56 12/11/2026)
   + v185 (tach han theo noi 22:02 + sao mien phi + hieu ung + popup 22:06/22:08):
   sao = xep hang cong khai, KHONG cong diem, ai cung an duoc (khac
   nut Thich +1 diem, chi tai khoan). Moi lan an sao hop le +1 vao
   tong so sao (profile_star_stats) va hien ngay tren nut sao o the
   ho so ngoai; moi sao len top 60 phut ke tu lan an gan nhat.
   - Gioi han 1 sao / 1 ho so / 1 phien an danh / 12 gio (khach) hoac
     1 sao / 1 tai khoan / 12 gio (da dang nhap) — TACH HAN THEO NOI:
     trang chu (home) va trang con (sub) tinh RIENG (gioi han 12h +
     so sao + top 60 phut). Server kiem tra qua RPC star_profile
     (created_at > now() - 12h AND place = noi hien tai); client them
     lop chan dia phuong (localStorage, luu moc thoi gian, khoa theo
     noi:type:id) de nut hien "da sao" ngay ca khi tai lai trang.
     Het 12h an lai duoc, lai +1 sao.
   - Sao MIEN PHI (khong ton xu). Moi lan an hop le: so tang NGAY
     kem hieu ung (so nhay len, sao sang len) + popup goi y dang ky
     de ghim lau hon (chi goi y, khong chan xem).
   - Tang sao 60 phut: last_starred_at trong 60 phut -> xep truoc theo
     so sao giam dan, roi theo thoi gian an sao gan nhat giam dan;
     het 60 phut rot ve thu tu mac dinh. Chi ap dung tang sao cho
     grid mau (initList) + grid shop (initShops) — 2 grid render lai
     duoc an toan; lo/xuong/kiot chi hien nut sao + so sao (grid cua
     chung duoc bo loc chup lai luc khoi tao nen khong render lai). */
var STAR_STORE_KEY = 'v2s_stars_v1';
var STAR_STATS = {}; // id -> {count, last} (nap tu profile_star_stats)
var STAR_STATS_LOADED = false; // v114 (P3-4): sao hien "…" truoc khi nap xong, khong hien 0 gia.
var STAR_WINDOW_MS = 60 * 60 * 1000;
var STAR_LIMIT_MS = 12 * 60 * 60 * 1000; // v183 (A): 1 sao / 12h / 1 ho so / 1 phien (khach) hoac 1 tai khoan (da dang nhap)
// v185: noi hien tai — 'home' (trang chu index.html) hoac 'sub' (trang con).
// Moi trang chi co 1 noi; khong co location (test Node) -> 'home'.
function starPlace(){
  try { var p = String((typeof location !== 'undefined' && location.pathname) || '').split('/').pop() || 'index.html'; return (p === 'index.html' || p === '') ? 'home' : 'sub'; }
  catch (e) { return 'home'; }
}
function starStoreRead(){
  try { var raw = (typeof localStorage !== 'undefined') ? localStorage.getItem(STAR_STORE_KEY) : null; return raw ? JSON.parse(raw) : {}; } catch (e) { return {}; }
}
function starStoreWrite(map){
  try { if (typeof localStorage !== 'undefined') localStorage.setItem(STAR_STORE_KEY, JSON.stringify(map)); } catch (e) {}
}
function starKey(a, b, c){ // v185: khoa theo noi:type:id. Goi 2 doi so (type, id) -> noi hien tai.
  if (c !== undefined) return String(a || 'home') + ':' + String(b || '') + ':' + String(c || '');
  return starPlace() + ':' + String(a || '') + ':' + String(b || '');
}
function starTodayStr(d){ d = d || new Date(); var y = d.getFullYear(), m = ('0' + (d.getMonth() + 1)).slice(-2), dd = ('0' + d.getDate()).slice(-2); return y + '-' + m + '-' + dd; }
function starredWithin12h(type, id, nowMs, place){
  var map = starStoreRead();
  var v = map[starKey(place || starPlace(), type, id)];
  if(v === undefined || v === null) return false;
  var now = (typeof nowMs === 'number') ? nowMs : Date.now();
  if(typeof v === 'number' && isFinite(v)) return (now - v) < STAR_LIMIT_MS;
  // Tuong thich gia tri cu (dang 'YYYY-MM-DD', luat 1 sao/ngay):
  // coi nhu da sao den het ngay do.
  return String(v) === starTodayStr(new Date(now));
}
function markStarred(type, id, nowMs, place){
  var map = starStoreRead(); map[starKey(place || starPlace(), type, id)] = (typeof nowMs === 'number') ? nowMs : Date.now(); starStoreWrite(map);
}
// Ten cu giu lam alias (nghia moi: da sao trong 12h) de khong vo cho
// nao con goi ten cu.
function starredToday(type, id, today){ return starredWithin12h(type, id, (typeof today === 'number') ? today : undefined); }
function markStarredToday(type, id){ markStarred(type, id); }
function starCountOf(id){ var s = STAR_STATS[id]; return (s && typeof s.count === 'number') ? s.count : 0; }
function starButtonHTML(targetType, targetId){
  // v114 (P3-4): chua nap xong bang sao thi hien "…" — khong hien 0 gia.
  var count = STAR_STATS_LOADED ? starCountOf(targetId) : '…';
  var done = starredWithin12h(targetType, targetId);
  return '<button class="v2s-star-btn' + (done ? ' starred' : '') + '" type="button" data-star-type="' + esc(targetType) + '" data-star-id="' + esc(targetId) + '" data-star-place="' + starPlace() + '" data-star-count="' + count + '"' + (done ? ' disabled' : '') + ' aria-label="Ấn sao để đưa hồ sơ này lên top 60 phút">★ <span class="v2s-star-count">' + count + '</span></button>';
}
function starTierOf(item, stats, now){
  var s = stats && item && stats[item.id];
  if(!s || !s.last) return 0;
  var t = Date.parse(s.last);
  if(!isFinite(t)) return 0;
  return (now - t) < STAR_WINDOW_MS ? 1 : 0;
}
function applyStarOrder(list, stats, now){
  // On dinh (stable): tang 1 truoc (sao giam dan, moi nhat truoc),
  // tang 0 giu nguyen thu tu goc.
  var n = (now == null) ? Date.now() : now;
  var tier1 = [], tier0 = [];
  (list || []).forEach(function(it){ (starTierOf(it, stats, n) === 1 ? tier1 : tier0).push(it); });
  tier1.sort(function(a, b){
    var sa = stats[a.id] || {}, sb = stats[b.id] || {};
    var dc = (sb.count || 0) - (sa.count || 0);
    if(dc) return dc;
    return Date.parse(sb.last || 0) - Date.parse(sa.last || 0);
  });
  return tier1.concat(tier0);
}
function refreshStarCounts(){
  if(typeof document === 'undefined' || !document.querySelectorAll) return;
  var btns = document.querySelectorAll('.v2s-star-btn');
  for(var i = 0; i < btns.length; i++){
    var b = btns[i], id = b.getAttribute('data-star-id'), ty = b.getAttribute('data-star-type');
    var c = starCountOf(id);
    if(b.setAttribute) b.setAttribute('data-star-count', String(c));
    var n = (b.querySelector) ? b.querySelector('.v2s-star-count') : null; if(n) n.textContent = String(c);
    if(starredWithin12h(ty, id)){ if(b.classList) b.classList.add('starred'); b.disabled = true; }
  }
}
function fetchStarStats(){
  // Nap bang dem sao cong khai; loi (migration chua chay) -> {} im lang.
  var M = (typeof window !== 'undefined') ? window.McLivestreamAPI : null;
  if(!M || typeof M.fetchStarStats !== 'function'){ STAR_STATS_LOADED = true; return Promise.resolve({}); }
  return M.fetchStarStats().then(function(rows){
    var map = {};
    var place = starPlace(); // v185: chi nap so sao cua noi hien tai (hang cu khong co place -> 'home').
    (rows || []).forEach(function(r){ if(r && r.profile_id){ var rp = (r.place === 'sub' || r.place === 'home') ? r.place : 'home'; if(rp !== place) return; map[r.profile_id] = {count: Number(r.star_count) || 0, last: r.last_starred_at || null}; } });
    STAR_STATS = map;
    STAR_STATS_LOADED = true;
    return map;
  }, function(){ STAR_STATS_LOADED = true; return {}; });
}
/* v111 (NEW-S1): toast phan hoi khi bam sao — dung style inline de khong
   phu thuoc file CSS (chi sua app.js trong nhom nay). Tu bien mat sau 3s. */
function starToast(msg){
  if (typeof document === 'undefined' || !document.body || typeof document.createElement !== 'function') return;
  try {
    var old = (document.getElementById) ? document.getElementById('v2sStarToast') : null;
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var el = document.createElement('div');
    el.id = 'v2sStarToast';
    el.setAttribute('role', 'status');
    el.textContent = msg;
    if (el.style) el.style.cssText = 'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#0b5d4e;color:#fff;padding:10px 16px;border-radius:8px;font-size:14px;font-weight:700;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,.25);max-width:calc(100vw - 32px);text-align:center;';
    document.body.appendChild(el);
    if (typeof setTimeout === 'function') setTimeout(function(){ if (el.parentNode) el.parentNode.removeChild(el); }, 3000);
  } catch (e) {}
}
/* v185 (pheu dang ky, anh chot 22:06 12/11/2026): popup GOI Y dang ky —
   CHI goi y, KHONG chan xem. Hien khi: (1) an sao xong (kind 'star':
   goi y dang ky de ghim lau hon 60 phut); (2) mo xem chi tiet ho so
   (kind 'detail': goi y dang ky de xem day du + sua ho so neu la ho
   so cua ban). Co nut "Dang ky ngay" (sang dang-ky.html, tu chon loai
   tai khoan tren trang do) + "De sau" + dau X + bam nen ngoai de dong.
   Da dang nhap thi KHONG hien (kiem tra session neu API co san;
   khong kiem tra duoc thi hien). Dung style inline nhu starToast de
   khong phu thuoc file CSS. */
function v2sSignupPopup(kind){
  if (typeof document === 'undefined' || !document.body || typeof document.createElement !== 'function') return;
  try {
    var M = (typeof window !== 'undefined') ? window.McLivestreamAPI : null;
    var show = function(){
      try {
        if ((typeof document.getElementById === 'function') && document.getElementById('v2sSignupPopup')) return; // chi 1 popup 1 luc
        var isStar = kind === 'star';
        var ov = document.createElement('div');
        ov.id = 'v2sSignupPopup';
        ov.setAttribute('role', 'dialog');
        ov.setAttribute('aria-modal', 'true');
        if (ov.style) ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:10000;display:flex;align-items:center;justify-content:center;padding:16px;';
        var box = document.createElement('div');
        if (box.style) box.style.cssText = 'background:#fff;border-radius:12px;max-width:420px;width:100%;padding:20px;box-shadow:0 8px 32px rgba(0,0,0,.3);text-align:center;position:relative;';
        var title = isStar ? '⭐ Ghim hồ sơ này lâu hơn?' : '👋 Đăng ký để xem đầy đủ?';
        var body = isStar
          ? 'Bạn vừa sao hồ sơ lên top 60 phút. Đăng ký tài khoản (miễn phí, tặng 10 xu) để ghim hồ sơ này lâu hơn và được shop liên hệ trực tiếp.'
          : 'Đăng ký tài khoản (miễn phí, tặng 10 xu) để xem đầy đủ chi tiết hồ sơ, lưu hồ sơ yêu thích và sửa hồ sơ này nếu đây là hồ sơ của bạn.';
        box.innerHTML = '<button type="button" aria-label="Đóng" style="position:absolute;top:8px;right:12px;border:0;background:none;font-size:20px;cursor:pointer;">✕</button>'
          + '<h3 style="margin:0 0 8px;font-size:18px;">' + title + '</h3>'
          + '<p style="margin:0 0 16px;font-size:14px;line-height:1.5;color:#333;">' + body + '</p>'
          + '<p style="margin:0;display:flex;gap:8px;justify-content:center;"><a href="dang-ky.html" style="background:#0b5d4e;color:#fff;padding:10px 18px;border-radius:8px;font-weight:700;text-decoration:none;">Đăng ký ngay</a>'
          + '<button type="button" style="background:#eee;color:#333;border:0;padding:10px 18px;border-radius:8px;font-weight:700;cursor:pointer;">Để sau</button></p>';
        var close = function(){ if (ov.parentNode) ov.parentNode.removeChild(ov); };
        if (ov.addEventListener) ov.addEventListener('click', function(e){ if (e && e.target === ov) close(); });
        var btns = (box.getElementsByTagName) ? box.getElementsByTagName('button') : [];
        for (var i = 0; i < btns.length; i++) { if (btns[i].addEventListener) btns[i].addEventListener('click', close); }
        ov.appendChild(box);
        document.body.appendChild(ov);
      } catch (e) {}
    };
    if (M && typeof M.getSession === 'function') {
      M.getSession().then(function(s){ if (!s || !s.user) show(); }, function(){ show(); });
    } else { show(); }
  } catch (e) {}
}
/* v117 (pheu dang ky): toast dung chung — cung kieu starToast (style
   inline, co dinh duoi giua man hinh, tu bien mat), dung cho thong bao
   sau dang ky ("Ban nhan duoc 10 xu thuong!"). msg() trong form khong
   dung duoc viec nay: form bi an ngay sau showUser() nen nguoi dung
   khong bao gio thay dong msg. ms mac dinh 4000. */
var V2S_PENDING_TOAST_KEY = 'v2s_pending_toast';
var V2S_PENDING_TOAST_MAX_AGE_MS = 10000;
function v2sToast(msg, ms){
  if (typeof document === 'undefined' || !document.body || typeof document.createElement !== 'function') return;
  try {
    var old = (document.getElementById) ? document.getElementById('v2sToast') : null;
    if (old && old.parentNode) old.parentNode.removeChild(old);
    var el = document.createElement('div');
    el.id = 'v2sToast';
    el.setAttribute('role', 'status');
    el.textContent = msg;
    if (el.style) el.style.cssText = 'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#0b5d4e;color:#fff;padding:10px 16px;border-radius:8px;font-size:14px;font-weight:700;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,.25);max-width:calc(100vw - 32px);text-align:center;';
    document.body.appendChild(el);
    if (typeof setTimeout === 'function') setTimeout(function(){ if (el.parentNode) el.parentNode.removeChild(el); }, (typeof ms === 'number' && ms > 0) ? ms : 4000);
  } catch (e) {}
}
if (typeof window !== 'undefined') window.V2SToast = v2sToast;
/* v117: doc toast cho hien lai tren trang dich (vd dang-ky.html chuyen
   sang trang chu 800ms sau dang ky, toast tren trang cu bien mat theo
   dieu huong). auth-ui.js luu {text, ts} vao sessionStorage truoc khi
   chuyen; chi hien khi toast moi (< 10s) de khong hien lai toast cu o
   lan dieu huong sau. Luon xoa key sau khi doc. Goi o DOMContentLoaded. */
function showPendingToast(){
  try {
    if (typeof window === 'undefined' || !window.sessionStorage) return;
    var raw = window.sessionStorage.getItem(V2S_PENDING_TOAST_KEY);
    if (!raw) return;
    try { window.sessionStorage.removeItem(V2S_PENDING_TOAST_KEY); } catch (e) {}
    var o = null;
    try { o = JSON.parse(raw); } catch (e) { o = null; }
    if (!o || typeof o.text !== 'string' || !o.text) return;
    var age = Date.now() - Number(o.ts || 0);
    if (isNaN(age) || age < 0 || age > V2S_PENDING_TOAST_MAX_AGE_MS) return;
    v2sToast(o.text);
  } catch (e) {}
}
function starClick(btn, api){
  // Bam sao: lac quan +1 ngay + vo hieu nut, goi RPC, that bai thi hoan lai.
  // api mac dinh = window.McLivestreamAPI (test truyen api gia).
  if(!btn) return Promise.resolve(null);
  var type = btn.getAttribute ? btn.getAttribute('data-star-type') : null;
  var id = btn.getAttribute ? btn.getAttribute('data-star-id') : null;
  var place = (btn.getAttribute ? btn.getAttribute('data-star-place') : null) || starPlace(); // v185: sao theo noi
  if(!type || !id) return Promise.resolve(null);
  if(starredWithin12h(type, id, undefined, place)) return Promise.resolve(null);
  var A = api || ((typeof window !== 'undefined') ? window.McLivestreamAPI : null);
  if(!A || typeof A.starProfile !== 'function'){
    if(btn.setAttribute) btn.setAttribute('title', 'Chưa kết nối được, thử lại sau.');
    starToast('Chưa kết nối được, thử lại sau.');
    return Promise.resolve(null);
  }
  var before = starCountOf(id);
  var beforeLast = (STAR_STATS[id] && STAR_STATS[id].last) || null;
  STAR_STATS[id] = {count: before + 1, last: new Date().toISOString()};
  if(btn.classList) btn.classList.add('starred');
  if(btn.classList) btn.classList.add('v2s-star-pop'); // v185: hieu ung so nhay len (CSS v20.css)
  if (typeof setTimeout === 'function') setTimeout(function(){ if(btn.classList) btn.classList.remove('v2s-star-pop'); }, 600);
  btn.disabled = true;
  refreshStarCounts();
  return A.starProfile(type, id, place).then(function(count){
    STAR_STATS[id] = {count: Number(count) || before + 1, last: new Date().toISOString()};
    markStarred(type, id, undefined, place);
    refreshStarCounts();
    // v111 (NEW-S1): toast xac nhan sao thanh cong (luat sao v185:
    // khach 1 sao/ho so/phien/12h/theo noi; tai khoan 1 sao/ho so/12h/theo noi; top 60 phut).
    starToast('Đã sao ★ — hồ sơ lên top 60 phút.');
    v2sSignupPopup('star'); // v185: popup goi y dang ky de ghim lau hon (chi goi y, khong chan).
    return STAR_STATS[id].count;
  }, function(err){
    var msg = String((err && err.message) || err || '');
    if(/already_starred(_today|_12h)?/i.test(msg)){
      markStarred(type, id, undefined, place);
      refreshStarCounts();
      starToast('Bạn đã sao hồ sơ này rồi, 12 giờ sau ấn lại được.');
      return starCountOf(id);
    }
    STAR_STATS[id] = {count: before, last: beforeLast};
    if(btn.classList) btn.classList.remove('starred');
    if(btn.classList) btn.classList.remove('v2s-star-pop');
    btn.disabled = false;
    refreshStarCounts();
    if(btn.setAttribute) btn.setAttribute('title', 'Chưa gửi được sao, thử lại sau.');
    starToast('Chưa gửi được sao, thử lại sau.');
    return null;
  });
}
function initStars(){
  if(typeof document === 'undefined' || !document.addEventListener) return;
  // Uy thac click: the render dong (phan trang/loc) khong can gan lai.
  document.addEventListener('click', function(e){
    var t = e && e.target;
    if(!t) return;
    var btn = (t.closest && t.closest('.v2s-star-btn')) || null;
    if(!btn) return;
    e.preventDefault();
    starClick(btn);
  });
  // Nap so sao roi cap nhat so hien thi + sap xep lai grid mau/shop
  // (chi khi co sao trong 60 phut — khong thi giu nguyen thu tu).
  fetchStarStats().then(function(map){
    refreshStarCounts();
    var hasRecent = false, now = Date.now();
    Object.keys(map).forEach(function(k){ if(starTierOf({id: k}, map, now) === 1) hasRecent = true; });
    if(!hasRecent) return;
    try {
      if(typeof modelGridRender === 'function'){
        var p = params(); var pg = parseInt(p.page || '1', 10) || 1;
        modelGridRender(pg);
      }
    } catch (e) {}
    try {
      var shopEl = document.getElementById('publicShopsList');
      if(shopEl && typeof shopEl._shopRender === 'function'){
        var p2 = params(); var pg2 = parseInt(p2.page || '1', 10) || 1;
        shopEl._shopRender(pg2);
      }
    } catch (e) {}
  });
}
function cardHTML(m, opts){
  // v99 (§1): the rut gon — anh 46/51 + ten overlay cuoi anh + dung
  // 2 dong (noi tim viec, linh vuc) + nut sao. Luong/gio lam/luot xem/
  // binh luan/danh gia/lien he/diem chi con o trang chi tiet (ho-so.html).
  // opts (v63: zaloHref/demoUrl) duoc giu de tuong thich nhung khong
  // con dung tren the danh sach. data-gender mang "" khi khong ro gioi
  // tinh (v28) — chu placeholder khong bao gio vao DOM.
  opts = opts || {};
  return '<article class="card card-compact" id="'+esc(m.id)+'" data-v2s-id="'+esc(m.id)+'" data-province="'+esc(m.province)+'" data-cat="'+esc(m.cat)+'" data-gender="'+esc(hasReal(m.gender)?m.gender:'')+'" data-views="'+m.views+'" data-comments="'+m.comments+'">'
  + '<a class="card-compact-photo" href="ho-so.html?id='+esc(m.id)+'">'+photoHTML(m, 'compact')+'<span class="card-compact-name"><span>'+esc(m.name)+'</span></span></a>'
  + starButtonHTML('model_profile', m.id)
  + '<div class="card-compact-lines"><p class="card-compact-line">'+modelLocationLine(m)+'</p><p class="card-compact-line">'+modelFieldLine(m)+'</p></div>'
  + '</article>';
}
function miniHTML(m){
  return '<article class="mini"><div class="mini-photo">'+photoHTML(m)+'</div><div class="mini-body"><h3><a data-track="xem-ho-so" href="ho-so.html?id='+esc(m.id)+'">'+esc(m.province)+' — '+esc(m.name)+'</a></h3>'
  + '<p>'+esc(m.title)+'</p><p>📍 '+esc(m.province)+' · '+esc(m.cat)+'</p><p>Lương: '+esc(m.salary)+'</p><p>'+esc(m.exp)+'</p></div></article>';
}
/* Contacts (v26, spec §8): render ONLY the audited `contacts` array from data.js.
   Every value is escaped before render (AGENTS.md §1.7). Zalo numbers are
   10-digit strings already normalised in data.js; the link is always zalo.me,
   never a bare number. Items with no public source simply do not exist in
   `contacts`, so they are never rendered and never shown as "Chưa cập nhật". */
var CONTACT_NOTE = 'Các bên chủ động liên hệ trao đổi, thông tin là công khai.';
function defaultContactLabel(p){
  return {facebook:'Facebook', zalo:'Zalo', phone:'Số điện thoại', email:'Email', tiktok:'TikTok', shopee:'Shopee', threads:'Threads'}[p] || 'Liên hệ';
}
function digitsOnly(v){ return String(v||'').replace(/\D/g,''); }
function contactHref(c){
  if(c.provider==='zalo') return 'https://zalo.me/'+digitsOnly(c.value);
  if(c.provider==='phone') return 'tel:'+digitsOnly(c.value);
  if(c.provider==='email') return 'mailto:'+c.value;
  return c.value; // facebook / tiktok / shopee / threads: full public URL
}
function contactItemHTML(c, trackAttr){
  var label = esc(c.label || defaultContactLabel(c.provider));
  var href = esc(contactHref(c));
  var ext = (c.provider==='facebook'||c.provider==='tiktok'||c.provider==='shopee'||c.provider==='threads') ? ' target="_blank" rel="noopener"' : '';
  // v99: nut Zalo doi tu the danh sach sang khoi lien he cua trang chi tiet —
  // giu event analytics tren chinh link Zalo do (trackAttr = 'data-track="nhan-zalo-mau"' hoac '...-shop').
  var tr = (trackAttr && (c.provider==='zalo' || c.provider==='phone')) ? ' ' + trackAttr : '';
  if(c.provider==='facebook'||c.provider==='tiktok'||c.provider==='shopee'||c.provider==='threads'){
    return '<li><a href="'+href+'"'+ext+'>'+label+'</a></li>';
  }
  return '<li>'+label+': <a'+tr+' href="'+href+'"'+ext+'>'+esc(c.value)+'</a></li>';
}
function contactsBlockHTML(contacts, trackAttr){
  if(!contacts || !contacts.length) return '';
  return '<ul class="contact-list">'+contacts.map(function(c){ return contactItemHTML(c, trackAttr); }).join('')+'</ul>';
}
/* Xu v2 (GĐ2, 20:22 07/11): xem liên hệ 1 hồ sơ = 5 xu/lần bấm (1 lần/
   ngày/hồ sơ). contactsBlockHTML() giữ nguyên (render danh sách đầy đủ,
   dùng sau khi đã trả xu + test cũ); hàm này bọc nó trong khối ẩn + nút
   "Xem liên hệ". LƯU Ý: số liên hệ vẫn nằm trong js/data.js công
   khai nên đây là cửa thu xu ở giao diện, không phải kiểm soát truy cập
   thật — xem spec §12. Nút bấm được xử lý tập trung trong initPointsUI.
   v92 (08/11/2026): xem liên hệ TẠM MIỄN PHÍ (cờ V20_FREE_SERVICES ở
   js/reward.js) — nhãn nút bỏ "(5 xu)", bấm hiện ngay không trừ xu;
   code trừ xu giữ nguyên để mở lại chỉ bằng 1 cờ. */
function gatedContactsHTML(targetType, targetId, contacts){
  if(!contacts || !contacts.length) return '';
  var trackAttr = targetType==='model_profile' ? 'data-track="nhan-zalo-mau"' : 'data-track="nhan-zalo-shop"';
  return '<div class="v2s-contacts-gated" data-v2s-target-type="'+esc(targetType)+'" data-v2s-target-id="'+esc(targetId)+'">'
  + '<div class="v2s-contacts-hidden" hidden>'+contactsBlockHTML(contacts, trackAttr)+contactNoteHTML()+'</div>'
  + '<p><button class="btn btn-ghost btn-sm" type="button" data-v2s-view-contact>👁 Xem liên hệ</button> <span class="v2s-contact-msg" role="status"></span></p></div>';
}
function contactNoteHTML(){ return '<p class="contact-note">'+CONTACT_NOTE+'</p>'; }
/* Shops (v22): tin tuyển công khai thu thập từ bài tuyển shop tự đăng.
   v26: 3 shops have a verified real logo (images-shop/; FANI square = cover,
   Chạm Loa + Mylan transparent/wide = contain on white, never cropped).
   The other 21 keep the initial-letter placeholder. Contact block + Notes
   (spec §8.3) show ONLY the audited public contacts; a shop with no public
   number/email shows no Zalo/phone/email line at all. No private phone/Zalo/
   address, no fabricated fanpage link, no Thế Giới Giấy content for Mylan. */
function shopInitial(s){ return (String(s.name||'?').trim().charAt(0)||'?').toUpperCase(); }
function shopLogoHTML(s, compact){
  // v101: the rut gon 5 cot — shop khong logo hien ten san pham ban trong
  // o anh thay cho chu cai dau (chi khi goi voi compact=true, tuc the danh
  // sach; trang chi tiet shop + fallback anh loi giu chu cai dau). Truong
  // product trong hoac 'Chưa cập nhật' thi giu chu cai dau.
  if(!s.logo){
    if(compact && hasReal(s.product)) return '<span class="card-compact-noimg" aria-hidden="true"><span>🛍️ '+esc(s.product)+'</span></span>';
    return '<span class="shop-initial" aria-hidden="true">'+esc(shopInitial(s))+'</span>';
  }
  var fit = s.logoFit==='contain' ? 'shop-logo--contain' : 'shop-logo--cover';
  var init = esc(shopInitial(s));
  return '<img class="shop-logo '+fit+'" src="'+esc(s.logo)+'" alt="Logo '+esc(s.name)+'" loading="lazy" onerror="this.outerHTML=\'<span class=shop-initial>'+init+'</span>\'">';
}
/* Shop decision block (v32, v37): same "5-second card" pattern as decisionHTML
   for models — salary / province / field / channels / requirements up front.
   v37: ALWAYS render all 4 boxes + the requirements box, even when a value is
   missing (shown muted as "Chưa cập nhật"). v32 hid empty values, which made
   the inner blocks start at different heights in every row, so the buttons
   never lined up (visual QA 05/11: e.g. Javata had only a "Tỉnh" box, its
   "Yêu cầu chính" started ~90px higher than its neighbours'). A salary
   starting with "Thỏa thuận" shows "Thỏa thuận" in the box (the grey chip in
   the tags row stays); the full salary text stays on the detail page. */
function shopDecisionHTML(s){
  var sal = hasReal(s.salary) ? esc(s.salary) : 'Chưa cập nhật';
  var prov = hasReal(s.province) ? esc(s.province) : 'Chưa cập nhật';
  var field = hasReal(s.product) ? esc(s.product) : 'Chưa cập nhật';
  var chan = hasReal(s.channels) ? esc(s.channels) : 'Chưa cập nhật';
  var req = hasReal(s.req) ? esc(s.req) : 'Chưa cập nhật';
  var miss = function(v){ return v === 'Chưa cập nhật' ? ' muted' : ''; };
  return '<div class="decision">'
  + '<div class="decision-row">'
  + '<div class="decision-item"><span class="decision-label">💰 Lương</span><b class="decision-value'+miss(sal)+'">'+sal+'</b></div>'
  + '<div class="decision-item"><span class="decision-label">📍 Tỉnh</span><span class="decision-value'+miss(prov)+'">'+prov+'</span></div>'
  + '</div>'
  + '<div class="decision-row">'
  + '<div class="decision-item"><span class="decision-label">🎯 Lĩnh vực livestream</span><span class="decision-value'+miss(field)+'">'+field+'</span></div>'
  + '<div class="decision-item"><span class="decision-label">📺 Kênh livestream</span><span class="decision-value'+miss(chan)+'">'+chan+'</span></div>'
  + '</div>'
  + '<div class="decision-exp"><span class="decision-label">Yêu cầu chính</span><span class="decision-value'+miss(req)+'">'+req+'</span></div>'
  + '</div>';
}
function shopCardHTML(s){
  // v99 (§1c): the shop rut gon — logo/chu cai dau 46/51 + ten overlay
  // + dung 2 dong (noi muon tuyen, muc luong de xuat; thieu luong thi
  // "Thoa thuan") + nut sao. Chi tiet day du chi con o trang chi tiet.
  var url='chi-tiet-shop.html?id='+s.id;
  return '<article class="shop-card card-compact" id="'+esc(s.id)+'" data-v2s-id="'+esc(s.id)+'">'
  + '<a class="card-compact-photo card-compact-photo--shop" href="'+url+'">'+shopLogoHTML(s, true)+'<span class="card-compact-name"><span>'+esc(s.name)+'</span></span></a>'
  + starButtonHTML('shop_profile', s.id)
  + '<div class="card-compact-lines"><p class="card-compact-line">'+shopLocationLine(s)+'</p><p class="card-compact-line">'+shopSalaryLine(s)+'</p></div>'
  + '</article>';
}
function sortShopsNewest(list){
  return list.slice().sort(function(a,b){ return (a.date||'')>(b.date||'')?-1:((a.date||'')<(b.date||'')?1:0); });
}
function withPhotoFirst(list){
  // Downloaded real photos first (7), then profiles whose original post has a photo
  // but whose file was not downloaded yet (labelled "Có ảnh trong bài gốc"), then the rest.
  return list.filter(function(m){return m.photoUrl;})
    .concat(list.filter(function(m){return !m.photoUrl && m.photoHas;}))
    .concat(list.filter(function(m){return !m.photoHas;}));
}
/* v152: xoay 4 lan/ngay, moi 6 tieng (cua so 00:00 / 06:00 / 12:00 / 18:00
   gio VN). Thay the xoay 3 lan/ngay moi 8 tieng (v64) — nguoi dung chot
   15:50 ngay 11/11: BO UU TIEN CO ANH — xoay random tu nhien toan bo danh
   sach, khong nhom theo tier anh (photoTier) hay logo (logoTier). Thu tu
   goc truoc khi xoay giu nguyen (mau: views|comments giam dan; shop: moi
   nhat truoc). On dinh trong cung cua so; khong doi du lieu hay tieu de.
   Bai ghim tra tien KHONG xoay: applyPinnedOrder chay sau khi render, dua
   ghim len truoc theo pinned_until giam dan. */
function dayOfYear(d){ d = d || new Date(); var start = new Date(d.getFullYear(), 0, 0); return Math.floor((d - start) / 86400000); }
function window6h(d){ d = d || new Date(); return Math.floor((d.getTime() + 7*3600*1000) / (6*3600*1000)); }
function rotateArr(list, offset){ var n = list.length; if(!n) return list.slice(); var k = ((offset % n) + n) % n; return list.slice(k).concat(list.slice(0, k)); }
function photoTier(m){ return m.photoUrl ? 'a' : (m.photoHas ? 'b' : 'c'); }
function rotateWindow(list, date){
  return rotateArr(list || [], window6h(date));
}
function rotateDaily(list, date){ return rotateWindow(list, date); }
/* v152 (quy tắc người dùng chốt 15:50 ngày 11/11 — BO UU TIEN CO ANH):
   trang chủ hiện 12 mẫu = 12 mẫu đầu của TOÀN BỘ danh sách đã xoay ngẫu
   nhiên theo cửa sổ 6 tiếng (00:00/06:00/12:00/18:00 giờ VN, window6h +
   rotateArr), không phân biệt có ảnh hay không — mẫu không ảnh có thể
   đứng trước mẫu có ảnh. Thay quy tắc v103/v118 (hàng 1 có ảnh / hàng 2
   không ảnh). Trang danh sách vẫn hiện đủ hồ sơ, không đổi. */
function homeModels12(models, date){
  return rotateArr(models || [], window6h(date)).slice(0, 12);
}
/* v152: thu tu mac dinh cua trang Shop: moi nhat truoc, roi xoay 4 lan/ngay
   theo cua so 6 tieng (00:00/06:00/12:00/18:00 gio VN) — xoay deu TOAN BO
   danh sach, KHONG uu tien shop co logo (bo logoTier, quyet cua user 15:50
   ngay 11/11). Khi nguoi dung chon sap xep (luong/gio) thi KHONG xoay, giu
   dung thu tu sap xep. */
function logoTier(s){ return s.logo ? '0' : '1'; }
function defaultShopOrder(list, date){
  var sorted = sortShopsNewest(list.slice());
  return rotateWindow(sorted, date);
}
/* v152: xoay the tinh (lo / xuong may) tren trang Shop — the la HTML tinh,
   khong qua JS render. Xoay vong trong tung .lot-grid theo cua so 6 tieng
   (00:00/06:00/12:00/18:00 gio VN): 6 the dau (2 hang mac dinh) doi sau
   moi 6 tieng, nhom lo van giu nguyen (khong tron nhom). An toan vi the chi
   la link, khong co listener. Khong lam gi neu trang khong co .lot-grid. */
function rotateStaticGrids(date){
  var win = window6h(date);
  var grids = document.querySelectorAll ? document.querySelectorAll('.lot-grid') : [];
  for(var gi = 0; gi < grids.length; gi++){
    var grid = grids[gi];
    var cards = [];
    for(var ci = 0; ci < grid.children.length; ci++){ cards.push(grid.children[ci]); }
    if(cards.length < 2) continue;
    var k = ((win % cards.length) + cards.length) % cards.length;
    var rotated = cards.slice(k).concat(cards.slice(0, k));
    for(var ri = 0; ri < rotated.length; ri++){ grid.appendChild(rotated[ri]); }
  }
}
/* v64: bo loc cho muc Lo hang xa kho + muc Xuong may (trang Shop). The la
   HTML tinh, loc bang data-attribute tren the:
   - Lo: data-price (VND/cai toi thieu, '' neu khong cong khai),
     data-qty (so mon, ''), data-cat (nam/nu/tre-em/quan-ao/giay-dep/
     my-pham/phu-kien).
   - Xuong: data-moq (so san pham toi thieu, '' neu khong cong khai),
     data-cat (nhu tren + tpcn), data-prov (tinh: TP.HCM/Ha Noi/Binh Duong/
     Nam Dinh/Hung Yen/Dong Nai). Gia tri don xuong hien chua co du lieu gia
     nen dung MOQ lam quy mo don (nho <30 / vua 30-100 / lon >100).
   Quy tac: the thieu du lieu cua 1 tieu chi dang loc thi KHONG khop (an di);
   the khop duoc dua len dau moi grid de quy tac thu gon 2 hang (nth-child)
   van hien dung 6 the khop dau. Khi dang loc, tu mo rong section (bo
   collapsed) + CUON TOI THE KHOP DAU TIEN de xem ket qua ngay; bam Dat lai
   thi tra lai thu tu goc + thu gon lai. */
function inRange(v, key){
  if(key === 'lt20') return v < 20000;
  if(key === '20-50') return v >= 20000 && v <= 50000;
  if(key === '50-100') return v > 50000 && v <= 100000;
  if(key === 'gt100') return v > 100000;
  if(key === 'lt500') return v < 500;
  if(key === '500-1000') return v >= 500 && v <= 1000;
  if(key === '1000-5000') return v > 1000 && v <= 5000;
  if(key === 'gt5000') return v > 5000;
  return true;
}
function lotMatches(card, f){
  if(f.prov && normProv(card.getAttribute('data-prov')) !== normProv(f.prov)) return false;
  if(f.price){
    var p = card.getAttribute('data-price');
    if(p === null || p === '') return false;
    if(!inRange(parseInt(p, 10), f.price)) return false;
  }
  if(f.qty){
    var q = card.getAttribute('data-qty');
    if(q === null || q === '') return false;
    if(!inRange(parseInt(q, 10), f.qty)) return false;
  }
  /* v135: loc Nhom (xa kho/thu mua/cho-san) — chi lo thu thap co
     data-group; the tin user khong co data-group nen khong khop khi
     loc nhom (mau.html khong truyen f.group nen khong anh huong). */
  if(f.group && card.getAttribute('data-group') !== f.group) return false;
  if(f.cat && card.getAttribute('data-cat') !== f.cat) return false;
  return true;
}
function facMatches(card, f){
  if(f.prov && normProv(card.getAttribute('data-prov')) !== normProv(f.prov)) return false;
  if(f.value){
    var m = card.getAttribute('data-moq');
    if(m === null || m === '') return false;
    var mv = parseInt(m, 10);
    if(f.value === 'small' && !(mv < 30)) return false;
    if(f.value === 'medium' && !(mv >= 30 && mv <= 100)) return false;
    if(f.value === 'large' && !(mv > 100)) return false;
  }
  if(f.moq){
    var mm = card.getAttribute('data-moq');
    if(mm === null || mm === '') return false;
    if(parseInt(mm, 10) > parseInt(f.moq, 10)) return false;
  }
  if(f.cat && card.getAttribute('data-cat') !== f.cat) return false;
  return true;
}
/* v72: nut mo/dong bo loc tren mobile (<=600px). Nut chi hien tren mobile
   (CSS .filter-toggle); desktop bo loc luon mo nen nut an, khong doi hanh vi.
   Bam nut: doi class .filters-open tren section chua nut; cap nhat
   aria-expanded + nhan nut. Sau khi ap dung bo loc thi gap lai (goi tu cac
   handler apply) de thay ket qua ngay, kieu san TMDT. */
function filterSectionOf(btn){
  var el = btn;
  if(el && el.closest){ var s = el.closest('section'); if(s) return s; }
  while(el){ if(el.tagName && String(el.tagName).toLowerCase() === 'section') return el; el = el.parentElement || el.parentNode; }
  return null;
}
function initFilterToggle(){
  var btns = (document.querySelectorAll) ? document.querySelectorAll('.filter-toggle') : [];
  for(var i = 0; i < btns.length; i++){
    (function(btn){
      /* v78 C2: chi gan handler 1 lan cho moi nut. Dispatcher goi ca
         initList() (trang Mau) lan initShops() (moi trang) — trang Mau bi
         gan 2 listener: bam 1 lan toggle 2 lan (mo roi dong ngay) nen
         .filter-card mai display:none, nut khong doi nhan. */
      if(btn._filterToggleBound) return;
      btn._filterToggleBound = true;
      btn.addEventListener('click', function(){
        var sec = filterSectionOf(btn);
        if(!sec) return;
        if(!btn._label) btn._label = btn.textContent;
        var open = sec.classList.toggle('filters-open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        btn.textContent = open ? '✕ Ẩn bộ lọc' : btn._label;
      });
    })(btns[i]);
  }
}
function closeFilters(sec){
  if(!sec || !sec.classList) return;
  sec.classList.remove('filters-open');
  var btn = (sec.querySelector) ? sec.querySelector('.filter-toggle') : null;
  if(btn){ btn.setAttribute('aria-expanded', 'false'); if(btn._label) btn.textContent = btn._label; }
}
function closeFilterOf(btn){ var sec = filterSectionOf(btn); if(sec) closeFilters(sec); }
/* v75: FAQ trang chu chi hien 3 cau dau; nut "Xem thêm câu hỏi" mo/thu gon
   cac cau con lai. Pattern giong nut Xem them lo/xuong: section bat dau co
   class .collapsed, cac .step tu cau 4 mang class .faq-extra, CSS an khi
   section collapsed; bam nut doi class + aria-expanded + nhan nut. */
function initFaqToggle(){
  var sec = document.getElementById('faq');
  if(!sec) return;
  var btn = document.getElementById('faqMoreBtn');
  if(!btn) return;
  btn.addEventListener('click', function(){
    var collapsed = sec.classList.toggle('collapsed');
    var open = !collapsed;
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    btn.textContent = open ? 'Thu gọn ↑' : 'Xem thêm câu hỏi ↓';
  });
}
// v91 (9): bảng "Chưa có dữ liệu" thống nhất cho mọi bộ lọc — banner rõ
// ràng (class .empty-state) + hướng dẫn nới bộ lọc, thay cho các dòng chữ
// thường rời rạc trước đây. Người dùng dặn: lọc 0 kết quả thì phải nhảy
// bảng thông báo "Chưa có dữ liệu" + cuộn tới khu vực kết quả.
function emptyResultsHTML(guidance){
  return '<p class="empty-state" role="status"><b>Chưa có dữ liệu.</b> ' + (guidance || 'Hãy nới bộ lọc hoặc bấm Đặt lại.') + '</p>';
}
function initSectionFilter(opts){
  var section = document.getElementById(opts.sectionId);
  if(!section) return null;
  /* v96: nut Ap dung / Dat lai la tuy chon — trang Shop dung 1 nut chung
     (uniApplyBtn/uniResetBtn) dieu phoi ca lo + xuong nen khong gan nut
     rieng o day; tra ve {apply, reset} de khung chung goi. */
  var applyBtn = opts.applyId ? document.getElementById(opts.applyId) : null;
  var resetBtn = opts.resetId ? document.getElementById(opts.resetId) : null;
  var grids = [];
  var gEls = section.querySelectorAll('.lot-grid');
  for(var gi = 0; gi < gEls.length; gi++){
    var cards = [];
    for(var ci = 0; ci < gEls[gi].children.length; ci++){ cards.push(gEls[gi].children[ci]); }
    grids.push({el: gEls[gi], orig: cards.slice()});
  }
  function setExpanded(open){
    var moreBtn = document.getElementById(opts.moreBtnId);
    if(open){ section.classList.remove('collapsed'); }
    else { section.classList.add('collapsed'); }
    /* v213: 2 muc lop hoc do refreshClassMoreBtn lam chu nut (hien so luong
       con lai / an nut khi het) — khong dat text don o day nua. */
    if(CLASS_MORE[opts.sectionId]){ refreshClassMoreBtn(opts.sectionId); return; }
    if(moreBtn){
      moreBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      moreBtn.textContent = open ? 'Thu gọn ↑' : 'Xem thêm ↓';
    }
  }
  function apply(doScroll){
    var f = opts.readForm();
    /* v214: + priceMin/priceMax — loc chi theo khoang gia (khong chon tinh
       nao) van la loc dang hoat dong: hien dong dem + bang "Chua co du lieu"
       khi 0 ket qua + mo rong section. Truoc day active khong tinh gia nen
       dong dem rong khi chi loc gia. */
    var active = !!(f.price || f.qty || f.prov || f.value || f.moq || f.cat || f.group || f.logisticsOption || f.priceMin != null || f.priceMax != null); /* v179: + logisticsOption (5 danh muc moi) */
    var total = 0, first = null;
    grids.forEach(function(g){
      var matched = [], rest = [];
      g.orig.forEach(function(card){
        if(opts.matches(card, f)){ matched.push(card); } else { rest.push(card); }
      });
      /* v135: sap xep (opts.sort tra comparator theo form; khong co thi
         giu thu tu goc). Sap xep chi doi thu tu the khop, khong doi so
         luong — rieng cho bo loc trang Lo/Xuong. */
      if(opts.sort){
        var cmp = opts.sort(f);
        if(cmp) matched.sort(cmp);
      }
      matched.forEach(function(card){ g.el.appendChild(card); card.classList.remove('lot-filtered-out'); });
      rest.forEach(function(card){ g.el.appendChild(card); card.classList.add('lot-filtered-out'); });
      total += matched.length;
      if(!first && matched.length) first = matched[0];
    });
    var countEl = document.getElementById(opts.countId);
    if(countEl) countEl.textContent = active ? (total + ' ' + opts.label + ' khớp bộ lọc') : '';
    var emptyEl = document.getElementById(opts.emptyId);
    if(emptyEl) emptyEl.hidden = !(active && total === 0);
    if(active){ setExpanded(true); }
    /* v72: mobile — gap bo loc sau khi ap dung de thay ket qua ngay. */
    closeFilterOf(applyBtn);
    var target = first || section;
    // v91 (9): 0 kết quả → cuộn tới đúng bảng "Chưa có dữ liệu" (có
    // scroll-margin để header sticky không che).
    if (!first && emptyEl && !emptyEl.hidden) target = emptyEl;
    // v213 (anh Thọ dặn 23:58 ngày 13/11 — TAT CA muc loc sau khi Ap dung
    // ra ket qua thi TU CUON toi ket qua; ghi de phan cam cuon khi Ap dung
    // cua v207): chi cuon khi apply() duoc goi TU NUT Ap dung (doScroll=true)
    // hoac section khong phai muc moi. Bam hang muc/switch/?newobj=/Dat lai
    // goi apply() khong truyen doScroll nen VAN KHONG cuon (giữ v207).
    // Section muc moi (noScroll) KHONG cuon khi goi tu duong khac.
    if((doScroll === true || !opts.noScroll) && target.scrollIntoView){ target.scrollIntoView({behavior: 'smooth', block: 'start'}); }
  }
  function reset(){
    grids.forEach(function(g){
      g.orig.forEach(function(card){ g.el.appendChild(card); card.classList.remove('lot-filtered-out'); });
    });
    var sels = section.querySelectorAll('select');
    for(var si = 0; si < sels.length; si++){ sels[si].value = ''; }
    /* v67: khoi loc da chuyen len dau trang (ngoai section) — reset them select trong khoi loc theo id */
    var fEl = opts.filterId ? document.getElementById(opts.filterId) : null;
    if(fEl){ var fSels = fEl.querySelectorAll('select'); for(var fi = 0; fi < fSels.length; fi++){ fSels[fi].value = ''; } }
    var countEl = document.getElementById(opts.countId);
    if(countEl) countEl.textContent = '';
    var emptyEl = document.getElementById(opts.emptyId);
    if(emptyEl) emptyEl.hidden = true;
    setExpanded(false);
  }
  if(applyBtn) applyBtn.addEventListener('click', function(){ return gateFilterApply(opts.pointsCategory || 'lot', pointsPageName(), apply, applyBtn); });
  if(resetBtn) resetBtn.addEventListener('click', reset);
  // v124: chụp lại danh sách thẻ trong lưới (dùng khi tin user tải xong
  // mới chen vào lưới sau khi bộ lọc đã khởi tạo — nếu không, tin user
  // không lọt vào `orig` nên bộ lọc không lọc được chúng).
  function refresh(){
    grids.forEach(function(g){
      var cards = [];
      for(var ci = 0; ci < g.el.children.length; ci++){ cards.push(g.el.children[ci]); }
      g.orig = cards.slice();
    });
  }
  return {apply: apply, reset: reset, refresh: refresh};
}
function initLotFilter(){
  /* v96: doc tu khung loc chung (fUni*); dem + thong bao dung chung
     (uniCount/uniEmpty); khong gan nut rieng — khung chung dieu phoi. */
  return initSectionFilter({
    sectionId: 'lo-hang-xa-kho', moreBtnId: 'lotMoreBtn', filterId: 'uniFilter', pointsCategory: 'lot',
    countId: 'uniCount', emptyId: 'uniEmpty', label: 'lô',
    readForm: function(){
      var cat = uniCatToLotFac(document.getElementById('fUniCat').value);
      return {
        // v111: lo cung loc theo tinh (truoc day readForm khong doc
        // fUniProv nen chon tinh khong loc gi); tinh quet tu tieu de/meta.
        prov: document.getElementById('fUniProv').value,
        price: document.getElementById('fUniLotPrice').value,
        qty: document.getElementById('fUniLotQty').value,
        cat: cat === null ? '__none__' : cat
      };
    },
    matches: lotMatches
  });
}
function initFactoryFilter(){
  /* v96: nhu tren; tinh doi 'TP. Hồ Chí Minh' -> 'TP.HCM' cho data-prov. */
  return initSectionFilter({
    sectionId: 'xuong-may-gia-cong', moreBtnId: 'factoryMoreBtn', filterId: 'uniFilter', pointsCategory: 'factory',
    countId: 'uniCount', emptyId: 'uniEmpty', label: 'xưởng',
    readForm: function(){
      var cat = uniCatToLotFac(document.getElementById('fUniCat').value);
      return {
        // v111: gui nguyen gia tri tinh (ten moi sau sap nhap); facMatches
        // quy ca hai ve bang normProv (TP.HCM/Binh Duong cu -> TP. HCM...).
        prov: document.getElementById('fUniProv').value,
        value: document.getElementById('fUniFacValue').value,
        moq: document.getElementById('fUniFacMoq').value,
        cat: cat === null ? '__none__' : cat
      };
    },
    matches: facMatches
  });
}
/* v135: bo loc rieng cho trang danh-sach-lo.html / danh-sach-xuong.html
   (chuan v98: khung 2 hang x 6 o + 3 nut chon doi tuong .uni-cat-switch).
   Tai dung initSectionFilter + lotMatches/facMatches — chi them:
   - o Nhom (lo) va o Sap xep (ca hai, qua opts.sort moi them vao
     initSectionFilter);
   - dem so that trong () cho moi option (quy tac v103);
   - nut doi tuong la <a> dan thang toi 3 trang (khong dung
     initUniCatSwitch — trang rieng khong co khung loc chung).
   Goi tu inline script cua trang, SAU renderLotSections() (bo loc can
   chup danh sach the) va TRUOC loadUserListings(controller) de tin user
   chen vao duoc refresh dung controller. Tra ve controller (null neu
   trang khong co bo loc — de inline script van chay duoc o trang khac). */
function lotSortComparator(key){
  function numAttr(card, attr, missing){
    var v = card.getAttribute(attr);
    if(v === null || v === '') return missing;
    var n = parseInt(v, 10);
    return isNaN(n) ? missing : n;
  }
  if(key === 'price-asc') return function(a, b){ return numAttr(a, 'data-price', Infinity) - numAttr(b, 'data-price', Infinity); };
  if(key === 'price-desc') return function(a, b){ return numAttr(b, 'data-price', -Infinity) - numAttr(a, 'data-price', -Infinity); };
  if(key === 'qty-desc') return function(a, b){ return numAttr(b, 'data-qty', -Infinity) - numAttr(a, 'data-qty', -Infinity); };
  if(key === 'qty-asc') return function(a, b){ return numAttr(a, 'data-qty', Infinity) - numAttr(b, 'data-qty', Infinity); };
  return null;
}
function facSortComparator(key){
  function numAttr(card, attr, missing){
    var v = card.getAttribute(attr);
    if(v === null || v === '') return missing;
    var n = parseInt(v, 10);
    return isNaN(n) ? missing : n;
  }
  if(key === 'moq-asc') return function(a, b){ return numAttr(a, 'data-moq', Infinity) - numAttr(b, 'data-moq', Infinity); };
  if(key === 'moq-desc') return function(a, b){ return numAttr(b, 'data-moq', -Infinity) - numAttr(a, 'data-moq', -Infinity); };
  return null;
}
function initLotPageFilter(){
  if(typeof document === 'undefined' || !document.getElementById('lotFilter')) return null;
  var up = document.getElementById('fLotProv');
  if(up) applyOptionCounts(up, function(v){ return uniProvCount('lot', v); }, uniTotal('lot'));
  var uc = document.getElementById('fLotCat');
  if(uc) applyOptionCounts(uc, function(v){ return uniCatCount('lot', v); }, uniTotal('lot'));
  var upr = document.getElementById('fLotPrice');
  if(upr) applyOptionCounts(upr, function(v){ var n = 0; (D.lots || []).forEach(function(l){ if(l.priceNum != null && inRange(l.priceNum, v)) n++; }); return n; }, (D.lots || []).length);
  var uq = document.getElementById('fLotQty');
  if(uq) applyOptionCounts(uq, function(v){ var n = 0; (D.lots || []).forEach(function(l){ if(l.qty != null && inRange(l.qty, v)) n++; }); return n; }, (D.lots || []).length);
  var ug = document.getElementById('fLotGroup');
  if(ug) applyOptionCounts(ug, function(v){ var n = 0; (D.lots || []).forEach(function(l){ if(String(l.group) === v) n++; }); return n; }, (D.lots || []).length);
  initFilterToggle();
  return initSectionFilter({
    sectionId: 'lo-hang-xa-kho', moreBtnId: 'lotMoreBtn', filterId: 'lotFilter', pointsCategory: 'lot',
    countId: 'lotCount', emptyId: 'lotEmpty', label: 'lô',
    applyId: 'lotApplyBtn', resetId: 'lotResetBtn',
    readForm: function(){
      return {
        prov: elVal('fLotProv'),
        price: elVal('fLotPrice'),
        qty: elVal('fLotQty'),
        group: elVal('fLotGroup'),
        /* v135: cat lo luu bang ma uni (giong data-cat) nen truyen thang
           ma — khong qua uniCatToLotFac vi ham do khong map 'gia-dung' /
           'khac' (3+1 lo that) nen loc chung tren mau.html bo sot 4 lo. */
        cat: elVal('fLotCat')
      };
    },
    matches: lotMatches,
    sort: function(){ return lotSortComparator(elVal('fLotSort')); }
  });
}
function initFactoryPageFilter(){
  if(typeof document === 'undefined' || !document.getElementById('facFilter')) return null;
  var up = document.getElementById('fFacProv');
  if(up) applyOptionCounts(up, function(v){ return uniProvCount('factory', v); }, uniTotal('factory'));
  var uc = document.getElementById('fFacCat');
  if(uc) applyOptionCounts(uc, function(v){ return uniCatCount('factory', v); }, uniTotal('factory'));
  var um = document.getElementById('fFacMoq');
  if(um) applyOptionCounts(um, function(v){ var n = 0; (D.factories || []).forEach(function(f){ if(f.moq != null && f.moq <= parseInt(v, 10)) n++; }); return n; }, (D.factories || []).length);
  initFilterToggle();
  return initSectionFilter({
    sectionId: 'xuong-may-gia-cong', moreBtnId: 'factoryMoreBtn', filterId: 'facFilter', pointsCategory: 'factory',
    countId: 'facCount', emptyId: 'facEmpty', label: 'xưởng',
    applyId: 'facApplyBtn', resetId: 'facResetBtn',
    readForm: function(){
      return {
        prov: elVal('fFacProv'),
        moq: elVal('fFacMoq'),
        cat: elVal('fFacCat')
      };
    },
    matches: facMatches,
    sort: function(){ return facSortComparator(elVal('fFacSort')); }
  });
}
/* v135: khung xem chi tiet lo/xuong/kiot TREN TRANG (modal). Truoc day
   bam anh the la ra thang link goc (target _blank); gio bam the (anh)
   mo modal hien day du thong tin, link goc chi con trong nut phu
   "Xem bai goc" (+ dong "Chi tiet" khi thieu dia diem, theo quy tac
   fallback 08/11). Tin user KHONG qua modal — handler rieng cua tin
   user (toggleUserListingPanel) van mo panel cua no. Sao + binh luan
   dung uy thac cap document san co (initStars, initCardComments) nen
   chen dong van chay.
   v139 (11/11/2026): mo rong thanh khung chi tiet DUNG CHUNG cho ca 5
   loai (mau / shop / lo / xuong / kiot) — bam anh the mau/shop cung mo
   cung 1 modal; nut "Xem day du" dan toi trang chi tiet rieng. */
function findLotFactoryKiot(id){
  if(!id) return null;
  var lists = [['lot', D.lots || []], ['factory', D.factories || []], ['kiot', D.kiots || []]];
  for(var i = 0; i < lists.length; i++){
    var arr = lists[i][1];
    for(var j = 0; j < arr.length; j++){
      if(arr[j] && arr[j].id === id) return {kind: lists[i][0], item: arr[j]};
    }
  }
  return null;
}
/* v139: tim 1 muc bat ky trong 5 loai cho khung chi tiet dung chung
   (mau / shop / lo / xuong / kiot) — mo rong findLotFactoryKiot them
   mau + shop. Thu tu: mau -> shop -> lo/xuong/kiot (id cac loai khong
   trung nhau: th- / sh- / lot- / fac- / kiot-). */
function findDetailItem(id){
  if(!id) return null;
  var m = (D.models || []).filter(function(x){ return x && x.id === id; })[0];
  if(m) return {kind: 'model', item: m};
  var s = (D.shops || []).filter(function(x){ return x && x.id === id; })[0];
  if(s) return {kind: 'shop', item: s};
  /* v179: 5 danh muc doi tuong moi — kind = type cua muc (vd 'classesLive'). */
  for(var ni = 0; ni < NEWOBJ_ARRAYS.length; ni++){
    var arr = D[NEWOBJ_ARRAYS[ni]] || [];
    for(var nj = 0; nj < arr.length; nj++){
      if(arr[nj] && arr[nj].id === id) return {kind: arr[nj].type, item: arr[nj]};
    }
  }
  return findLotFactoryKiot(id);
}
/* v139: khung chi tiet DUNG CHUNG cho ca 5 loai (mau / shop / lo / xuong /
   kiot) — 1 markup (.detail-overlay/.detail-box) + 1 ham mo. Truoc day
   chi co lo/xuong/kiot; mau/shop mo trang chi tiet rieng. Cac truong
   hien trong modal lay Y NGUYEN tu trang chi tiet cua tung loai
   (initDetail / initShopDetail); nut "Xem day du" dan toi trang chi
   tiet do (lien he + binh luan + ho so khac van o trang day du). */
function lotFactoryKiotDetailHTML(kind, item){
  var isNewObj = !!(kind && NEWOBJ_TYPES[kind]); /* v179: 5 danh muc doi tuong moi */
  var title = kind === 'model' ? ((item.province || '') + ' — ' + (item.name || '')) : (item.title || item.name || 'Chi tiết');
  var icon = isNewObj ? NEWOBJ_TYPES[kind].icon : kind === 'factory' ? '🏭' : kind === 'kiot' ? '🏪' : kind === 'model' ? '👤' : kind === 'shop' ? '🛍️' : '📦';
  var photoLabel = '';
  if(kind === 'model') photoLabel = hasReal(item.cat) ? item.cat : 'Mẫu livestream';
  else if(kind === 'shop') photoLabel = hasReal(item.product) ? item.product : 'Shop tuyển mẫu';
  else if(isNewObj) photoLabel = NEWOBJ_TYPES[kind].label;
  else if(kind === 'factory') photoLabel = hasReal(item.cat) ? catLabel(item.cat) : 'Xưởng gia công';
  else if(kind === 'kiot') photoLabel = hasReal(item.cat) ? catLabel(item.cat) : 'Kiot thanh lý';
  else photoLabel = (item.group === 2 ? 'Thu mua: ' : 'Xả kho: ') + (hasReal(item.cat) ? catLabel(item.cat) : 'Lô hàng');
  var facts = '';
  if(kind === 'model'){
    facts += '<div class="fact"><b>Tỉnh / nơi muốn làm việc</b><span>' + esc(item.province) + '</span></div>';
    facts += '<div class="fact"><b>Giỏi livestream nhất</b><span>' + esc(item.cat) + '</span></div>';
    facts += '<div class="fact"><b>Lương mong muốn</b><span>' + esc(item.salary) + '</span></div>';
    facts += '<div class="fact"><b>Lịch làm việc</b><span>' + esc(item.schedule) + '</span></div>';
    facts += '<div class="fact"><b>Doanh thu cao nhất</b><span>' + esc(revenueText(item)) + '</span></div>';
    facts += '<div class="fact"><b>Chiều cao / cân nặng</b><span>' + esc(item.height) + '</span></div>';
    facts += '<div class="fact"><b>Đánh giá</b><span>' + esc(item.rating) + '</span></div>';
    facts += '<div class="fact"><b>Kinh nghiệm</b><span>' + esc(item.exp) + '</span></div>';
  } else if(kind === 'shop'){
    facts += '<div class="fact"><b>Tỉnh / thành phố</b><span>' + esc(item.province) + '</span></div>';
    facts += '<div class="fact"><b>Quận / huyện</b><span>' + esc(item.district) + '</span></div>';
    facts += '<div class="fact"><b>Mặt hàng</b><span>' + esc(item.product) + '</span></div>';
    facts += '<div class="fact"><b>Mức lương</b><span>' + esc(item.salary) + '</span></div>';
    facts += '<div class="fact"><b>Yêu cầu chính</b><span>' + esc(item.req) + '</span></div>';
    facts += '<div class="fact"><b>Kênh livestream</b><span>' + esc(item.channels) + '</span></div>';
  } else if(kind === 'lot'){
    facts += '<div class="fact"><b>Địa điểm</b><span>' + lotLocationLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Tổng giá trị</b><span>' + lotValueLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Loại mặt hàng</b><span>' + esc(hasReal(item.cat) ? catLabel(item.cat) : 'Chưa cập nhật') + '</span></div>';
    facts += '<div class="fact"><b>Số lượng</b><span>' + (item.qty == null ? 'Chưa cập nhật' : Number(item.qty).toLocaleString('vi-VN') + ' món') + '</span></div>';
    facts += '<div class="fact"><b>Nhóm</b><span>' + (item.group === 2 ? 'Thu mua' : item.group === 3 ? 'Chợ / Sàn' : 'Xả kho') + '</span></div>';
  } else if(kind === 'factory'){
    facts += '<div class="fact"><b>Địa điểm</b><span>' + factoryLocationLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Loại gia công</b><span>' + factoryItemsLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Số lượng tối thiểu (MOQ)</b><span>' + (item.moq == null ? 'Không công khai' : Number(item.moq).toLocaleString('vi-VN') + ' sản phẩm') + '</span></div>';
  } else if(isNewObj){
    /* v179: 5 danh muc moi — don vi to chuc/chu, gia theo nhan gia, tinh, option logistics, ngay dang/het han. */
    facts += '<div class="fact"><b>Đơn vị tổ chức / chủ</b><span>' + esc(item.provider || 'Chưa cập nhật') + '</span></div>';
    facts += '<div class="fact"><b>' + esc(item.priceLabel || NEWOBJ_TYPES[kind].priceLabel || 'Giá') + '</b><span>' + esc(newObjPriceText(item)) + '</span></div>';
    facts += '<div class="fact"><b>Tỉnh / thành phố</b><span>' + esc(item.province || 'Chưa cập nhật') + '</span></div>';
    if(kind === 'logistics' && item.logisticsOption) facts += '<div class="fact"><b>Hình thức vận chuyển</b><span>' + esc(NEWOBJ_LOGISTICS_OPTIONS[item.logisticsOption] || item.logisticsOption) + '</span></div>';
    facts += '<div class="fact"><b>Ngày đăng</b><span>' + esc(item.dateAdded || '') + '</span></div>';
    facts += '<div class="fact"><b>Hết hạn</b><span>' + esc(item.expiresAt || '') + '</span></div>';
  } else {
    facts += '<div class="fact"><b>Địa điểm</b><span>' + kiotLocationLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Loại hình kinh doanh</b><span>' + kiotTypeLine(item) + '</span></div>';
    facts += '<div class="fact"><b>Giá sang nhượng</b><span>' + esc(item.price || 'Thoả thuận') + '</span></div>';
  }
  facts += '<div class="fact"><b>Ngày đăng</b><span>' + esc(item.date || '') + '</span></div>';
  // Anh dai dien: mau dung anh ho so, shop dung logo, lo/xuong/kiot dung anh bai goc, 5 loai moi dung avatar (bat buoc).
  var photo = kind === 'model' ? photoHTML(item) : kind === 'shop' ? shopLogoHTML(item) : isNewObj ? '<img src="' + esc(item.avatar) + '" alt="Ảnh đại diện của ' + esc(item.name || '') + '" loading="lazy" onerror="this.remove()">' : lotFactoryPhotoHTML(item, title);
  // Meta: mau dung tieu de ho so, shop dung mat hang + tinh, lo/xuong/kiot dung meta san co, 5 loai moi dung don vi + tinh.
  var meta = kind === 'model' ? item.title : kind === 'shop' ? ((hasReal(item.product) ? '🎯 ' + item.product + ' · ' : '') + '📍 ' + (item.province || '')) : isNewObj ? ((item.provider || '') + (item.province ? ' · 📍 ' + item.province : '')) : item.meta;
  // Nut hanh dong: mau/shop co nut "Xem day du" dan toi trang chi tiet
  // (lien he + binh luan + ho so khac van o do); nut sao dung loai
  // 'model_profile'/'shop_profile' nhu trang chi tiet (dong bo sao).
  var origin = '';
  var fullLink = '';
  if(kind === 'model'){
    fullLink = '<a class="btn btn-primary" href="ho-so.html?id=' + esc(item.id) + '">Xem hồ sơ đầy đủ →</a>';
    if(hasReal(item.src)) origin = '<a class="btn btn-ghost" href="' + esc(item.src) + '" target="_blank" rel="noopener">Xem bài gốc →</a>';
  } else if(kind === 'shop'){
    fullLink = '<a class="btn btn-primary" href="chi-tiet-shop.html?id=' + esc(item.id) + '">Xem shop đầy đủ →</a>';
    if(hasReal(item.src)) origin = '<a class="btn btn-ghost" href="' + esc(item.src) + '" target="_blank" rel="noopener">Xem bài tuyển gốc →</a>';
  } else if(isNewObj && hasReal(item.sourceUrl)){
    origin = '<a class="btn btn-primary" href="' + esc(item.sourceUrl) + '" target="_blank" rel="noopener">Xem bài gốc →</a>';
  } else if(hasReal(item.url)){
    origin = '<a class="btn btn-primary" href="' + esc(item.url) + '" target="_blank" rel="noopener">Xem bài gốc →</a>';
  }
  var note = kind === 'model' ? '⚠ CHƯA XÁC NHẬN ĐỒNG Ý ĐĂNG WEB — hồ sơ từ bài đăng công khai, sẽ xóa khi có hồ sơ mới tự đăng ký thay thế.'
    : kind === 'shop' ? 'Shop có thể yêu cầu cập nhật hoặc gỡ tin qua nút Góp ý (💬).'
    : hasReal(item.label) ? esc(item.label) : 'Tin đăng được tổng hợp từ bài đăng công khai trên mạng. Ver2Solution chưa xác thực thông tin trong tin đăng này.';
  var starKind = kind === 'model' ? 'model_profile' : kind === 'shop' ? 'shop_profile' : kind;
  // Binh luan inline chi co o lo/xuong/kiot (nhu cu); mau/shop binh luan
  // o trang chi tiet day du.
  var comments = (kind === 'lot' || kind === 'factory' || kind === 'kiot') ? commentToggleHTML(kind, userListingCommentTargetId(item)) : '';
  return '<div class="detail-modal-photo">' + photo + '<span class="detail-modal-icon" aria-hidden="true">' + icon + '</span><span class="detail-modal-label">' + esc(photoLabel) + '</span></div>'
  + '<h2 id="lfkDetailTitle">' + esc(title) + '</h2>'
  + (hasReal(meta) ? '<p class="detail-meta">' + esc(meta) + '</p>' : '')
  + '<div class="fact-grid">' + facts + '</div>'
  + (isNewObj && hasReal(item.detail) ? '<p style="white-space:pre-wrap;overflow-wrap:break-word">' + esc(item.detail) + '</p>' : '')
  + '<div class="detail-actions">' + (isNewObj ? '' : starButtonHTML(starKind, item.id)) + fullLink + origin + '</div>' /* v179: 5 loai moi chua co nut sao (enum RPC sao chua co cac loai nay) */
  + '<p class="detail-note">' + note + '</p>'
  /* v177: mien tru o cuoi thong tin chi tiet cho ca 5 loai (lo/xuong/kiot
     truoc day chua co; mau/shop modal cung hien nhu trang chi tiet day du).
     Dat sau note, truoc phan binh luan. */
  + '<p class="disclaimer">'+(isNewObj ? DISCLAIMER.replace(' Để ghim hồ sơ này lên top, hãy ấn sao ★ (mỗi sao lên top 60 phút).', '') : DISCLAIMER)+'</p>' /* v179: 5 loai moi khong co nut sao nen bo cau ghim sao khoi mien tru */
  + comments;
}
function openLotFactoryKiotDetail(id){
  var found = findDetailItem(id); // v139: mo rong ca 5 loai (mau/shop/lo/xuong/kiot)
  if(!found) return false;
  var overlay = document.getElementById('lfkDetailOverlay');
  var body = document.getElementById('lfkDetailBody');
  if(!overlay || !body) return false;
  body.innerHTML = lotFactoryKiotDetailHTML(found.kind, found.item);
  overlay.classList.add('open');
  v2sSignupPopup('detail'); // v185: popup goi y dang ky khi xem chi tiet (chi goi y, khong chan).
  return true;
}
function closeLotFactoryKiotDetail(){
  var overlay = document.getElementById('lfkDetailOverlay');
  if(overlay) overlay.classList.remove('open');
}
function initLotFactoryDetail(){
  if(typeof document === 'undefined' || document._v2sLfkDetailBound) return;
  document._v2sLfkDetailBound = true;
  /* Tao overlay 1 lan (neu trang chua co san). */
  if(!document.getElementById('lfkDetailOverlay')){
    var ov = document.createElement('div');
    ov.className = 'detail-overlay';
    ov.id = 'lfkDetailOverlay';
    ov.innerHTML = '<div class="detail-box" role="dialog" aria-modal="true" aria-labelledby="lfkDetailTitle"><button class="detail-close" id="lfkDetailClose" type="button" aria-label="Đóng">✕</button><div id="lfkDetailBody"></div></div>';
    document.body.appendChild(ov);
  }
  document.addEventListener('click', function(e){
    var closeBtn = e.target && e.target.closest ? e.target.closest('#lfkDetailClose') : null;
    if(closeBtn){ closeLotFactoryKiotDetail(); return; }
    if(e.target && e.target.id === 'lfkDetailOverlay'){ closeLotFactoryKiotDetail(); return; }
    /* v139: khung chi tiet dung chung cho ca 5 loai — bam vao anh bat ky
       the nao (mau / shop / lo / xuong / kiot) deu mo cung 1 modal
       (#lfkDetailOverlay). Click thuong, chuot trai, khong phim bo tro
       — giu hanh vi mo tab moi cho Ctrl/middle (link goc van giu). */
    if(e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
    var a = e.target && e.target.closest ? e.target.closest('.card-compact-photo') : null;
    if(!a) return;
    var card = a.closest('article[data-v2s-id]');
    var id = card && card.getAttribute('data-v2s-id');
    if(!id) return;
    /* Tin user: handler rieng (toggleUserListingPanel) xu ly — khong
       cuop, khong chan. */
    if(userListingByCardId[id]) return;
    if(openLotFactoryKiotDetail(id)) e.preventDefault();
  });
  document.addEventListener('keydown', function(e){
    if(e.key === 'Escape') closeLotFactoryKiotDetail();
  });
}
function params(){
  var p={}; try{new URLSearchParams(location.search).forEach(function(v,k){p[k]=v;});}catch(e){} return p;
}/* v45: doc gia tri o loc, an toan khi o khong co tren trang (vd test stub
   DOM chi co cac o cu) — tra ve '' thay vi nem loi. */
function elVal(id){ var el=document.getElementById(id); return el ? el.value : ''; }
function setParams(p){
  var q=new URLSearchParams(); Object.keys(p).forEach(function(k){if(p[k]) q.set(k,p[k]);});
  // v111 (CTA shop): GIU hash (#ho-so-shop, #dang-nhap-shop...) khi ghi URL
  // — truoc day replaceState xoa hash nen nut "Tao ho so shop" mat neo.
  var hash='';
  try { hash = location.hash || ''; } catch (e) {}
  try{history.replaceState(null,'',location.pathname+(q.toString()?'?'+q.toString():'')+hash);}catch(e){}
}
function filterModels(list, f){
  return list.filter(function(m){
    if(f.prov && m.province!==f.prov) return false;
    if(f.cat && m.cat!==f.cat) return false;
    if(f.gender && m.gender!==f.gender) return false;
    /* v43: loc gio lam theo truong shifts (suy ra tu schedule, xem data.js).
       Chi mau co ca do moi hien; shifts rong chi hien khi chon "Tất cả giờ".
       Mau khong co fulltime nen khong ap quyet dinh fulltime-hien-trong-moi-ca
       nhu shop. */
    if(f.shift){ var sh = m.shifts || []; if(sh.indexOf(f.shift) === -1) return false; }
    /* v111 (muc 6): loc theo LOAI LUONG — truoc day filterModels bo qua
       hoan toan f.payType nen chon "Luong theo gio/thang" van tra du 37
       mau. Luong gio = co salaryNum; luong thang dung proxy doanh thu da
       xac minh (giong uniSortToModelSort: monthly -> revenue) vi mau
       khong co truong luong thang rieng. Doi chieu data.js 09/11: chi 3/37
       mau co salaryNum (th-03/th-08/th-11), 0 mau co doanh thu da xac
       minh — nen dem that la gio (3), thang (0). */
    if(f.payType === 'hourly' && typeof m.salaryNum !== 'number') return false;
    if(f.payType === 'monthly' && verifiedRevenue(m) === null) return false;
    /* v45: loc theo gia tri. revMin tinh theo trieu (doanh thu DA XAC
       MINH, v85 M1); mau chua co doanh thu da xac minh bi loai khi co
       nhap — hien 0/20 mau co doanh thu that nen loc nay chua ra ket qua
       cho toi khi co du lieu, dung thiet ke, khong bia du lieu. */
    if(f.revMin != null){ var r = verifiedRevenue(m); if(r === null || r < f.revMin * 1000000) return false; }
    if(f.wageMin != null){ var w = (typeof m.salaryNum === 'number' ? m.salaryNum : null); if(w === null || w < f.wageMin) return false; }
    if(f.q){var hay=(m.name+' '+m.title+' '+m.province+' '+m.cat+' '+m.form+' '+m.exp).toLowerCase(); if(hay.indexOf(f.q.toLowerCase())===-1) return false;}
    return true;
  });
}
function renderPager(el, page, totalPages, total, onPage, perPage, label){
  if(!el) return;
  perPage=perPage||6; label=label||'hồ sơ';
  var html='<button type="button" data-track="chuyen-trang" data-p="'+(page-1)+'"'+(page<=1?' disabled':'')+'>← Trang trước</button>';
  for(var i=1;i<=totalPages;i++) html+='<button type="button" data-track="chuyen-trang" data-p="'+i+'"'+(i===page?' class="current" disabled':'')+'>'+i+'</button>';
  html+='<button type="button" data-track="chuyen-trang" data-p="'+(page+1)+'"'+(page>=totalPages?' disabled':'')+'>Trang sau →</button>';
  html+='<span class="pager-info">Trang '+page+' / '+totalPages+' — đang hiện '+(total===0?0:((page-1)*perPage+1))+'–'+Math.min(page*perPage,total)+' trên tổng số '+total+' '+label+'.</span>';
  el.innerHTML=html;
  el.querySelectorAll('button[data-p]').forEach(function(b){b.addEventListener('click',function(){onPage(parseInt(b.getAttribute('data-p'),10));});});
}
/* v197 (MỚI-MC-10): link "Xem hồ sơ / Xem shop" ở tim-kiem.html trỏ tới
   danh sách kèm hash #<id> — thẻ đích có thể ở trang phân trang khác,
   và thẻ chỉ có data-v2s-id nên neo trình duyệt không tìm được.
   pageOfId: trang (1-based) chứa id trong danh sách đã lọc + đã sắp xếp
   (cùng danh sách render dùng), null nếu không có. Thuần — test qua Node. */
function pageOfId(list, id, perPage){
  if(!id || !Array.isArray(list) || !(perPage > 0)) return null;
  for(var i=0;i<list.length;i++){ if(list[i] && list[i].id === id) return Math.floor(i/perPage)+1; }
  return null;
}
/* Cuộn tới thẻ được hash trỏ tới (id thật, hoặc data-v2s-id để tương thích
   thẻ cũ chưa có id). Gọi sau khi lưới đã render xong — neo trình duyệt
   không tự chạy vì thẻ do JS render sau lúc tải trang. */
function scrollToHashedCard(){
  if(typeof document === 'undefined' || typeof location === 'undefined') return false;
  var h='';
  try{ h=(location.hash||'').replace(/^#/,''); }catch(e){}
  if(!h) return false;
  var el=null;
  try{ el=document.getElementById(h); }catch(e){}
  if(!el && document.querySelector){ try{ el=document.querySelector('[data-v2s-id="'+String(h).replace(/"/g,'')+'"]'); }catch(e){} }
  if(!el || typeof el.scrollIntoView !== 'function') return false;
  el.scrollIntoView({behavior:'auto', block:'start'});
  return true;
}
/* Home: hero search + 2 rows, 8 with-photo first */
/* Articles with their own page (v23): link to our page, not out to the source.
   Older articles without a page still link out to the source as before. */
function articleLink(a){
  if(a.page) return '<a href="'+esc(a.page)+'">'+esc(a.title)+'</a>';
  if(!a.url) return '<strong>'+esc(a.title)+'</strong>';
  if(/^https?:\/\//.test(a.url)) return '<a href="'+esc(a.url)+'" target="_blank" rel="noopener">'+esc(a.title)+'</a>';
  return '<a href="'+esc(a.url)+'">'+esc(a.title)+'</a>';
}
function articleHref(a){ return a.page || a.url || ''; }
function sortByDateDesc(list){
  return list.slice().sort(function(x,y){ return (x.date||'')>(y.date||'')?-1:((x.date||'')<(y.date||'')?1:0); });
}
function articleTarget(a){
  var href = articleHref(a);
  if(!href) return {href:'', blank:false};
  return {href:href, blank:!a.page};
}
function articleTitleHTML(a){
  var tg = articleTarget(a);
  if(!tg.href) return '<strong>'+esc(a.title)+'</strong>';
  return '<a href="'+esc(tg.href)+'"'+(tg.blank?' target="_blank" rel="noopener"':'')+'>'+esc(a.title)+'</a>';
}
/* v230 (L12): anh tin ghim luc dau chi hien mang xanh — loading="lazy" cho MOI
   anh tin ke ca anh dau trang nen trinh duyet tai sau lan ve dau; anh hong
   cung khong co fallback nen xanh mai. eager=true (hang ghim trang chu +
   2 hang dau trang Tin tuc) -> tai ngay + uu tien cao; moi anh tin deu co
   onerror -> thay bang o thuong hieu "2" nhu bai khong anh. */
function articleMediaHTML(a, cls, eager){
  // Bai khong co anh -> o mau thuong hieu + so 2 (khong de trong, khong anh vo).
  if(a.img) return '<img class="'+cls+'" src="'+esc(a.img)+'" alt="'+esc(a.title)+'"'+(eager?' fetchpriority="high"':' loading="lazy"')+' onerror="V20.imgFallback(this)">';
  return '<span class="'+cls+' pin-noimg" aria-hidden="true"><b>2</b></span>';
}
/* v230 (L12): anh tin loi tai/giai ma -> thay the img bang o thuong hieu "2"
   (cung mau bai khong anh), khong de khung xanh trong. Goi tu onerror. */
function imgFallback(img){
  try{
    var s=document.createElement('span');
    s.className=img.className+' pin-noimg';
    s.setAttribute('aria-hidden','true');
    s.innerHTML='<b>2</b>';
    img.replaceWith(s);
  }catch(e){ /* giu nguyen img neu thay the that bai */ }
}
/* Hang ghim (v84): toi da 4 o — bai ghim (pinned:true) len truoc, xep theo
   pinOrder tang dan roi ngay giam dan. Chua du 4 o thi LAP BANG BAI MOI
   THEM VAO WEB GAN NHAT (thu tu them vao = thu tu trong mang articles,
   bai them sau nam CUOI mang nen dao nguoc mang) — KHONG xep theo truong
   date (date la ngay cua bai GOC, bai moi them ve su kien cu van phai len).
   Chi nguoi dung ghim tay (hien chi bai bop-reach); cron bai bao 08:21
   KHONG tu ghim bai moi nua (bai moi pinned:false), de hang tu day. */
function getPinnedRow(list){
  var pinned = (list||[]).filter(function(a){ return !!a.pinned; });
  pinned.sort(function(a, b){
    var ao = (typeof a.pinOrder === 'number') ? a.pinOrder : Infinity;
    var bo = (typeof b.pinOrder === 'number') ? b.pinOrder : Infinity;
    if(ao !== bo) return ao - bo;
    return (a.date||'') > (b.date||'') ? -1 : ((a.date||'') < (b.date||'') ? 1 : 0);
  });
  var newest = (list||[]).slice().reverse(); // v84: moi them vao web = cuoi mang -> dao nguoc (khong xep theo date bai goc)
  var picked = pinned.slice(0, 4);
  for(var i=0; i<newest.length && picked.length<4; i++){
    if(picked.indexOf(newest[i]) === -1) picked.push(newest[i]);
  }
  return picked;
}
/* v100: quy chuan the tin rut gon — 1 anh dai dien nho 16:9 + dung 2 dong
   (dong 1: tieu de, toi da 2 dong co cat ...; dong 2: chuyen muc · ngay).
   Dung CHUNG cho tin-tuc, trang chu (homeNews + homePinned) va hang tin
   trang Mau. Noi dung day du van o trang bai-viet; chi rut gon phan hien
   thi danh sach. So thu tu (neu co) nam goc duoi-trai cua anh, khong them
   dong. */
/* v100: the tin rut gon — 1 anh dai dien + 2 dong thong tin (tieu de + chuyen muc · ngay).
   - withPoints=true (chi danh sach tin-tuc.html): them hang nut diem/ghim v92
     (Thich +1 / Chia se +2 / Ghim len top) NGOAI link bai — day la hang
     hanh dong, khong phai dong thong tin; trang chu + hang tin trang Mau
     khong co hang nut nay (nhu truoc v100). */
/* v111 (muc 5): ngay bai hien du ngay/thang/nam. Du lieu hien dung ISO
   'YYYY-MM-DD' (doi sang DD/MM/YYYY de doc); 2 bai chi co nam '2026'
   (khong co thang/ngay trong data.js) thi giu nguyen '2026' — khong bia
   ngay thang. */
function formatArticleDate(d){
  var s = String(d == null ? '' : d).trim();
  var m = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if(m) return m[3] + '/' + m[2] + '/' + m[1];
  return s || 'Chưa có ngày';
}
function newsCardHTML(a, n, withPoints, eager){
  var tg = articleTarget(a);
  var num = (typeof n === 'number') ? '<span class="pin-num" aria-label="Tin ' + n + '">' + n + '</span>' : '';
  var inner = num + articleMediaHTML(a, 'news-card-img', eager)
    + '<h3>'+esc(a.title)+'</h3>'
    + '<p class="news-card-meta">'+esc(a.cat)+' · '+esc(formatArticleDate(a.date))+'</p>';
  var points = withPoints ? pointsButtonsHTML('article', articleRef(a)) : '';
  // v166 (N10): thêm nút Bình luận cho bài viết — trước đây thẻ tin chỉ
  // có Thích/Chia sẻ/Ghim, trang bài cũng chỉ có chia sẻ FB/Zalo/Copy
  // link nên không có chỗ bình luận dù có dòng mời đăng nhập để bình
  // luận. Dùng chung cơ chế commentToggleHTML (chờ duyệt, +1 xu sau
  // duyệt) như thẻ lô/xưởng/kiot; chỉ hiện cùng chỗ với nút điểm.
  var comments = withPoints ? commentToggleHTML('article', articleRef(a)) : '';
  if(!tg.href) return '<article class="news-card">'+inner+points+comments+'</article>';
  return '<article class="news-card"><a href="'+esc(tg.href)+'"'+(tg.blank?' target="_blank" rel="noopener"':'')+'>'+inner+'</a>'+points+comments+'</article>';
}
/* pinCardHTML giu lai lam bi danh (test cu + code khac goi) — cung mau the rut gon v100. */
/* v230 (L12): the ghim trang chu o dau trang -> anh tai ngay (eager). */
function pinCardHTML(a, n){ return newsCardHTML(a, n, false, true); }
/* v124: hang tin — o 1 = bai duoc xem nhieu nhat (analytics 30 ngay),
   3 o con lai = 3 bai moi nhat. Hang render 4 bai moi nhat truoc
   (dong bo, khong doi fetch), roi nang cap o 1 len bai xem nhieu nhat
   khi analytics ve (bat dong bo, khong lam cham trang). Neu khong co
   bai nao co luot xem trong 2 chuyen muc cua hang thi giu nguyen 4 bai
   moi nhat. Chuyen muc theo chi dao cua anh 10/11: Shop = Livestream +
   Xu hướng; Mau = Đời Sống + Việc Làm; Kiot = Đang hot + Livestream. */
function newsRowNewest(cats,n){
  return (D.articles||[]).map(function(a,i){ return {a:a,i:i}; })
    .filter(function(x){ return cats.indexOf(x.a.cat)!==-1; })
    .sort(function(p,q){ var d=(p.a.date||'')<(q.a.date||'')?1:((p.a.date||'')>(q.a.date||'')?-1:0); return d!==0?d:(q.i-p.i); })
    .slice(0,n).map(function(x){ return x.a; });
}
/* Ham thuan (test duoc): chon bai co luot xem cao nhat trong cats.
   pageviews: map page (khong dau '/') -> so luot xem. Tra null neu
   khong bai nao co luot xem > 0. */
function pickMostViewedArticle(articles,pageviews,cats){
  var best=null,bestN=0;
  (articles||[]).forEach(function(a){
    if(cats.indexOf(a.cat)===-1) return;
    var n=(pageviews&&a.page)?(pageviews[a.page]||0):0;
    if(n>bestN){ bestN=n; best=a; }
  });
  return bestN>0?best:null;
}
var _mostViewedPromise=null;
function fetchMostViewedInCats(cats){
  if(_mostViewedPromise) return _mostViewedPromise;
  _mostViewedPromise=(function(){
    try{
      var cfg=(typeof window!=='undefined'?window.MCLIVESTREAM_SUPABASE_CONFIG:null)||{};
      if(!cfg.url||!cfg.anonKey||typeof fetch==='undefined') return Promise.resolve(null);
      return fetch(cfg.url+'/rest/v1/rpc/get_analytics_summary',{
        method:'POST',
        headers:{'apikey':cfg.anonKey,'Authorization':'Bearer '+cfg.anonKey,'Content-Type':'application/json'},
        body:JSON.stringify({p_days:30})
      }).then(function(res){ return res.ok?res.json():null; }).then(function(rows){
        if(!rows||!rows.length) return null;
        var pv={};
        rows.forEach(function(r){
          if(r&&r.event_type==='pageview'&&r.page&&r.page.indexOf('/bai-viet/')===0){
            var p=r.page.slice(1);
            pv[p]=(pv[p]||0)+(r.event_count||0);
          }
        });
        return pickMostViewedArticle(D.articles,pv,cats);
      }).catch(function(){ return null; });
    }catch(e){ return Promise.resolve(null); }
  })();
  return _mostViewedPromise;
}
function renderNewsRow(row,titleHtml,list){
  row.innerHTML=titleHtml
    + '<div class="news-row-4">'+list.map(function(a){ return newsCardHTML(a); }).join('')+'</div>'
    + '<p style="margin:10px 0 0"><a href="tin-tuc.html">Xem tất cả tin →</a></p>';
}
/* Ham thuan (test duoc): ghep danh sach cuoi — o 1 = bai xem nhieu nhat,
   3 o con lai = 3 bai moi nhat (loai bai xem nhieu nhat neu trung).
   Neu khong co bai xem nhieu nhat thi giu nguyen 4 bai moi nhat. */
function newsRowFinalList(newest,mostViewed){
  if(!mostViewed) return newest.slice(0,4);
  if(newest.length&&newest[0]===mostViewed) return newest.slice(0,4);
  var rest=newest.filter(function(a){ return a!==mostViewed; }).slice(0,3);
  return [mostViewed].concat(rest);
}
/* v154: initNewsRow them opts tuy chon {pinnedKey} — khi co, cac bai co
   co do (vd pinnedShop) duoc dat len dau hang theo shopPinOrder tang dan
   roi date giam dan; cac o con lai lap bang newsRowFinalList(newest loai
   bai ghim, mostViewed) va loc trung, tong toi da 4 o. Khong co opts thi
   hanh vi Y HET nhu cu (hang Mau/Kiot khong doi). */
function initNewsRow(rowId,cats,titleHtml,opts){
  var row=document.getElementById(rowId); if(!row) return;
  var pinnedFirst=[];
  if(opts&&opts.pinnedKey){
    pinnedFirst=(D.articles||[]).filter(function(a){ return !!a[opts.pinnedKey]; });
    pinnedFirst.sort(function(a,b){
      var ao=(typeof a.shopPinOrder==='number')?a.shopPinOrder:Infinity;
      var bo=(typeof b.shopPinOrder==='number')?b.shopPinOrder:Infinity;
      if(ao!==bo) return ao-bo;
      return (a.date||'')>(b.date||'')?-1:((a.date||'')<(b.date||'')?1:0);
    });
  }
  var newest=newsRowNewest(cats,4).filter(function(a){ return pinnedFirst.indexOf(a)===-1; });
  renderNewsRow(row,titleHtml,pinnedFirst.concat(newest).slice(0,4));
  fetchMostViewedInCats(cats).then(function(mv){
    if(!mv) return;
    var rest=newsRowFinalList(newest,mv).filter(function(a){ return pinnedFirst.indexOf(a)===-1; });
    renderNewsRow(row,titleHtml,pinnedFirst.concat(rest).slice(0,4));
  }).catch(function(){ /* giu 4 bai moi nhat */ });
}
/* v100: hang 4 o tin tuc tren trang Danh cho Mau (duoi bo loc, #modelNewsRow
   trong danh-sach-mau.html — vong 2 A3 10/11 dua container ve dung trang Mau).
   2 chuyen muc "Đời Sống" + "Việc Làm" (anh chot 10/11, thay "Dòng tiền").
   v103: tieu de "Xu hướng sống mới" (user chot 21:40 08/11, giu nguyen).
   v124: o 1 = bai xem nhieu nhat, 3 o con lai = 3 bai moi nhat (xem initNewsRow). */
function initModelNewsRow(){
  initNewsRow('modelNewsRow',['Đời Sống','Việc Làm'],
    '<h2><a href="tin-tuc.html" data-track="tieu-de-tin-doi-song-mau">Xu hướng sống mới</a></h2>');
}
/* v154 (anh chot 11/11/2026): hang 4 o tin danh cho Shop (#shopNewsRow
   trong danh-sach-mau.html sau A3 un-swap 10/11) — 2 o dau la 2 bai ghim
   rieng cho Shop (pinnedShop, shopPinOrder): (1) "Quy định Facebook 2026:
   tài khoản bị khóa và cách kháng cáo", (2) "Vì sao 90% Page bị bóp reach
   khi đi share group?...". 2 o sau van la tin Livestream/Xu hướng moi
   nhat (bai xem nhieu nhat len truoc trong phan khong ghim, xem
   initNewsRow). Bai bop-reach dong thoi duoc bo ghim toan cuc
   (pinned:false) nen khong con trong hang ghim trang chu/tin-tuc. */
function initShopNewsRow(){
  initNewsRow('shopNewsRow',['Livestream','Xu hướng'],
    '<h2><a href="tin-tuc.html" data-track="tieu-de-tin-livestream-shop">Livestream &amp; xu hướng</a></h2>',
    {pinnedKey:'pinnedShop'});
}
/* v123: hang 4 o tin "Đang hot & livestream" tren trang Thanh ly Kiot
   (thanh-ly-kiot.html, #kiotNewsRow) — 2 chuyen muc "Đang hot" +
   "Livestream". v124: o 1 = bai xem nhieu nhat, 3 o con lai = 3 bai
   moi nhat (xem initNewsRow). */
function initKiotNewsRow(){
  initNewsRow('kiotNewsRow',['Đang hot','Livestream'],
    '<h2><a href="tin-tuc.html" data-track="tieu-de-tin-hot-kiot">Đang hot &amp; livestream</a></h2>');
}
/* v157: khu tin 3 hang duoi danh sach (giong khu Tin moi trang chu:
   .news-list 2 cot, 6 bai moi nhat theo chuyen muc rieng cua trang). */
function initBottomNewsList(listId,cats){
  var el=document.getElementById(listId); if(!el) return;
  el.innerHTML=newsRowNewest(cats,6).map(function(a){ return newsCardHTML(a); }).join('');
}
/* v41 trust strip: so lieu tinh DONG tu data.js (khong ghi so cung vao HTML).
   Quy tac luong/doanh thu cua mau (user-directed 06/11): doanh thu cao nhat
   (highest_revenue_amount DA XAC MINH, v85 M1) la tieu de khi co du lieu da
   kiem chung; hien tai ca 20 mau deu "Chua cap nhat" nen fallback la luong
   de xuat THAP NHAT (min salaryNum) kem ghi chu doanh thu chua co du lieu.
   Khi 1 mau co doanh thu da xac minh thi code tu chuyen sang hien thi
   doanh thu, khong can sua tay. So tu khai/chuoi topRevenue cu khong tinh.
   Luong shop cao nhat: chi xet luong thang — parse cac so TRUOC cum
   "trieu/thang" (khoang "16–36" -> 36; "Tu 15" -> 15; "8–18" -> 18; phan
   tram hoa hong sau cum do khong tinh). 400+ la hang so cong dong do nguoi
   dung xac nhan, khong bao gio tinh tu data.js. */
function fmtVnd(n){ return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
function parseMonthlyMax(s){
  if(!s || s.indexOf('/tháng') < 0) return null;
  // Dang "triệu/tháng": so la trieu (vd "16–36" -> 36; "Tu 15" -> 15).
  // Chi lay khoang so NGAY TRUOC "triệu/tháng" (vd "9–12 triệu/tháng" -> 12),
  // khong quet ca dau chuoi — keo nham tien thuong VND dung truoc (sh-200:
  // "thuong KPI 500.000–1.000.000d" bi doc thanh 500 trieu, v41, sua 13/11/2026).
  // Lay max qua MOI khoang "…triệu/tháng" trong chuoi (sh-219 co 2 vai tro:
  // host 10–30 + tro ly 6–8 -> 30); cho phep dau "+" ("20+ triệu/tháng").
  if(s.indexOf('triệu/tháng') >= 0){
    var re2 = /(\d+(?:[.,]\d+)?)\s*(?:[–-]\s*(\d+(?:[.,]\d+)?))?\s*\+?\s*triệu\s*\+?\s*\/tháng/g;
    var max2 = null, mm;
    while((mm = re2.exec(s)) !== null){
      var hi2 = mm[2] || mm[1];
      var v2 = parseFloat(hi2.replace(',', '.'));
      if(!isNaN(v2) && (max2 === null || v2 > max2)) max2 = v2;
    }
    return max2;
  }
  // Dang "đ/tháng": so la VND (vd "8.000.000đ - 15.000.000đ/tháng" -> 15 trieu).
  // Regex quet toi khoang ngay truoc "/tháng" nen khong lay nham luong gio
  // dung truoc (vd sh-05: "70.000đ - 100.000đ / giờ (8.000.000đ - 15.000.000đ/tháng" -> 15).
  var m = s.match(/([\d.]+)\s*đ(?:\s*[–-]\s*([\d.]+)\s*đ)?\s*\/tháng/);
  if(!m) return null;
  var hi = m[2] || m[1];
  var v = parseFloat(hi.replace(/\./g, '')) / 1000000;
  return isNaN(v) ? null : v;
}
function parseRevenue(s){
  if(!s || s === 'Chưa cập nhật') return null;
  var m = s.match(/([\d.,]+)\s*(tỷ|tỉ|triệu|tr|k|nghìn)?/i);
  if(!m) return null;
  var v = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
  if(isNaN(v)) return null;
  var unit = (m[2] || '').toLowerCase();
  if(unit === 'tỷ' || unit === 'tỉ') v *= 1000000000;
  else if(unit === 'triệu' || unit === 'tr') v *= 1000000;
  else if(unit === 'k' || unit === 'nghìn') v *= 1000;
  return v;
}
/* v45: parse so tien nguoi dung nhap o o loc gia tri ("150k", "150.000",
   "1,5", "15"). Quy uoc Viet: dau "." la phan cach hang nghin, dau ","
   la thap phan, hau to "k"/"K" = x1000. Tra ve so, hoac null neu rong /
   khong phai so / <= 0 (0 tro xuong nghia la "khong gioi han"). */
function parseMoneyInput(s){
  if(s == null) return null;
  var t = String(s).trim().toLowerCase().replace(/\s+/g, '');
  if(!t) return null;
  var mult = 1;
  if(t.charAt(t.length - 1) === 'k'){ mult = 1000; t = t.slice(0, -1); }
  t = t.replace(/\./g, '').replace(',', '.');
  if(!/^\d+(\.\d+)?$/.test(t)) return null;
  var v = parseFloat(t) * mult;
  if(isNaN(v) || v <= 0) return null;
  return v;
}
/* v226 (L4): parse luong gio thap nhat tu text salary cua shop.
   Duyet TUNG moc gio ('giờ' hoac '/h') theo thu tu, lay moc DAU TIEN ma
   menh de truoc no KET THUC bang 1 so tien (hoac dai "A-B") — vi cum
   "luong theo gio" cung chua chu "giờ" nhung khong co so tien ke sau.
   Menh de = phan sau dau ';' cuoi cung truoc moc. So tien phai co don vi
   (k/d/VNĐ/dong) hoac dau '.' phan cach nghin hoac ',' hoac gan '/' (moc
   '/h' tu gan '/') hoac la 1 dau cua dai co don vi; so tran khong don vi
   (vd "1 gio" = so luong video, "4 tieng", "ca 3 gio") thi BO.
   Dai "80-110k" lay so nho nhat; "150-170/h" -> 150000. Goc L4: ham cu
   lay MIN moi so TRUOC moc gio dau tien nen nuot ca luong THANG o menh
   de truoc (vd XDS sh-202: 8.000.000 thang -> coi la luong gio 8tr,
   xep dau; sh-154: 7-18 trieu/thang -> 7000 thay vi 60000).
   So co dau "." la phan cach hang nghin ("50.000" -> 50000); so < 1000
   hoac co hau to "k" hieu la nghin dong ("100k" -> 100000).
   Tra ve so thap nhat trong khoang, hoac null neu khong co luong gio. */
function parseHourlyMin(s){
  if(!s) return null;
  var low = String(s).toLowerCase();
  var marks = [];
  var i = -1;
  while((i = low.indexOf('giờ', i + 1)) !== -1) marks.push({pos: i, slash: false});
  i = -1;
  while((i = low.indexOf('/h', i + 1)) !== -1) marks.push({pos: i, slash: true});
  marks.sort(function(a, b){ return a.pos - b.pos; });
  if(!marks.length) return null;
  function money(raw, unit, partnerUnit, hasSlash){
    if(raw == null) return null;
    var hasDot = raw.indexOf('.') !== -1, hasComma = raw.indexOf(',') !== -1;
    if(!unit && !hasDot && !hasComma && !hasSlash && !partnerUnit) return null;
    var v;
    if(hasDot){ v = parseInt(raw.replace(/\./g, ''), 10); }
    else if(hasComma){ v = parseFloat(raw.replace(',', '.')); }
    else { v = parseInt(raw, 10); }
    if(isNaN(v)) return null;
    if(unit === 'k' || partnerUnit === 'k' || v < 1000) v = v * 1000;
    return v;
  }
  for(var k = 0; k < marks.length; k++){
    var end = marks[k].pos;
    var clause = low.slice(0, end);
    var semi = clause.lastIndexOf(';');
    if(semi !== -1) clause = clause.slice(semi + 1);
    var m = clause.match(/(\d[\d.,]*)\s*(k|đ|vnđ|vnd|đồng)?(?:\s*[-–—]\s*(\d[\d.,]*)\s*(k|đ|vnđ|vnd|đồng)?)?\s*\/?\s*$/);
    if(!m) continue;
    var hasSlash = marks[k].slash || /\/\s*$/.test(clause);
    var v1 = money(m[1], m[2], m[4], hasSlash);
    if(v1 === null) continue;
    var v2 = money(m[3], m[4], m[2], hasSlash);
    if(v2 === null) return v1;
    return Math.min(v1, v2);
  }
  return null;
}
/* v42: sap xep. null (khong co gia tri) LUON xep cuoi cung o ca 2 chieu.
   sortModelsBy: 'wage-asc'/'wage-desc' dung salaryNum; 'revenue-asc'/
   'revenue-desc' dung verifiedRevenue (v85 M1 — chi so DA XAC MINH, so
   tu khai/chuoi topRevenue cu khong tinh) — hien ca 20 mau deu
   "Chưa cập nhật" nen sap xep doanh thu khong doi thu tu (tat ca bang nhau).
   sortShopsBy: 'hourly-asc'/'hourly-desc' dung parseHourlyMin; 'monthly-asc'/
   'monthly-desc' dung parseMonthlyMax (v41). Mac dinh ('') tra ve ban sao
   khong doi thu tu — trang goi se dung pipeline mac dinh cua rieng no. */
function sortByVal(list, get, dir){
  return list.slice().sort(function(a, b){
    var va = get(a), vb = get(b);
    if(va === null && vb === null) return 0;
    if(va === null) return 1;
    if(vb === null) return -1;
    return dir * (va - vb);
  });
}
function sortModelsBy(list, sort){
  if(sort === 'wage-asc') return sortByVal(list, function(m){ return (typeof m.salaryNum === 'number' ? m.salaryNum : null); }, 1);
  if(sort === 'wage-desc') return sortByVal(list, function(m){ return (typeof m.salaryNum === 'number' ? m.salaryNum : null); }, -1);
  if(sort === 'revenue-asc') return sortByVal(list, function(m){ return verifiedRevenue(m); }, 1);
  if(sort === 'revenue-desc') return sortByVal(list, function(m){ return verifiedRevenue(m); }, -1);
  return list.slice();
}
function sortShopsBy(list, sort){
  if(sort === 'hourly-asc') return sortByVal(list, function(s){ return parseHourlyMin(s.salary); }, 1);
  if(sort === 'hourly-desc') return sortByVal(list, function(s){ return parseHourlyMin(s.salary); }, -1);
  if(sort === 'monthly-asc') return sortByVal(list, function(s){ return parseMonthlyMax(s.salary); }, 1);
  if(sort === 'monthly-desc') return sortByVal(list, function(s){ return parseMonthlyMax(s.salary); }, -1);
  return list.slice();
}
/* v76: lo/xuong trong data.js — so PR tinh tu data.js, khong con so ghi cung.
   Quy tac 60 ngay: chi ap dung nhom 1 (lo si). Ngay trong data.js la ngay dang
   goc trong bai goc (khong co ngay dang len web rieng); lo co (ngay hien tai -
   ngay dang) > 60 ngay thi khong render va khong tinh vao so PR. Nhom 2
   (thu mua/ky gui), nhom 3 (cho/san/TTTM/chuong trinh) va xuong may khong
   gioi han thoi gian — render het. */
function parseVnDate(s){
  if(!s) return null;
  var m = String(s).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if(!m) return null;
  var d = new Date(parseInt(m[3], 10), parseInt(m[2], 10) - 1, parseInt(m[1], 10));
  return isNaN(d.getTime()) ? null : d;
}
function lotActive(l, ref){
  if(!l || l.group !== 1) return true; /* v223: chi nhom 1 chiu quy tac 30 ngay (anh chot 13:01 14/11 — thu hoi 60 ngay cu) */
  var d = parseVnDate(l.date);
  if(!d) return true; /* khong co ngay hop le: hien de khoi mat du lieu */
  /* kiem tra kieu Date bang duck-type (khong dung instanceof) de chay dung
     ca khi ref duoc tao o realm khac (vd test chay qua vm). */
  var r = (ref && typeof ref.getTime === 'function') ? ref : new Date();
  var days = (r.getTime() - d.getTime()) / 86400000;
  return days <= 30; /* ngay tuong lai (days am) van hien */
}
function lotsByGroup(lots, ref){
  var out = {g1: [], g2: [], g3: []};
  (lots || []).forEach(function(l){
    if(l.group === 1){ if(lotActive(l, ref)) out.g1.push(l); }
    else if(l.group === 2){ out.g2.push(l); }
    else if(l.group === 3){ out.g3.push(l); }
  });
  return out;
}
function lotFactoryStats(lots, factories, ref){
  var byGroup = lotsByGroup(lots, ref);
  var provs = {};
  (factories || []).forEach(function(f){ if(f.prov) provs[f.prov] = true; });
  return {lotCount: byGroup.g1.length + byGroup.g2.length + byGroup.g3.length, buyerCount: byGroup.g2.length, batchCount: byGroup.g3.length, factoryCount: (factories || []).length, factoryProvinceCount: Object.keys(provs).length};
  /* v223 (S2-4): lotCount truoc day chi dem nhom 1 (18) trong khi link trang chu
     + tong the tren trang danh sach lo dem ca 3 nhom (71) — banner ghi 18, link ghi
     71. Nay dem TONG lo dang hoat dong (g1 active + g2 + g3); voi han 30 ngay:
     15 + 6 + 47 = 68. */
}
/* v76: the lo/xuong render tu data.js — phai GIONG HET the tinh cu (cung
   class, data-*, thu tu) de bo loc + nut Xem them 2 hang chay y nhu cu.
   v92 (C2): withComments=true thi them nut "Bình luận (N)" + khung mount
   an duoi moi the — bam moi mo form + tai danh sach (lazy-load, xu ly
   tap trung trong Ver2Comments.initCardComments). lotCardHTML dung chung
   cho ca kiot (trang thanh-ly-kiot goi voi doi tuong kiot): phan biet
   target_type theo tien to id ('kiot-' -> 'kiot', con lai -> 'lot'). */
function commentToggleHTML(targetType, targetId){
  return '<p><button class="btn btn-ghost btn-sm v2s-comment-toggle" type="button" data-v2s-comment-toggle data-v2s-target-type="'+esc(targetType)+'" data-v2s-target-id="'+esc(targetId)+'">💬 Bình luận</button></p>'
  + '<div class="v2s-comments-inline" data-v2s-comments-for="'+esc(targetType)+':'+esc(targetId)+'" hidden></div>';
}
/* v112: anh dai dien cho the lo/xuong/kiot — truong `img` trong data.js
   (anh that tu bai goc, vd images/lo/lot-01.jpg, images/xuong/fac-01.jpg,
   images/kiot/kiot-01.jpg; hien tai 0 ho so co anh that, anh se do cron
   thu thap dien dan). Khi co img: <img> phu kin o anh (luat
   .card-compact-photo img san co); placeholder icon/chu van nam DUOI anh
   (render truoc) nen anh loi (404) chi can this.remove() la hien lai
   placeholder — khong hien khung vo. Khi khong co img: giu nguyen
   placeholder nhu cu. */
function lotFactoryPhotoHTML(item, label){
  if(!item || !hasReal(item.img)) return '';
  return '<img src="'+esc(item.img)+'" alt="Ảnh thật từ bài gốc của '+esc(label)+'" loading="lazy" decoding="async" onerror="this.remove()">';
}
/* v124: huy hiệu "✓ Thành viên đăng" (góc trên-trái ảnh) + dòng tên shop
   dưới 2 dòng của thẻ lô/xưởng/kiot do thành viên đăng. Chỉ hiện khi
   item có source === 'user' (đặc tả §6.2/§6.3); tin thu thập giữ nguyên. */
function userListingBadgeHTML(item){
  if(!item || item.source !== 'user') return '';
  return '<span style="position:absolute;top:8px;left:8px;z-index:2;background:#137333;color:#fff;font-size:11px;font-weight:800;padding:3px 8px;border-radius:999px">✓ Thành viên đăng</span>';
}
function userListingShopLineHTML(item){
  if(!item || item.source !== 'user' || !item.shop_name) return '';
  return '<p class="card-compact-line" style="color:#137333;font-weight:700">Đăng bởi: ' + esc(item.shop_name) + '</p>';
}
/* v124: định danh bình luận của tin user = UUID gốc (đặc tả §6.3:
   target_ref = UUID của tin), không phải id thẻ 'user-<uuid>'; tin thu
   thập giữ nguyên id data.js. */
function userListingCommentTargetId(item){
  return (item && item.source === 'user' && item._dbId) ? item._dbId : (item && item.id);
}
function lotCardHTML(l, withComments){
  // v99 (§1c): the lo/kiot rut gon — khoi mau 46/51 + ten overlay + dung
  // 2 dong (dia diem; tong gia tri -> loai mat hang -> so luong) + nut
  // sao. Nut binh luan (v92 C2) giu nguyen duoi 2 dong. data-price/
  // data-qty/data-cat giu nguyen de bo loc lo (lotMatches) chay y cu.
  // v101: o anh khong con chi la icon — lo nhom 2 hien "Thu mua: <loai>",
  // lo nhom 1 + nhom 3 hien "Xa kho: <loai>", kiot hien loai hinh (nhan
  // tieng Viet tu cat); lo/kiot khong co cat thi giu icon cu.
  // v124: tin user có trường kind ('lot'/'factory'/'kiot', đặc tả §6.2)
  // nên nhận diện kiot qua kind trước; lô thu thập cũ giữ logic tiền tố
  // id ('kiot-…') như trước.
  var targetType = (l && (l.kind === 'kiot' || (l.id && String(l.id).indexOf('kiot-') === 0))) ? 'kiot' : 'lot';
  var photoContent;
  if(targetType === 'kiot'){
    photoContent = hasReal(l.cat) ? '<span class="card-compact-noimg" aria-hidden="true"><span>🏪 '+esc(catLabel(l.cat))+'</span></span>' : '<span class="card-compact-ph" aria-hidden="true">🏪</span>';
  } else if(l && l.group === 2){
    photoContent = hasReal(l.cat) ? '<span class="card-compact-noimg" aria-hidden="true"><span>📦 Thu mua: '+esc(catLabel(l.cat))+'</span></span>' : '<span class="card-compact-ph" aria-hidden="true">📦</span>';
  } else {
    photoContent = hasReal(l.cat) ? '<span class="card-compact-noimg" aria-hidden="true"><span>📦 Xả kho: '+esc(catLabel(l.cat))+'</span></span>' : '<span class="card-compact-ph" aria-hidden="true">📦</span>';
  }
  // Kiot co truong prov rieng (dung luon); lo phai quet tinh trong tieu de/meta.
  var line1 = targetType === 'kiot' ? kiotLocationLine(l) : lotLocationLine(l);
  var line2 = targetType === 'kiot' ? kiotTypeLine(l) : lotValueLine(l);
  // v111: data-prov de bo loc lo loc theo tinh (truoc day the lo khong co
  // data-prov nen chon tinh khong loc gi); kiot dung prov rieng, lo quet
  // tu tieu de/meta (lotProvOf), ca hai quy ve ten sau sap nhap.
  // v166 (N8): kiot dung normProvKiot (chi gop 'TP.HCM', KHONG gop
  // Binh Duong — xem ghi chu o normProvKiot) nen data-prov cua LEILA
  // la "Bình Dương", khong con khop loc TP. Hồ Chí Minh.
  // v135: data-group de bo loc Nhom (lo nhom 1/2/3); kiot khong co nhom.
  var cardProv = targetType === 'kiot' ? normProvKiot(l.prov) : lotProvOf(l);
  return '<article class="lot-card card-compact" id="'+esc(l.id)+'" data-prov="' + esc(cardProv) + '" data-price="' + (l.priceNum == null ? '' : l.priceNum) + '" data-qty="' + (l.qty == null ? '' : l.qty) + '" data-cat="' + esc(l.cat) + '" data-group="' + (targetType === 'kiot' || l.group == null ? '' : l.group) + '" data-v2s-id="'+esc(l.id)+'">'
  + '<a class="card-compact-photo card-compact-photo--' + targetType + '" href="' + esc(l.url) + '" target="_blank" rel="noopener">' + userListingBadgeHTML(l) + photoContent + lotFactoryPhotoHTML(l, l.title) + '<span class="card-compact-name"><span>' + esc(l.title) + '</span></span></a>'
  + starButtonHTML(targetType, l.id)
  + '<div class="card-compact-lines"><p class="card-compact-line">' + line1 + '</p><p class="card-compact-line">' + line2 + '</p>' + userListingShopLineHTML(l) + '</div>'
  + (withComments ? commentToggleHTML(targetType, userListingCommentTargetId(l)) : '') + '</article>';
}
function factoryCardHTML(f, withComments){
  // v99 (§1c): the xuong rut gon — khoi mau 46/51 + ten overlay + dung
  // 2 dong (dia diem; loai mat hang gia cong — nhieu loai thi lay loai
  // chinh, thieu thi "Thoa thuan") + nut sao. Nut binh luan (v92 C2)
  // giu nguyen. data-moq/data-cat/data-prov giu nguyen cho facMatches.
  return '<article class="lot-card card-compact" id="'+esc(f.id)+'" data-moq="' + (f.moq == null ? '' : f.moq) + '" data-cat="' + esc(f.cat) + '" data-prov="' + esc(f.prov) + '" data-v2s-id="'+esc(f.id)+'">'
  + '<a class="card-compact-photo card-compact-photo--factory" href="' + esc(f.url) + '" target="_blank" rel="noopener">' + userListingBadgeHTML(f) + '<span class="card-compact-ph" aria-hidden="true">🏭</span>' + lotFactoryPhotoHTML(f, f.name) + '<span class="card-compact-name"><span>' + esc(f.name) + '</span></span></a>'
  + starButtonHTML('factory', f.id)
  + '<div class="card-compact-lines"><p class="card-compact-line">' + factoryLocationLine(f) + '</p><p class="card-compact-line">' + factoryItemsLine(f) + '</p>' + userListingShopLineHTML(f) + '</div>'
  + (withComments ? commentToggleHTML('factory', userListingCommentTargetId(f)) : '') + '</article>';
}
/* v76: render the lo/xuong tu data.js vao trang Shop + cap nhat dong dem
   (.lot-sub) + o loc tinh dung chung (fUniProv) theo so lieu thuc te. Goi TRUOC
   initLotFilter/initFactoryFilter vi cac ham do chup lai danh sach the trong
   grid luc khoi tao. Tren trang khac (khong co section lo/xuong) thi khong lam gi. */
function renderLotSections(ref){
  var lots = D.lots || [], factories = D.factories || [];
  var byGroup = lotsByGroup(lots, ref);
  var g1 = document.getElementById('lotGrid1');
  if(g1) g1.innerHTML = byGroup.g1.map(function(l){ return lotCardHTML(l, true); }).join(''); // v92 (C2): nut Binh luan duoi moi the lo
  var g2 = document.getElementById('lotGrid2');
  if(g2) g2.innerHTML = byGroup.g2.map(function(l){ return lotCardHTML(l, true); }).join('');
  var g3 = document.getElementById('lotGrid3');
  if(g3) g3.innerHTML = byGroup.g3.map(function(l){ return lotCardHTML(l, true); }).join('');
  var fg = document.getElementById('factoryGrid');
  if(fg) fg.innerHTML = factories.map(function(f){ return factoryCardHTML(f, true); }).join(''); // v92 (C2): nut Binh luan duoi moi the xuong
  var s1 = document.getElementById('lotSub1');
  // v99 (§1c): the lo rut gon chi con 2 dong nen nhan "Chưa xác thực" khong
  // con cho tren moi the — hien canh bao chung o tieu de muc lo (v55: 20/20 lo deu chua xac thuc).
  if(s1) s1.textContent = 'Doanh nghiệp và shop xả hàng tồn kho theo lô sỉ — đang có ' + byGroup.g1.length + ' lô. Lưu ý: các lô đều chưa xác thực — không phải lô chính hãng của thương hiệu.';
  var s2 = document.getElementById('lotSub2');
  if(s2) s2.textContent = 'Doanh nghiệp cần xả kho số lượng lớn có thể liên hệ các đơn vị thu mua dưới đây để thu về vốn tái sản xuất. Giá thu mua không công khai, liên hệ trực tiếp để thỏa thuận. Đang có ' + byGroup.g2.length + ' đơn vị.';
  var s3 = document.getElementById('lotSub3');
  if(s3) s3.textContent = 'Chương trình xả kho theo đợt của chợ, sàn, trung tâm thương mại và tổ chức — bán lẻ từng món, không phải lô sỉ. Đang có ' + byGroup.g3.length + ' chương trình.';
  var fs = document.getElementById('factorySub');
  if(fs) fs.textContent = 'Xưởng và nhà máy may nhận gia công quần áo cho shop và thương hiệu — đang có ' + factories.length + ' xưởng/nhà máy.';
  /* v111 (muc 9): o loc tinh dung chung (fUniProv) build DONG tu
     D.provinces (danh sach tinh sau sap nhap, da gom Ha Tinh/Quang Ngai/
     Gia Lai/Dak Lak, khong con ten cu Binh Duong/Nam Dinh/Hai Duong/
     Bac Giang) thay vi chi cac tinh co xuong. So dem trong () do
     initOptionCounts/refreshUniCounts gan theo tung tab sau. */
  var sel = document.getElementById('fUniProv');
  if(sel){
    var html = '<option value="">Tất cả tỉnh</option>';
    (D.provinces || []).forEach(function(p){
      html += '<option value="' + esc(p) + '">' + esc(p) + '</option>';
    });
    sel.innerHTML = html;
  }
}
/* ---------- v179: 5 danh muc doi tuong moi (12/11/2026) ----------
   2 muc lop hoc -> danh-sach-mau.html; 3 muc con lai ->
   danh-sach-shop.html. Moi muc 1 section rieng duoi cac section hien
   co (khong doi thu tu section cu, khong them menu). The dung chung
   khung .lot-card/.lot-grid + modal dung chung lotFactoryKiotDetailHTML
   (mo rong them 5 loai); bo loc dung chung initSectionFilter.
   Avatar BAT BUOC: the khong co avatar thi khong render — newObjCardHTML
   tra '' (anh dai dien la bat buoc theo yeu cau 20:05 ngay 12/11).
   Khong co nut sao cho 7 loai moi: enum category cua RPC sao (M7.2)
   chua co cac loai nay, bam sao se loi hoan tac — cho backend bo sung
   roi moi bat sao. Khong co binh luan inline (nhu mau/shop: binh luan
   o trang chi tiet day du; 5 loai moi chua co trang chi tiet rieng). */
var NEWOBJ_TYPES = {
  classesLive: {label: 'Lớp Livestream / MC / Thuyết trình', short: 'Lớp Livestream', icon: '🎤', priceLabel: 'Học phí', page: 'danh-sach-mau.html'},
  classesMakeup: {label: 'Lớp dạy Makeup', short: 'Lớp Makeup', icon: '💄', priceLabel: 'Học phí', page: 'danh-sach-mau.html'},
  eventsMarketing: {label: 'Sự kiện Marketing', short: 'Sự kiện Marketing', icon: '📣', priceLabel: 'Phí tham dự', page: 'danh-sach-shop.html'},
  logistics: {label: 'Logistics Trung – Việt', short: 'Logistics', icon: '🚚', priceLabel: 'Giá vận chuyển', page: 'danh-sach-shop.html'},
  rentals: {label: 'Cho thuê cửa hàng / kho hàng', short: 'Cho thuê mặt bằng', icon: '🏬', priceLabel: 'Giá thuê', page: 'thanh-ly-kiot.html'},
  agencyAds: {label: 'Agency Ads Livestream', short: 'Agency Ads', icon: '🎯', priceLabel: 'Phí dịch vụ', page: 'danh-sach-shop.html'},
  movingServices: {label: 'Dịch vụ chuyển nhà', short: 'Chuyển nhà', icon: '🏠', priceLabel: 'Giá dịch vụ', page: 'thanh-ly-kiot.html'},
  liveEquipment: {label: 'Thiết bị Phòng Live', short: 'Thiết bị Live', icon: '🎙️', priceLabel: 'Giá bán', page: 'thanh-ly-kiot.html'}
};
var NEWOBJ_ARRAYS = ['classesLive', 'classesMakeup', 'eventsMarketing', 'logistics', 'rentals', 'agencyAds', 'movingServices', 'liveEquipment'];
var NEWOBJ_LOGISTICS_OPTIONS = {'chinh-ngach': 'Vận chuyển chính ngạch', 'tieu-ngach': 'Vận chuyển trọn gói – tiểu ngạch', 'mua-ho': 'Dịch vụ mua hàng hộ'};
/* v182 + v196: 7 danh muc moi lam MUC CON trong bo loc chung (uni-cat-switch).
   v186: loc cua 5 muc CHI CON o loc chung tren top cua trang con do
   (tinh dung chung + sap xep theo gia/hoc phi + hinh thuc logistics);
   section chi giu luoi + dem/trong, KHONG con loc rieng. Map nay tro
   thang toi o loc tren top de nut Ap dung loc chung doc dung gia tri. */
var NEWOBJ_UNI_CATS = {
  'class-live': {type: 'classesLive', sectionId: 'lop-livestream-mc', provId: 'fUniProv', moreBtnId: 'classLiveMoreBtn', countId: 'classLiveCount', label: 'Lớp học Livestream/MC/Thuyết trình'},
  'class-makeup': {type: 'classesMakeup', sectionId: 'lop-makeup', provId: 'fUniProv', moreBtnId: 'classMakeupMoreBtn', countId: 'classMakeupCount', label: 'Lớp học dạy Makeup'},
  'event-mkt': {type: 'eventsMarketing', sectionId: 'su-kien-marketing', provId: 'fShProv', moreBtnId: 'eventMarketingMoreBtn', countId: 'eventMarketingCount', label: 'Sự kiện Marketing chia sẻ kiến thức'},
  'logistics': {type: 'logistics', sectionId: 'logistics-trung-viet', provId: 'fShProv', optionId: 'fShopLogOpt', moreBtnId: 'logisticsMoreBtn', countId: 'logisticsCount', label: 'Công ty logistics Trung–Việt'},
  'rentals': {type: 'rentals', sectionId: 'cho-thue-cua-hang-kho', provId: 'kiotProv', moreBtnId: 'rentalsMoreBtn', countId: 'rentalsCount', label: 'Cho thuê cửa hàng/kho hàng'},
  'agency-ads': {type: 'agencyAds', sectionId: 'agency-ads-livestream', provId: 'fShProv', moreBtnId: 'agencyAdsMoreBtn', countId: 'agencyAdsCount', label: 'Agency Ads Livestream'},
  'chuyen-nha': {type: 'movingServices', sectionId: 'dich-vu-chuyen-nha', provId: 'kiotProv', moreBtnId: 'movingMoreBtn', countId: 'movingCount', label: 'Dịch vụ chuyển nhà'},
  'thiet-bi-live': {type: 'liveEquipment', sectionId: 'thiet-bi-phong-live', provId: 'kiotProv', moreBtnId: 'liveEquipMoreBtn', countId: 'liveEquipCount', label: 'Thiết bị Phòng Live'}
};
function newObjUniCatCfg(cat){ return NEWOBJ_UNI_CATS[cat] || null; }
/* v214: khoang gia dang chon cua overlay gia trang Kiot (trang duy nhat co
   overlay; khoang doi theo muc dang chon, mac dinh khong loc gia). Trang
   Kiot dat qua setKiotPriceRange; readForm cua section moi doc o day. */
var KIOT_PRICE_RANGE = {min: null, max: null};
function setKiotPriceRange(min, max){ KIOT_PRICE_RANGE.min = (min == null ? null : min); KIOT_PRICE_RANGE.max = (max == null ? null : max); }
/* Dem that theo mang du lieu (chi tinh muc co avatar — giong render). */
function newObjCount(type){ var n = 0; (D[type] || []).forEach(function(x){ if(x && x.avatar) n++; }); return n; }
function newObjProvCount(type, prov){ var n = 0; (D[type] || []).forEach(function(x){ if(x && x.avatar && normProv(x.province || '') === normProv(prov)) n++; }); return n; }
/* v214 (anh Thọ dặn 01:08 ngày 14/11): BO so thong ke canh ten 7 muc moi
   (5 muc KPI: lop livestream, lop makeup, su kien/marketing, logistics,
   cho thue mat bang + 2 muc con Kiot: dich vu chuyen nha, thiet bi phong
   live). LUAT CUNG: khong bao gio de so thong ke o canh ten muc DANG CHON
   — nut switch dang active thi an .uni-cat-count cua nut do, het active
   thi hien lai neu muc duoc phep hien so (agency-ads giu so khi chua chon). */
var NEWOBJ_NO_COUNT = {'class-live': 1, 'class-makeup': 1, 'event-mkt': 1, 'logistics': 1, 'rentals': 1, 'chuyen-nha': 1, 'thiet-bi-live': 1};
/* Cap nhat so dem (N) tren cac nut muc con trong uni-cat-switch (ca 3 trang). */
function refreshNewObjCatCounts(){
  if(typeof document === 'undefined' || !document.querySelectorAll) return;
  var btns = document.querySelectorAll('.uni-cat-btn[data-uni-cat]');
  btns.forEach(function(b){
    var cat = b.getAttribute('data-uni-cat');
    var cfg = NEWOBJ_UNI_CATS[cat];
    if(!cfg) return;
    var sp = b.querySelector('.uni-cat-count');
    if(!sp) return;
    if(NEWOBJ_NO_COUNT[cat] || b.classList.contains('active')){ sp.textContent = ''; return; }
    sp.textContent = '(' + newObjCount(cfg.type) + ')';
  });
}
/* v182: chi hien section cua hang muc moi dang chon; an cac section moi con
   lai tren cung trang (de "chi hien dung ho so thuoc muc do"). Cac section
   chinh (mau/shop/lo/xuong) giu nguyen nhu tab cu — khong an. */
function showOnlyNewObjSection(activeCat){
  if(typeof document === 'undefined') return;
  Object.keys(NEWOBJ_UNI_CATS).forEach(function(k){
    var s = document.getElementById(NEWOBJ_UNI_CATS[k].sectionId);
    if(s) s.hidden = (k !== activeCat);
  });
}
function showAllNewObjSections(){
  if(typeof document === 'undefined') return;
  Object.keys(NEWOBJ_UNI_CATS).forEach(function(k){
    var s = document.getElementById(NEWOBJ_UNI_CATS[k].sectionId);
    if(s) s.hidden = false;
  });
}
/* Thu tu hien thi + id DOM cua 8 section (v210: shop.html: 2 muc dau — lop hoc; mau.html: 3 muc giua — su kien/logistics/agency; thanh-ly-kiot.html: 3 muc cuoi). */
var NEWOBJ_SECTIONS = [
  {type: 'classesLive', gridId: 'classLiveGrid', subId: 'classLiveSub', countH2Id: 'classLiveCountH2', subText: 'Lớp học livestream, MC và thuyết trình trước đám đông cho mẫu live và người mới bắt đầu.'},
  {type: 'classesMakeup', gridId: 'classMakeupGrid', subId: 'classMakeupSub', countH2Id: 'classMakeupCountH2', subText: 'Lớp học dạy makeup cá nhân và makeup lên hình livestream.'},
  {type: 'eventsMarketing', gridId: 'eventMarketingGrid', subId: 'eventMarketingSub', countH2Id: 'eventMarketingCountH2', subText: 'Sự kiện marketing, workshop và buổi chia sẻ kiến thức cho chủ shop online.'},
  {type: 'logistics', gridId: 'logisticsGrid', subId: 'logisticsSub', countH2Id: 'logisticsCountH2', subText: 'Công ty logistics Trung – Việt: vận chuyển chính ngạch, trọn gói – tiểu ngạch và dịch vụ mua hàng hộ.'},
  {type: 'rentals', gridId: 'rentalsGrid', subId: 'rentalsSub', countH2Id: 'rentalsCountH2', subText: 'Cho thuê cửa hàng và kho hàng cho shop online và hộ kinh doanh.'},
  {type: 'agencyAds', gridId: 'agencyAdsGrid', subId: 'agencyAdsSub', countH2Id: 'agencyAdsCountH2', subText: 'Agency chạy quảng cáo livestream TikTok/Facebook, booking KOL livestream cho shop online.'},
  {type: 'movingServices', gridId: 'movingGrid', subId: 'movingSub', countH2Id: 'movingCountH2', subText: 'Dịch vụ chuyển nhà, chuyển trọ, chở đồ ghép xe cho shop và hộ kinh doanh online.'},
  {type: 'liveEquipment', gridId: 'liveEquipGrid', subId: 'liveEquipSub', countH2Id: 'liveEquipCountH2', subText: 'Thiết bị phòng live: đèn, mic, webcam, capture card cho livestream bán hàng.'}
];
function newObjPriceText(item){
  if(!item || item.price == null) return 'Liên hệ';
  return fmtVnd(item.price) + 'đ' + (item.priceSuffix || '');
}
function newObjCardHTML(item){
  /* Avatar bat buoc: khong co avatar thi khong render the. */
  if(!item || !hasReal(item.avatar)) return '';
  var meta = NEWOBJ_TYPES[item.type] || {};
  var priceTxt = newObjPriceText(item);
  var priceLabel = item.priceLabel || meta.priceLabel || 'Giá';
  return '<article class="lot-card newobj-card" id="' + esc(item.id) + '" data-v2s-id="' + esc(item.id) + '" data-type="' + esc(item.type) + '" data-prov="' + esc(item.province || '') + '" data-price="' + (item.price == null ? '' : item.price) + '" data-logistics-option="' + esc(item.logisticsOption || '') + '">'
    + '<a href="#" class="newobj-photo" data-detail-id="' + esc(item.id) + '" aria-label="Xem chi tiết ' + esc(item.name || '') + '"><img src="' + esc(item.avatar) + '" alt="' + esc(item.name || '') + ' — ' + esc(meta.label || '') + '" loading="lazy" onerror="this.remove()"></a>'
    + '<div class="newobj-lines"><p class="newobj-name">' + esc(item.name || '') + '</p>'
    + '<p class="newobj-provider">' + esc(item.provider || '') + '</p>'
    + '<p class="newobj-price">' + esc(priceLabel) + ': <b>' + esc(priceTxt) + '</b></p>'
    + '<p class="newobj-prov">📍 ' + esc(item.province || '') + '</p>'
    + '<p><button type="button" class="btn btn-ghost btn-sm" data-detail-id="' + esc(item.id) + '">Xem chi tiết →</button></p></div>'
    + '</article>';
}
function renderNewObjSections(){
  NEWOBJ_SECTIONS.forEach(function(cfg){
    var items = (D[cfg.type] || []).filter(function(x){ return x && x.avatar; });
    var g = document.getElementById(cfg.gridId);
    if(g) g.innerHTML = items.map(function(it){ return newObjCardHTML(it); }).join('');
    var s = document.getElementById(cfg.subId);
    if(s) s.textContent = cfg.subText + ' — đang có ' + items.length + ' ' + ((NEWOBJ_TYPES[cfg.type] || {}).short || 'mục') + '.';
    var h = document.getElementById(cfg.countH2Id);
    if(h) h.textContent = '(' + items.length + ')';
  });
  /* v186: loc rieng cua 5 muc da xoa — o Tinh dung o loc chung tren top
     (fUniProv/fShProv, option cung san trong HTML), khong build o day nua. */
  /* v182: so dem (N) tren cac nut muc con trong bo loc chung. */
  refreshNewObjCatCounts();
}
function newObjMatches(card, f){
  if(f.prov && normProv(card.getAttribute('data-prov')) !== normProv(f.prov)) return false;
  if(f.logisticsOption && card.getAttribute('data-logistics-option') !== f.logisticsOption) return false;
  /* v214: loc theo khoang gia Kiot (overlay tran xuong) — chi khi co khoang
     duoc chon (f.priceMin/f.priceMax); the khong co gia (data-price '')
     khong khop khoang nao. Ngu nghia theo nhan hien thi: "Duoi X" la p < X;
     "A–B" la A <= p <= B (ca 2 dau, nhu cach doc cua nguoi dung — muc gia
     dung o moc 500.000d phai hien trong khoang "300.000–500.000d"); "Tren X"
     la p > X. */
  if(f.priceMin != null || f.priceMax != null){
    var p = parseFloat(card.getAttribute('data-price'));
    if(isNaN(p)) return false;
    if(f.priceMin != null && f.priceMax != null){ if(p < f.priceMin || p > f.priceMax) return false; }
    else if(f.priceMin != null){ if(p <= f.priceMin) return false; }
    else { if(p >= f.priceMax) return false; }
  }
  return true;
}
/* v213: nut "Xem them" cua 2 muc lop hoc CHI hien khi con du lieu chua hien
   (anh Thọ dặn 23:57 ngày 13/11 — 2 muc lop hoc hien 2 hang, neu nhieu hon thi
   co nut xem tiep va hien tong so luong; theo mau v212 cua Kiot). Mo rong thi
   nut la "Thu gọn"; thu gon thi "Xem thêm ↓ (còn N lớp học)" voi N = so the
   khop bo loc dang bi CSS an (tu the #13 desktop / #5 tablet / #3 mobile);
   khong con the an thi AN nut. Dem bang offsetParent (chinh xac theo
   viewport) — loai the bi loc (lot-filtered-out) vi chung an do loc, khong
   phai do thu gon. 1 chu duy nhat cho text/an-hien cua 2 nut (thay 2 script
   inline rieng trong danh-sach-shop.html + cac cho dat text truc tiep). */
var CLASS_MORE = {
  'lop-livestream-mc': {moreBtnId: 'classLiveMoreBtn', gridId: 'classLiveGrid'},
  'lop-makeup': {moreBtnId: 'classMakeupMoreBtn', gridId: 'classMakeupGrid'}
};
function refreshClassMoreBtn(secId){
  var cfg = CLASS_MORE[secId];
  if(!cfg) return;
  var mb = document.getElementById(cfg.moreBtnId);
  var s = document.getElementById(secId);
  var grid = document.getElementById(cfg.gridId);
  if(!mb || !s || !grid) return;
  if(!s.classList.contains('collapsed')){
    mb.hidden = false; mb.setAttribute('aria-expanded','true'); mb.textContent = 'Thu gọn ↑'; return;
  }
  var hidden = 0;
  for(var i = 0; i < grid.children.length; i++){
    var c = grid.children[i];
    if(!c.classList.contains('lot-filtered-out') && c.offsetParent === null) hidden++;
  }
  mb.setAttribute('aria-expanded','false');
  mb.hidden = hidden === 0;
  mb.textContent = 'Xem thêm ↓ (còn ' + hidden + ' lớp học)';
}
/* v213: expose qua window.V20 o literal cuoi file (kieu v179/v212) — probe
   dung de kiem duong dem so luong khi them the gia vao luoi. */
/* Khoi tao 1 section moi: bo loc dung chung initSectionFilter (tinh/tp +
   option logistics + sap xep theo gia) — v186: form loc doc TU LOC
   CHUNG TREN TOP (provId/sortId/optionId tro toi o tren top, khong con
   loc rieng trong section). Nut Ap dung / Dat lai o loc chung goi
   h.apply()/h.reset() (khong qua gateFilterApply: 5 loai moi chua co
   points category, khong can gate diem); sau khi ap dung thi gap bo loc
   tren mobile (closeFilterOf) de thay ket qua ngay nhu cac bo loc khac. */
function initNewObjSection(cfg){
  var sectionId = cfg.sectionId;
  if(!document.getElementById(sectionId)) return null;
  var h = initSectionFilter({
    sectionId: sectionId, moreBtnId: cfg.moreBtnId, filterId: cfg.filterId,
    countId: cfg.countId, emptyId: cfg.emptyId, label: cfg.label,
    /* v207: CẤM cuộn (trôi) cho mục mới khi BAM HANG MUC/switch/?newobj= —
       apply() của section mục mới chỉ cuộn khi được gọi TỪ NÚT Áp dụng
       (doScroll=true, v213); xem guard trong apply(). */
    noScroll: true,
    readForm: function(){
      return {
        prov: elVal(cfg.provId),
        sort: elVal(cfg.sortId),
        logisticsOption: cfg.optionId ? elVal(cfg.optionId) : '',
        /* v214: khoang gia Kiot (overlay) — trang Kiot dat qua
           window.V20.setKiotPriceRange; trang khac khong co nen null. */
        priceMin: (typeof window !== 'undefined' && window.V20 && window.V20.kiotPriceRange) ? window.V20.kiotPriceRange.min : null,
        priceMax: (typeof window !== 'undefined' && window.V20 && window.V20.kiotPriceRange) ? window.V20.kiotPriceRange.max : null
      };
    },
    matches: newObjMatches,
    sort: function(f){ return lotSortComparator(f.sort); }
  });
  if(!h) return null;
  /* v179: giu handle de test/debug (refresh sau khi them the moi) + goi lai tu console. */
  if(typeof window !== 'undefined'){ window.V2S_NEWOBJ_FILTERS = window.V2S_NEWOBJ_FILTERS || {}; window.V2S_NEWOBJ_FILTERS[sectionId] = h; }
  return h;
}
function initNewObjSections(){
  renderNewObjSections();
  /* v210: o Tinh doc theo TRANG (moi trang chi co 1 o Tinh o loc chung):
     mau.html fUniProv, shop.html fShProv, kiot.html kiotProv. Truoc day
     lop hoc cung fUniProv + 3 muc shop cung fShProv — sau khi doi cho
     (lop hoc sang shop, 3 muc shop sang mau) phai doc theo trang, khong
     cung theo muc nua (elVal tra '' neu o khong co tren trang thi loc
     tinh am tham mat tac dung). sortId/optionId giu theo muc: lop hoc
     fUniClassSort, 3 muc shop fShopPriceSort (+ fShopLogOpt cho logistics);
     2 o nay da chuyen sang trang moi cung section (xem HTML). */
  var PROV = document.getElementById('fUniProv') ? 'fUniProv' : (document.getElementById('fShProv') ? 'fShProv' : 'kiotProv');
  initNewObjSection({sectionId: 'lop-livestream-mc', moreBtnId: 'classLiveMoreBtn', countId: 'classLiveCount', emptyId: 'classLiveEmpty', label: 'lớp học', provId: PROV, sortId: 'fUniClassSort'});
  initNewObjSection({sectionId: 'lop-makeup', moreBtnId: 'classMakeupMoreBtn', countId: 'classMakeupCount', emptyId: 'classMakeupEmpty', label: 'lớp học', provId: PROV, sortId: 'fUniClassSort'});
  initNewObjSection({sectionId: 'su-kien-marketing', moreBtnId: 'eventMarketingMoreBtn', countId: 'eventMarketingCount', emptyId: 'eventMarketingEmpty', label: 'sự kiện', provId: PROV, sortId: 'fShopPriceSort'});
  initNewObjSection({sectionId: 'logistics-trung-viet', moreBtnId: 'logisticsMoreBtn', countId: 'logisticsCount', emptyId: 'logisticsEmpty', label: 'đơn vị vận chuyển', provId: PROV, sortId: 'fShopPriceSort', optionId: 'fShopLogOpt'});
  initNewObjSection({sectionId: 'cho-thue-cua-hang-kho', moreBtnId: 'rentalsMoreBtn', countId: 'rentalsCount', emptyId: 'rentalsEmpty', label: 'mặt bằng', provId: PROV, sortId: 'kiotSort'});
  initNewObjSection({sectionId: 'agency-ads-livestream', moreBtnId: 'agencyAdsMoreBtn', countId: 'agencyAdsCount', emptyId: 'agencyAdsEmpty', label: 'agency', provId: PROV, sortId: 'fShopPriceSort'});
  initNewObjSection({sectionId: 'dich-vu-chuyen-nha', moreBtnId: 'movingMoreBtn', countId: 'movingCount', emptyId: 'movingEmpty', label: 'dịch vụ chuyển nhà', provId: PROV, sortId: 'kiotSort'});
  initNewObjSection({sectionId: 'thiet-bi-phong-live', moreBtnId: 'liveEquipMoreBtn', countId: 'liveEquipCount', emptyId: 'liveEquipEmpty', label: 'thiết bị phòng live', provId: PROV, sortId: 'kiotSort'});
  /* Bam anh hoac nut "Xem chi tiet" tren the moi -> mo modal dung chung.
     Gan 1 lan (guard) vi init chay moi lan DOMContentLoaded. */
  if(typeof document !== 'undefined' && !document._v2sNewObjDetailBound){
    document._v2sNewObjDetailBound = true;
    document.addEventListener('click', function(e){
      if(e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey) return;
      var t = e.target && e.target.closest ? e.target.closest('[data-detail-id]') : null;
      if(!t) return;
      if(openLotFactoryKiotDetail(t.getAttribute('data-detail-id'))) e.preventDefault();
    });
  }
  /* v213: nut Xem them cua 2 muc lop hoc — 1 dang ky click duy nhat (thay
     2 script inline rieng trong danh-sach-shop.html) + dat text/lan dau
     theo so luong that (renderNewObjSections da render xong the o tren). */
  Object.keys(CLASS_MORE).forEach(function(secId){
    var b = document.getElementById(CLASS_MORE[secId].moreBtnId);
    if(b && !b._v213Bound){
      b._v213Bound = true;
      b.addEventListener('click', function(){
        var s = document.getElementById(secId);
        if(!s) return;
        s.classList.toggle('collapsed');
        refreshClassMoreBtn(secId);
      });
    }
    refreshClassMoreBtn(secId);
  });
}
/* ---------- v124: Tin lô / xưởng / kiot do thành viên đăng ---------- */
/* Chuyển 1 dòng từ public view (Supabase) sang đúng shape data.js (đặc tả
   §6.2) để tái dùng lotCardHTML / factoryCardHTML:
   - id: 'user-' + uuid; source: 'user'; kind: 'lot'/'factory'/'kiot';
     _dbId giữ UUID gốc (dùng cho RPC/bình luận — target_ref = UUID).
   - prov: province (tin user LUÔN có tỉnh); meta: description (+ xưởng:
     địa chỉ/MOQ/điện thoại/website; kiot: diện tích/tiền thuê).
   - url: NULL — thẻ tin user KHÔNG phải link ngoài (§6.4); img:
     images[0] (ảnh bìa); images: toàn bộ mảng; shop_name từ view.
   - group: lô user luôn 1 (xả kho). Tin user KHÔNG ghi vào data.js —
     chỉ fetch runtime rồi gộp vào lưới; lỗi mạng/supabase thì im lặng,
     chỉ hiện tin thu thập. */
var userListingByCardId = {};
function userListingDateStr(iso){
  try{
    var d = new Date(iso);
    if(isNaN(d.getTime())) return '';
    var dd = String(d.getDate()).padStart(2, '0');
    var mm = String(d.getMonth() + 1).padStart(2, '0');
    return dd + '/' + mm + '/' + d.getFullYear();
  }catch(e){ return ''; }
}
function userListingToLot(r){
  return {
    id: 'user-' + r.id, source: 'user', kind: 'lot', _dbId: r.id,
    title: r.title, prov: r.province, meta: r.description || '',
    cat: r.cat, priceNum: r.price_num, priceUnit: r.price_unit || 'cái',
    qty: r.qty, img: (r.images && r.images[0]) || null, images: r.images || [],
    shop_name: r.shop_name || '', contact_zalo: r.contact_zalo || '',
    contact_phone: r.contact_phone || '', source_url: r.source_url || '',
    url: null, date: userListingDateStr(r.created_at), group: 1,
    label: 'Đã duyệt bởi Ver2Solution'
  };
}
function userListingToFactory(r){
  var metaParts = [];
  if(r.description) metaParts.push(r.description);
  if(r.address) metaParts.push(r.address);
  if(r.moq != null) metaParts.push('MOQ: ' + r.moq);
  if(r.phone) metaParts.push(r.phone);
  if(r.website) metaParts.push(r.website);
  return {
    id: 'user-' + r.id, source: 'user', kind: 'factory', _dbId: r.id,
    name: r.name, items: r.items, cat: r.cat, prov: r.province,
    meta: metaParts.join(' · '), moq: r.moq, phone: r.phone || '',
    website: r.website || '', address: r.address || '',
    img: (r.images && r.images[0]) || null, images: r.images || [],
    shop_name: r.shop_name || '', contact_zalo: r.contact_zalo || '',
    url: null, date: userListingDateStr(r.created_at),
    label: 'Đã duyệt bởi Ver2Solution'
  };
}
function userListingToKiot(r){
  var metaParts = [];
  if(r.description) metaParts.push(r.description);
  if(r.area_sqm != null) metaParts.push(r.area_sqm + ' m²');
  if(r.rent_monthly != null) metaParts.push('Thuê ' + fmtVnd(r.rent_monthly) + 'đ/tháng');
  return {
    id: 'user-' + r.id, source: 'user', kind: 'kiot', _dbId: r.id,
    title: r.title, cat: r.kind, prov: r.province,
    priceNum: r.price_num, areaSqm: r.area_sqm, rentMonthly: r.rent_monthly,
    meta: metaParts.join(' · '), img: (r.images && r.images[0]) || null,
    images: r.images || [], shop_name: r.shop_name || '',
    contact_zalo: r.contact_zalo || '', contact_phone: r.contact_phone || '',
    source_url: r.source_url || '', url: null,
    date: userListingDateStr(r.created_at),
    label: 'Đã duyệt bởi Ver2Solution'
  };
}
function registerUserListing(item){
  if(item && item.id) userListingByCardId[item.id] = item;
  return item;
}
/* Panel chi tiết tin user — INLINE ngay dưới thẻ (đặc tả §6.4, v1).
   Bấm thẻ tin user → chèn panel mở rộng ngay dưới thẻ đó (grid-column
   1/-1 để span hết lưới): mô tả đầy đủ, album ảnh (ảnh bìa lớn + ảnh
   nhỏ bấm để đổi), tên shop + nút liên hệ (Zalo / gọi điện), và — nếu
   người xem là admin đang đăng nhập — nút "Đóng tin". Bấm lại thẻ hoặc
   nút × để đóng. Chỉ mở 1 panel tại 1 thời điểm. */
var userListingOpenPanel = null; // {cardId, el}
var userListingViewerIsAdmin = null; // cache kết quả is_admin()
async function checkViewerIsAdmin(){
  if(userListingViewerIsAdmin !== null) return userListingViewerIsAdmin;
  userListingViewerIsAdmin = false;
  try{
    if(window.McLivestreamAPI && window.McLivestreamAPI.client){
      var r = await window.McLivestreamAPI.client.rpc('is_admin');
      userListingViewerIsAdmin = !!(r && r.data === true);
    }
  }catch(e){ userListingViewerIsAdmin = false; }
  return userListingViewerIsAdmin;
}
function closeUserListingPanel(){
  if(userListingOpenPanel && userListingOpenPanel.el && userListingOpenPanel.el.parentNode){
    userListingOpenPanel.el.parentNode.removeChild(userListingOpenPanel.el);
  }
  userListingOpenPanel = null;
}
function userListingPanelHTML(item){
  var title = item.title || item.name || '(không tiêu đề)';
  var imgs = item.images || [];
  var mainImg = imgs[0] ? '<img data-user-panel-main-img src="' + esc(imgs[0]) + '" alt="" style="width:100%;max-height:320px;object-fit:cover;border-radius:12px;display:block">' : '';
  var thumbs = imgs.length > 1 ? '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' + imgs.map(function(u){
    return '<img data-user-panel-thumb="' + esc(u) + '" src="' + esc(u) + '" alt="" style="width:64px;height:64px;object-fit:cover;border-radius:8px;cursor:pointer">';
  }).join('') + '</div>' : '';
  var details = [];
  if(item.kind === 'lot'){
    if(item.priceNum != null) details.push('Giá bán lô: <b>' + fmtVnd(item.priceNum) + 'đ/' + esc(item.priceUnit || 'cái') + '</b>');
    if(item.qty != null) details.push('Số lượng: <b>' + fmtVnd(item.qty) + '</b>');
  } else if(item.kind === 'factory'){
    if(item.items) details.push('Mặt hàng: <b>' + esc(item.items) + '</b>');
    if(item.moq != null) details.push('Số lượng tối thiểu: <b>' + fmtVnd(item.moq) + '</b>');
    if(item.phone) details.push('Điện thoại xưởng: ' + esc(item.phone));
    if(item.website) details.push('Website: <a href="' + esc(item.website) + '" target="_blank" rel="noopener">' + esc(item.website) + '</a>');
    if(item.address) details.push('Địa chỉ: ' + esc(item.address));
  } else {
    if(item.priceNum != null) details.push('Giá sang nhượng: <b>' + fmtVnd(item.priceNum) + 'đ</b>');
    if(item.areaSqm != null) details.push('Diện tích: ' + fmtVnd(item.areaSqm) + ' m²');
    if(item.rentMonthly != null) details.push('Tiền thuê: ' + fmtVnd(item.rentMonthly) + 'đ/tháng');
  }
  if(item.cat) details.push('Danh mục: ' + esc(catLabel(item.cat)));
  if(item.prov) details.push('Tỉnh / Thành phố: ' + esc(item.prov));
  var zaloVal = item.contact_zalo || '';
  var phoneVal = item.contact_phone || item.phone || '';
  var contact = [];
  if(zaloVal){
    var zaloHref = /^https?:\/\//i.test(zaloVal) ? zaloVal : 'https://zalo.me/' + zaloVal.replace(/[^0-9]/g, '');
    contact.push('<a class="btn btn-primary btn-sm" href="' + esc(zaloHref) + '" target="_blank" rel="noopener">Nhắn Zalo</a>');
  }
  if(phoneVal){
    contact.push('<a class="btn btn-ghost btn-sm" href="tel:' + esc(phoneVal.replace(/[^0-9+]/g, '')) + '">Gọi ' + esc(phoneVal) + '</a>');
  }
  return '<div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start"><h3 style="margin:0">' + esc(title) + '</h3><button type="button" class="btn btn-ghost btn-sm" data-user-panel-close aria-label="Đóng">×</button></div>'
    + '<p style="margin:6px 0"><span style="background:#e6f4ea;color:#137333;font-weight:800;padding:2px 8px;border-radius:999px;font-size:12px">✓ Thành viên đăng</span> <span style="font-size:13px;color:#666">Đăng bởi: ' + esc(item.shop_name || '') + '</span></p>'
    + (item.meta ? '<p style="white-space:pre-wrap;word-break:break-word">' + esc(item.meta) + '</p>' : '')
    + mainImg + thumbs
    + (details.length ? '<ul style="margin:10px 0;padding-left:18px">' + details.map(function(d){ return '<li>' + d + '</li>'; }).join('') + '</ul>' : '')
    + (contact.length ? '<p style="display:flex;gap:8px;flex-wrap:wrap">' + contact.join('') + '</p>' : '')
    + (item.source_url ? '<p style="font-size:13px"><a href="' + esc(item.source_url) + '" target="_blank" rel="noopener">Bài gốc</a></p>' : '')
    + '<p style="font-size:12px;color:#999">Tin do thành viên đăng, đã qua admin duyệt. Ver2Solution không chịu trách nhiệm về giao dịch giữa hai bên.</p>'
    + '<p><button type="button" class="btn btn-ghost btn-sm" data-user-panel-admin-close hidden>Đóng tin (admin)</button></p>';
}
async function toggleUserListingPanel(cardEl, item){
  if(!cardEl || !item) return;
  // Bấm lại thẻ đang mở → đóng.
  if(userListingOpenPanel && userListingOpenPanel.cardId === item.id){
    closeUserListingPanel();
    return;
  }
  closeUserListingPanel();
  var panel = document.createElement('div');
  panel.className = 'user-listing-panel';
  panel.setAttribute('style', 'grid-column:1/-1;background:#fff;border:1px solid var(--line);border-radius:16px;padding:16px;');
  panel.innerHTML = userListingPanelHTML(item);
  if(cardEl.parentNode) cardEl.parentNode.insertBefore(panel, cardEl.nextSibling);
  userListingOpenPanel = {cardId: item.id, el: panel};
  panel.addEventListener('click', function(e){
    var t = e.target;
    if(!t || !t.closest) return;
    var thumb = t.closest('[data-user-panel-thumb]');
    if(thumb){
      var main = panel.querySelector('[data-user-panel-main-img]');
      var src = thumb.getAttribute('data-user-panel-thumb');
      if(main && src) main.src = src;
      return;
    }
    if(t.closest('[data-user-panel-close]')){ closeUserListingPanel(); return; }
    var adminClose = t.closest('[data-user-panel-admin-close]');
    if(adminClose){
      var reason = window.prompt('Lý do đóng tin (hiện cho chủ tin):', '');
      if(reason === null || !String(reason).trim()) return;
      closeUserListingByAdmin(item, String(reason).trim(), panel);
    }
  });
  // Nếu là admin thì hiện nút Đóng tin (đặc tả §5.3/§6.4).
  var isAdmin = await checkViewerIsAdmin();
  if(isAdmin){
    var adminBtn = panel.querySelector('[data-user-panel-admin-close]');
    if(adminBtn) adminBtn.hidden = false;
  }
  if(panel.scrollIntoView) panel.scrollIntoView({behavior:'smooth', block:'nearest'});
}
async function closeUserListingByAdmin(item, reason, panel){
  try{
    if(!window.McLivestreamAPI || !window.McLivestreamAPI.client) throw new Error('Chưa kết nối Supabase.');
    var r = await window.McLivestreamAPI.client.rpc('admin_close_user_listing', {p_kind: item.kind, p_listing_id: item._dbId, p_reason: reason});
    if(r.error) throw r.error;
    closeUserListingPanel();
    var card = document.querySelector('[data-v2s-id="' + item.id + '"]');
    if(card && card.parentNode) card.parentNode.removeChild(card);
  }catch(e){
    if(panel){
      var msg = panel.querySelector('[data-user-panel-admin-msg]');
      if(!msg){
        msg = document.createElement('p');
        msg.setAttribute('data-user-panel-admin-msg', '');
        msg.style.cssText = 'color:#a50e0e;font-size:13px';
        panel.appendChild(msg);
      }
      msg.textContent = 'Chưa đóng được tin: ' + (e && e.message ? e.message : e);
    }
  }
}
/* Bấm thẻ tin user → mở panel inline ngay dưới thẻ thay vì đi theo link.
   Nút sao / bình luận trong thẻ vẫn hoạt động bình thường (bỏ qua click
   xuất phát từ <button>); không mở panel khi bấm vào panel đang mở.
   Đăng ký 1 lần ở cấp document (ủy quyền). */
if(typeof document !== 'undefined' && !document._v2sUserListingClickBound){
  document._v2sUserListingClickBound = true;
  document.addEventListener('click', function(e){
    var t = e.target;
    if(!t || !t.closest) return;
    if(t.closest('button')) return;
    if(t.closest('.user-listing-panel')) return;
    var card = t.closest('[data-v2s-id]');
    if(!card) return;
    var id = card.getAttribute('data-v2s-id');
    if(!id) return;
    var item = userListingByCardId[id];
    if(!item || item.source !== 'user') return;
    e.preventDefault();
    toggleUserListingPanel(card, item);
  });
}
/* Tải tin user đã duyệt rồi chen lên ĐẦU lưới lô (nhóm 1) + lưới xưởng.
   Gọi sau khi bộ lọc đã khởi tạo (initShopPage) thì truyền lotCtl/facCtl
   để làm mới snapshot bộ lọc; trang lô/xưởng riêng không có bộ lọc thì
   gọi không tham số. Chạy nền, không chặn render tin thu thập. */
async function loadUserListings(lotCtl, facCtl){
  try{
    if(!window.McLivestreamAPI) return;
    var lots = await window.McLivestreamAPI.fetchApprovedUserLots();
    var facs = await window.McLivestreamAPI.fetchApprovedUserFactories();
    var userLots = (lots || []).map(userListingToLot);
    var userFacs = (facs || []).map(userListingToFactory);
    userLots.forEach(registerUserListing);
    userFacs.forEach(registerUserListing);
    var g1 = document.getElementById('lotGrid1');
    if(g1 && userLots.length){
      g1.insertAdjacentHTML('afterbegin', userLots.map(function(l){ return lotCardHTML(l, true); }).join(''));
      var s1 = document.getElementById('lotSub1');
      if(s1){
        var n1 = g1.querySelectorAll('.lot-card').length;
        s1.textContent = s1.textContent.replace(/đang có \d+ lô/, 'đang có ' + n1 + ' lô');
      }
    }
    var fg = document.getElementById('factoryGrid');
    if(fg && userFacs.length){
      fg.insertAdjacentHTML('afterbegin', userFacs.map(function(f){ return factoryCardHTML(f, true); }).join(''));
      var fs = document.getElementById('factorySub');
      if(fs){
        var nf = fg.querySelectorAll('.lot-card').length;
        fs.textContent = fs.textContent.replace(/đang có \d+ xưởng/, 'đang có ' + nf + ' xưởng');
      }
    }
    if(lotCtl && typeof lotCtl.refresh === 'function') lotCtl.refresh();
    if(facCtl && typeof facCtl.refresh === 'function') facCtl.refresh();
  }catch(e){ /* im lặng — tin thu thập vẫn hiện */ }
}
function trustStats(models, shops, lots, factories, ref){
  models = models || []; shops = shops || [];
  var provs = {}, online = false, minWage = null, maxRev = null;
  models.forEach(function(m){
    if(m.province === 'Toàn quốc / Live online'){ online = true; }
    else if(m.province){ provs[m.province] = true; }
    if(typeof m.salaryNum === 'number' && m.salaryNum > 0 && (minWage === null || m.salaryNum < minWage)) minWage = m.salaryNum;
    var r = verifiedRevenue(m);
    if(r !== null && (maxRev === null || r > maxRev)) maxRev = r;
  });
  var shopProvs = {}, maxMonthly = null;
  shops.forEach(function(s){
    if(s.province){ shopProvs[s.province] = true; }
    var mm = parseMonthlyMax(s.salary);
    if(mm !== null && (maxMonthly === null || mm > maxMonthly)) maxMonthly = mm;
  });
  var lf = lotFactoryStats(lots, factories, ref);
  return {modelCount: models.length, modelProvinceCount: Object.keys(provs).length, modelOnline: online, minWage: minWage, maxRevenue: maxRev, shopCount: shops.length, shopProvinceCount: Object.keys(shopProvs).length, maxMonthly: maxMonthly, lotCount: lf.lotCount, buyerCount: lf.buyerCount, batchCount: lf.batchCount, factoryCount: lf.factoryCount, factoryProvinceCount: lf.factoryProvinceCount};
}
function renderTrustStats(){
  var st = trustStats(D.models, D.shops || [], D.lots || [], D.factories || []);
  var tm = document.getElementById('trustModels'); if(tm) tm.textContent = String(st.modelCount);
  var ts = document.getElementById('trustShops'); if(ts) ts.textContent = String(st.shopCount);
  var mp = document.getElementById('trustModelProvinces');
  if(mp) mp.textContent = 'Hồ sơ mẫu thật · ' + st.modelProvinceCount + ' tỉnh' + (st.modelOnline ? ' + live online' : '');
  var mpay = document.getElementById('trustModelPay');
  var mnote = document.getElementById('trustModelPayNote');
  if(st.maxRevenue !== null){
    if(mpay) mpay.textContent = 'Doanh thu cao nhất ' + fmtVnd(st.maxRevenue) + 'đ';
    if(mnote) mnote.textContent = '';
  } else if(st.minWage !== null){
    if(mpay) mpay.textContent = 'Lương đề xuất từ ' + fmtVnd(st.minWage) + 'đ/giờ';
    if(mnote) mnote.textContent = '(doanh thu cao nhất chưa có dữ liệu — sẽ thay bằng doanh thu cao nhất khi có)';
  }
  var sp = document.getElementById('trustShopProvinces');
  if(sp) sp.textContent = 'Shop đang tuyển mẫu · ' + st.shopProvinceCount + ' tỉnh';
  var spay = document.getElementById('trustShopPay');
  if(spay && st.maxMonthly !== null) spay.textContent = 'Lương cao nhất ' + st.maxMonthly + ' triệu/tháng';
  /* v76: 6 so lo/xuong tinh tu data.js (nhu mau/shop); so ghi cung trong
     index.html chi la du phong khi JS loi. */
  var tl = document.getElementById('trustLots'); if(tl) tl.textContent = String(st.lotCount);
  var tb = document.getElementById('trustBuyers'); if(tb) tb.textContent = String(st.buyerCount);
  var tba = document.getElementById('trustBatch'); if(tba) tba.textContent = String(st.batchCount);
  var tf = document.getElementById('trustFactories'); if(tf) tf.textContent = String(st.factoryCount);
  var tfp = document.getElementById('trustFactoryProvinces'); if(tfp) tfp.textContent = String(st.factoryProvinceCount);
  /* v205: 8 so lieu muc moi — lay tu data.js bang newObjCount (khop so tren switch + section). */
  [['trustNewObjClassesLive','classesLive'],['trustNewObjClassesMakeup','classesMakeup'],['trustNewObjEventsMarketing','eventsMarketing'],['trustNewObjLogistics','logistics'],['trustNewObjRentals','rentals'],['trustNewObjAgencyAds','agencyAds'],['trustNewObjMovingServices','movingServices'],['trustNewObjLiveEquipment','liveEquipment']].forEach(function(p){ var el = document.getElementById(p[0]); if(el) el.textContent = String(newObjCount(p[1])); });
}
/* v130: sap xep lo/xuong/kiot theo ngay dd/mm/yyyy giam dan. Dung
   parseVnDate co san (khong dung new Date() truc tiep len chuoi
   dd/mm/yyyy vi trinh duyet doc sai thang/ngay; khong dung sortByDateDesc
   co san vi ham do so sanh chuoi ISO yyyy-mm-dd). Array.sort on dinh tu
   ES2019 nen 2 ban ghi cung ngay giu dung thu tu goc trong data.js. */
function sortByDMYDesc(list){
  return (list || []).slice().sort(function(a, b){
    var da = parseVnDate(a.date), db = parseVnDate(b.date);
    var ta = da ? da.getTime() : 0, tb = db ? db.getTime() : 0;
    return tb - ta;
  });
}
/* v130: render 1 muc moi tren trang chu (Kiot / Lo / Xuong) theo dung mau
   2 muc Mau/Shop: section-head (h2 + link "Xem tat ca N →" ben phai) +
   luoi 6 the card-compact (anh 4/5 + ten overlay + dung 2 dong + nut sao,
   withComments=false — khong nut binh luan tren trang chu). Link "Xem tat
   ca N" tinh luc chay tu do dai danh sach, khong hardcode. Muc an han neu
   khong co du lieu. */
function renderHomeSection(sectionId, gridId, linkId, items, label, kind){
  var sec = document.getElementById(sectionId);
  var grid = document.getElementById(gridId);
  if(!sec || !grid) return;
  var list = sortByDMYDesc(items);
  if(!list.length){ sec.style.display = 'none'; return; }
  grid.innerHTML = list.slice(0, 6).map(function(it){
    if(kind === 'factory') return factoryCardHTML(it, false);
    return lotCardHTML(it, false); // lo + kiot dung chung lotCardHTML (nhan dien kiot qua kind/id)
  }).join('');
  var link = document.getElementById(linkId);
  if(link) link.textContent = 'Xem tất cả ' + list.length + ' ' + label + ' →';
}
/* v184: KHOA TRUNG HO SO (anh Tho dan 22:09 12/11/2026) — cung 1 ho so
   khong hien 2 lan tren trang chu. Khoa: id neu co; khong co id thi
   ten + nha cung cap (5 muc moi) / ten + tinh (mau/shop). TUYET DOI
   khong loc theo ten suong: 3 lop makeup cung ten "Khoa Hoc Trang Diem
   Ca Nhan" (cm-04 Juhee HN, cm-09 Jong APhuong DN, cm-11 ANA Beauty
   TP.HCM) la 3 ho so KHAC nhau (khac nha cung cap + tinh). */
function profileKey(item, kind){
  if(!item) return '';
  if(item.id) return 'id:' + item.id;
  /* Khong id ma cung khong co ten -> khong dinh danh duoc, bo qua
     (the khong ten hien len trang chu cung vo nghia). */
  if(!(item.name || '').trim()) return '';
  var name = (item.name || '').trim().toLowerCase();
  var extra = kind === 'newobj' ? (item.provider || '') : (item.province || '');
  return 'name:' + name + '|' + (extra || '').trim().toLowerCase();
}
function dedupeProfiles(items, seen, kind){
  var out = [];
  (items || []).forEach(function(it){
    var k = profileKey(it, kind);
    if(!k || seen[k]) return;
    seen[k] = true;
    out.push(it);
  });
  return out;
}
/* v184: sap xep muc moi theo dateAdded giam dan (ISO yyyy-mm-dd so chuoi
   la dung; Array.sort on dinh tu ES2019 nen cung ngay giu thu tu goc). */
function sortNewObjByDateDesc(list){
  return (list || []).slice().sort(function(a, b){
    var da = a.dateAdded || a.date || '', db = b.dateAdded || b.date || '';
    if(db === da) return 0;
    return db > da ? 1 : -1;
  });
}
/* v184: 5 muc moi tren trang chu — moi muc 1 hang, duoi #xuong-moi.
   Moi muc toi da 6 the (newObjCardHTML, bat buoc co avatar), sap
   dateAdded giam dan, an section neu rong, link "Xem tat ca N →" tinh
   tu du lieu da loc trung. Dung chung seen-set cua trang chu (truyen
   vao tu initHome) de khong trung voi mau/shop/lo/xuong/kiot. */
var HOME_NEWOBJ_SECTIONS = [
  {type: 'classesLive', sectionId: 'home-newobj-classesLive', gridId: 'homeNewObjClassesLive', linkId: 'homeNewObjClassesLiveAll', label: 'lớp học'},
  {type: 'classesMakeup', sectionId: 'home-newobj-classesMakeup', gridId: 'homeNewObjClassesMakeup', linkId: 'homeNewObjClassesMakeupAll', label: 'lớp học'},
  {type: 'eventsMarketing', sectionId: 'home-newobj-eventsMarketing', gridId: 'homeNewObjEventsMarketing', linkId: 'homeNewObjEventsMarketingAll', label: 'sự kiện'},
  {type: 'logistics', sectionId: 'home-newobj-logistics', gridId: 'homeNewObjLogistics', linkId: 'homeNewObjLogisticsAll', label: 'đơn vị vận chuyển'},
  {type: 'rentals', sectionId: 'home-newobj-rentals', gridId: 'homeNewObjRentals', linkId: 'homeNewObjRentalsAll', label: 'mặt bằng'},
  /* v207: 3 mục còn thiếu — trước đây chỉ có 5 mục nên thống kê hiện 11 nhưng
     không có ô nội dung (Agency Ads / Chuyển nhà / Thiết bị Phòng Live). */
  {type: 'agencyAds', sectionId: 'home-newobj-agencyAds', gridId: 'homeNewObjAgencyAds', linkId: 'homeNewObjAgencyAdsAll', label: 'agency'},
  {type: 'movingServices', sectionId: 'home-newobj-movingServices', gridId: 'homeNewObjMovingServices', linkId: 'homeNewObjMovingServicesAll', label: 'dịch vụ chuyển nhà'},
  {type: 'liveEquipment', sectionId: 'home-newobj-liveEquipment', gridId: 'homeNewObjLiveEquipment', linkId: 'homeNewObjLiveEquipmentAll', label: 'thiết bị phòng live'}
];
function renderHomeNewObj(seen){
  seen = seen || {};
  HOME_NEWOBJ_SECTIONS.forEach(function(cfg){
    var sec = document.getElementById(cfg.sectionId);
    var grid = document.getElementById(cfg.gridId);
    if(!sec || !grid) return;
    var items = (D[cfg.type] || []).filter(function(x){ return x && x.avatar; });
    var list = dedupeProfiles(sortNewObjByDateDesc(items), seen, 'newobj');
    if(!list.length){ sec.style.display = 'none'; return; }
    /* v207: mỗi mục trang chủ dàn 2 hàng nội dung (tối đa 12 thẻ/mục, khớp
       quy tắc "Hiện luôn 2 hàng" v198-B). */
    grid.innerHTML = list.slice(0, 12).map(function(it){ return newObjCardHTML(it); }).join('');
    var link = document.getElementById(cfg.linkId);
    if(link) link.textContent = 'Xem tất cả ' + list.length + ' ' + cfg.label + ' →';
  });
}
function initHome(){
  var grid=document.getElementById('homeGrid'); if(!grid) return;
  /* v184: seen-set dung chung toan trang chu — cung 1 ho so khong hien
     2 lan (mau/shop/lo/xuong/kiot + 5 muc moi). */
  var homeSeen = {};
  // v41 trust strip: so lieu tinh dong tu data.js; so tinh trong index.html
  // (20 / 30) chi la du phong neu JS loi — dai khong bao gio trong.
  renderTrustStats();
  // v152: trang chu 12 mau = 12 mau dau cua toan bo danh sach da xoay theo
  // cua so 6 tieng, khong phan biet co anh hay khong (quyet cua user 15:50
  // 11/11 — bo uu tien co anh; thay quy tac v103/v118 hang 1 co anh).
  var shown=dedupeProfiles(homeModels12(D.models), homeSeen, 'model');
  grid.innerHTML=shown.map(cardHTML).join('');
  // v38: hang tin ghim (4 khung) duoi hero search. Muc Tin moi (#homeNews)
  // giu nguyen list 6 bai moi nhat nhu cu (user-directed 22:37 05/11:
  // chi them 1 dong 4 o tin moi, muc Tin tuc de nguyen).
  // v38c: hang tin moi danh so 1-4 (badge tren anh), o nho gon (anh 16:9).
  var pinned=document.getElementById('homePinned');
  if(pinned) pinned.innerHTML=getPinnedRow(D.articles||[]).map(function(a,i){return pinCardHTML(a,i+1);}).join('');
  var news=document.getElementById('homeNews');
  /* v100: muc Tin moi dung chung the tin rut gon (1 anh + 2 dong). */
  if(news) news.innerHTML=D.articles.slice().sort(function(x,y){return (x.date||'')>(y.date||'')?-1:((x.date||'')<(y.date||'')?1:0);}).slice(0,6).map(function(a){
    return newsCardHTML(a);
  }).join('');
  var homeShops=document.getElementById('homeShops');
  if(homeShops) homeShops.innerHTML=dedupeProfiles(defaultShopOrder(D.shops||[]).slice(0,12), homeSeen, 'shop').map(shopCardHTML).join('');
  /* v223 (S2-3): link "Xem tat ca" Mau/Shop ghi so dong tu data.js (truoc day
     ghi cung 219/250 trong index.html, lech ngay khi data.js len 230/270). */
  var homeModelsAll=document.getElementById('homeModelsAll');
  if(homeModelsAll) homeModelsAll.textContent='Xem tất cả '+(D.models||[]).length+' hồ sơ →';
  var homeShopsAll=document.getElementById('homeShopsAll');
  if(homeShopsAll) homeShopsAll.textContent='Xem tất cả '+(D.shops||[]).length+' shop →';
  // v130: 3 muc moi tren trang chu (Kiot -> Lo -> Xuong), sau muc Shop.
  renderHomeSection('kiot-moi', 'homeKiots', 'homeKiotsAll', dedupeProfiles(D.kiots || [], homeSeen, 'kiot'), 'kiot', 'kiot');
  renderHomeSection('lo-moi', 'homeLots', 'homeLotsAll', dedupeProfiles(D.lots || [], homeSeen, 'lot'), 'lô', 'lot');
  renderHomeSection('xuong-moi', 'homeFactories', 'homeFactoriesAll', dedupeProfiles(D.factories || [], homeSeen, 'factory'), 'xưởng', 'factory');
  /* v184: 5 muc moi (lop live/makeup, su kien, logistics, cho thue),
     moi muc 1 hang, duoi #xuong-moi. */
  renderHomeNewObj(homeSeen);
  var form=document.getElementById('heroSearch');
  if(form) form.addEventListener('submit',function(e){e.preventDefault();
    var q=document.getElementById('heroQ').value.trim();
    var prov=document.getElementById('heroProv').value;
    var cat=document.getElementById('heroCat').value;
    var dest='danh-sach-mau.html'; var qs=[]; // A3 10/11 un-swap v96
    if(q) qs.push('q='+encodeURIComponent(q)); if(prov) qs.push('prov='+encodeURIComponent(prov)); if(cat) qs.push('cat='+encodeURIComponent(cat));
    var href=dest+(qs.length?'?'+qs.join('&'):'');
    // v139 (11/11/2026): BO CONG LOC — tim kiem hero (ke ca chon tinh /
    // linh vuc) di thang toi trang ket qua, KHONG doi dang nhap, KHONG
    // tru xu (truoc day dung tinh/linh vuc that thi tru 1 xu nhu bo loc
    // trang danh sach — v90; da go).
    location.href=href;
  });
}
/* Shop page (v22): all public job posts, newest first, rendered from D.shops */
/* v38: trang danh sach shop phan trang 12/trang (2 hang x 6 cot), dong bo
   URL ?page= nhu trang mau; dong dem hien theo trang hien tai. */
/* v38c: nhom linh vuc rong cho bo loc shop — truong product cua shop la
   chu tu do (vd "Thời trang nữ size S–M", "Idol Livestream") nen gom ve
   6 nhom rong de loc. Khong doi du lieu, chi gom nhom khi loc. */
function shopCatGroup(p){
  p = (p||'').toLowerCase();
  if(p.indexOf('thời trang')!==-1 || p.indexOf('áo dài')!==-1 || p.indexOf('giày dép')!==-1 || p.indexOf('công sở')!==-1) return 'Thời trang';
  if(p.indexOf('mỹ phẩm')!==-1 || p.indexOf('nail')!==-1 || p.indexOf('nhuộm')!==-1 || p.indexOf('vòng ngọc')!==-1 || p.indexOf('trang sức')!==-1 || p.indexOf('dược')!==-1) return 'Mỹ phẩm & Làm đẹp';
  if(p.indexOf('gia dụng')!==-1 || p.indexOf('đồ dùng')!==-1 || p.indexOf('hải sản')!==-1) return 'Gia dụng & Đời sống';
  if(p.indexOf('idol')!==-1 || p.indexOf('streamer')!==-1) return 'Idol / Streamer';
  if(p.indexOf('công nghệ')!==-1) return 'Công nghệ';
  return 'Khác';
}
/* v96: bo loc chung trang Shop — anh xa gia tri "Linh vuc / Mat hang" dung
   chung (fUniCat) ve tung he rieng: nhom shop (filterShops), linh vuc mau
   (hub/filterModels), ma lo/xuong (data-cat). Gia tri khong co tuong duong
   o lo/xuong (gia dung, idol, cong nghe, khac) tra ve null -> khong khop
   the nao (hien "Chua co du lieu"), khong bia du lieu. Gia tri da la ten
   nhom (vd tu URL cu ?cat=Thời trang) duoc giu nguyen. */
var UNI_CAT_TO_SHOP = {'quan-ao':'Thời trang','nam':'Thời trang','nu':'Thời trang','tre-em':'Thời trang','giay-dep':'Thời trang','my-pham':'Mỹ phẩm & Làm đẹp','phu-kien':'Khác','tpcn':'Mỹ phẩm & Làm đẹp','gia-dung':'Gia dụng & Đời sống','idol':'Idol / Streamer','cong-nghe':'Công nghệ','khac':'Khác'};
var UNI_CAT_TO_MODEL = {'quan-ao':'Thời trang','nam':'Thời trang','nu':'Thời trang','tre-em':'Thời trang','giay-dep':'Thời trang','my-pham':'Mỹ phẩm','phu-kien':'Chung / Đa ngành','tpcn':'Chung / Đa ngành','gia-dung':'Gia dụng','idol':'Chung / Đa ngành','cong-nghe':'Chung / Đa ngành','khac':'Chung / Đa ngành'};
var UNI_CAT_TO_LOTFAC = {'quan-ao':'quan-ao','nam':'nam','nu':'nu','tre-em':'tre-em','giay-dep':'giay-dep','my-pham':'my-pham','phu-kien':'phu-kien','tpcn':'tpcn'};
var SHOP_TO_UNI_CAT = {'Thời trang':'quan-ao','Mỹ phẩm & Làm đẹp':'my-pham','Gia dụng & Đời sống':'gia-dung','Idol / Streamer':'idol','Công nghệ':'cong-nghe','Khác':'khac'};
function uniCatToShop(v){ return v ? (UNI_CAT_TO_SHOP[v] || v) : ''; }
function uniCatToModel(v){ return v ? (UNI_CAT_TO_MODEL[v] || v) : ''; }
function uniCatToLotFac(v){ return v ? (UNI_CAT_TO_LOTFAC[v] || null) : ''; }
function shopCatToUni(v){ return v ? (SHOP_TO_UNI_CAT[v] || v) : ''; }
/* v96-swap (08/11): doi noi dung 2 trang — trang Shop hien DANH SACH MAU,
   trang Mau hien DANH SACH SHOP. Anh xa nguoc ten linh vuc mau -> ma dung
   chung, de dien san dropdown fUniCat tu URL ?cat= ten linh vuc mau (tu
   hero search / chip trang chu / hub). "Thực phẩm" khong co ma dung chung
   tuong duong nen khong co trong bang nay; truong hop do initList dung
   bien rieng uniModelCat de loc truc tiep theo ten linh vuc mau. */
var MODEL_CAT_TO_UNI = {'Thời trang':'quan-ao','Mỹ phẩm':'my-pham','Gia dụng':'gia-dung','Chung / Đa ngành':'khac'};
/* v96-swap: kieu sap xep cua bo loc chung (luong gio / luong thang) dich
   sang sap xep mau — luong gio = luong yeu cau theo gio cua mau
   (salaryNum); luong thang khong co truong tuong duong o mau nen dich
   sang doanh thu da xac minh (proxy thu nhap thang cua mau). */
function uniSortToModelSort(v){
  if(v==='hourly-asc') return 'wage-asc';
  if(v==='hourly-desc') return 'wage-desc';
  if(v==='monthly-asc') return 'revenue-asc';
  if(v==='monthly-desc') return 'revenue-desc';
  return '';
}
/* v96: tinh dung chung — gia tri 'TP. Hồ Chí Minh' dung cho shop/mau; du
   lieu xuong dung 'TP.HCM' (data-prov) nen doi khi loc xuong. */
function uniProvToFactory(prov){ return prov === 'TP. Hồ Chí Minh' ? 'TP.HCM' : prov; }
function filterShops(list, f){
  return list.filter(function(s){
    /* v223 (S2-5): so tinh qua normProv — 'Toàn quốc' (12 shop) phai khop
       option 'Toàn quốc / Live online' (xem MERGED_PROV). */
    if(f.prov && normProv(s.province)!==f.prov) return false;
    if(f.cat && shopCatGroup(s.product)!==f.cat) return false;
    /* v42: loc gio lam theo truong shifts (suy ra tu req, xem data.js).
       Quyet dinh: shop fulltime hien trong MOI ca (Sang/Chieu/Toi) vi fulltime
       lam ca ngay, dong thoi hien khi loc rieng "Fulltime". Shop khong co gio
       (shifts rong) chi hien khi chon "Tất cả giờ". */
    if(f.shift){
      var sh = s.shifts || [];
      /* v223 (S2-5): '__none__' = shop chua ghi gio lam (shifts rong, 214/270) —
         truoc day nhom nay khong thuoc option gio lam nao nen tong option chi 112. */
      if(f.shift === '__none__'){ if(sh.length) return false; }
      else if(f.shift === 'fulltime'){ if(sh.indexOf('fulltime') === -1) return false; }
      else if(sh.indexOf(f.shift) === -1 && sh.indexOf('fulltime') === -1) return false;
    }
    /* v45: loc theo loai luong + muc luong toi thieu. payMin chi ap dung khi
       da chon loai luong; khong chon loai thi payMin bi bo qua (o nhap bi
       disabled o giao dien). */
    if(f.payType === 'hourly' && parseHourlyMin(s.salary) === null) return false;
    if(f.payType === 'monthly' && parseMonthlyMax(s.salary) === null) return false;
    /* v223 (S2-5): '__none__' = shop chua ghi luong parse duoc (khong gio, khong
       thang — vd 'Thỏa thuận năng lực') — truoc day nhom nay khong thuoc option
       luong nao nen tong option chi 126. */
    if(f.payType === '__none__' && (parseHourlyMin(s.salary) !== null || parseMonthlyMax(s.salary) !== null)) return false;
    if(f.payMin != null && f.payType === 'hourly'){ var h = parseHourlyMin(s.salary); if(h === null || h < f.payMin) return false; }
    if(f.payMin != null && f.payType === 'monthly'){ var mm = parseMonthlyMax(s.salary); if(mm === null || mm < f.payMin) return false; }
    return true;
  });
}
/* v103: so luong that trong () o moi option loc (user chot 21:46–21:47 08/11).
   Quy tac chung: moi option hien "Nhan (N)" voi N = so muc THAT trong du
   lieu khop option do, tinh luc chay bang JS tu du lieu da nap (KHONG ghi
   cung so vao HTML — du lieu thu thap them hang ngay). Option "Tat ca..."
   hien tong so. Option 0 muc van hien "(0)", khong an. Chi ap cho option
   loc theo gia tri roi rac (tinh, linh vuc, ca lam, loai luong); KHONG ap
   cho option sap xep va o nhap so. So dem chay qua dung ham loc that
   (filterModels/filterShops) nen luon khop ket qua loc that.
   GIU NGUYEN value (BAT BUOC): option tinh trong HTML khong co thuoc tinh
   value (vd <option>Ha Noi</option>) nen value mac dinh = text. Khi viet
   lai nhan thanh "Ha Noi (5)" PHAI dat value tuong minh (value="Ha Noi") —
   neu khong bo loc se gui "Ha Noi (5)" va loc sai. */
function countLabel(label, n){ return label + ' (' + n + ')'; }
function applyOptionCounts(sel, counts, total){
  if(!sel || !sel.options) return;
  var opts = sel.options;
  for(var i = 0; i < opts.length; i++){
    var o = opts[i];
    var rawVal = (o.getAttribute ? o.getAttribute('value') : null);
    var val = (rawVal !== null && rawVal !== undefined) ? rawVal : o.textContent;
    var label = o.textContent;
    var m = label.match(/^(.*) \(\d+\)$/);
    if(m) label = m[1];
    var n = (val === '') ? total : (typeof counts === 'function' ? counts(val) : (counts[val] == null ? 0 : counts[val]));
    if(o.setAttribute) o.setAttribute('value', val);
    o.value = val;
    o.textContent = countLabel(label, n);
    // v114 (P3-9): an muc 0 ket qua — tru "Tat ca" (value '') va muc
    // dang duoc chon (de nguoi dung van thay lua chon hien tai cua minh).
    var isAll = (val === '');
    var isSelected = (o.selected === true);
    var hideZero = (!isAll && !isSelected && n === 0);
    if (o.hidden !== undefined) o.hidden = hideZero;
    o.disabled = hideZero;
  }
}
function initOptionCounts(){
  var models = D.models || [], shops = D.shops || [], articles = D.articles || [], kiots = D.kiots || [];
  var hp = document.getElementById('heroProv');
  if(hp) applyOptionCounts(hp, function(v){ return filterModels(models, {prov: v}).length; }, models.length);
  var hc = document.getElementById('heroCat');
  if(hc) applyOptionCounts(hc, function(v){ return filterModels(models, {cat: v}).length; }, models.length);
  var up = document.getElementById('fUniProv');
  if(up) applyOptionCounts(up, function(v){ return filterModels(models, {prov: v}).length; }, models.length);
  var uc = document.getElementById('fUniCat');
  // v118 (P2-9): rebuild danh sach option linh vuc theo tab dang chon
  // TRUOC khi gan so — initOptionCounts chay luc mo trang (khong qua
  // refreshUniCounts/setCat) nen phai rebuild o day; neu khong, o fUniCat
  // van giu 12 ma uni cu voi so dem mau (5 o cung (25)).
  rebuildUniCatOptions(getUniCat());
  if(uc) applyOptionCounts(uc, function(v){ return filterModels(models, {cat: uniCatToModel(v)}).length; }, models.length);
  var us = document.getElementById('fUniShift');
  /* v111 (muc 6): dem ca theo ham loc THAT (filterModels) — truoc day
     'fulltime' bi ghi cung = tong vi initList bo qua fulltime. Doi chieu
     data.js 09/11: 0/37 mau co ca fulltime (khong mau nao co shifts
     fulltime) nen dem that la (0); sang (3), chieu (4), toi (6). */
  if(us) applyOptionCounts(us, function(v){ return filterModels(models, {shift: v}).length; }, models.length);
  var upt = document.getElementById('fUniPayType');
  /* v111 (muc 6): dem loai luong theo ham loc THAT — truoc day ghi cung
     = tong cho ca hai (filterModels bo qua payType). Doi chieu data.js
     09/11: gio (3) — chi th-03/th-08/th-11 co salaryNum; thang (0) —
     0 mau co doanh thu da xac minh (proxy luong thang cua mau). */
  if(upt) applyOptionCounts(upt, function(v){ return filterModels(models, {payType: v}).length; }, models.length);
  var sp = document.getElementById('fShProv');
  if(sp) applyOptionCounts(sp, function(v){ return filterShops(shops, {prov: v}).length; }, shops.length);
  var sc = document.getElementById('fShCat');
  if(sc) applyOptionCounts(sc, function(v){ return filterShops(shops, {cat: uniCatToShop(v)}).length; }, shops.length);
  var ss = document.getElementById('fShShift');
  if(ss) applyOptionCounts(ss, function(v){ return filterShops(shops, {shift: v}).length; }, shops.length);
  var spt = document.getElementById('fShPayType');
  if(spt) applyOptionCounts(spt, function(v){ return filterShops(shops, {payType: v}).length; }, shops.length);
  var nc = document.getElementById('newsCat');
  if(nc) applyOptionCounts(nc, function(v){ var n = 0; articles.forEach(function(a){ if(a.cat === v) n++; }); return n; }, articles.length);
  var kp = document.getElementById('kiotProv');
  // v166 (N8): đếm theo đúng chuẩn hóa của bộ lọc kiot (normProvKiot)
  // — trước đây đếm prov thô (k.prov === v) nên dropdown ghi
  // 'TP. Hồ Chí Minh (17)' trong khi lọc khớp 36 tin (đã gộp
  // 'TP.HCM' + Bình Dương qua normProv).
  if(kp) applyOptionCounts(kp, function(v){ var n = 0; kiots.forEach(function(k){ if(normProvKiot(k.prov) === v) n++; }); return n; }, kiots.length);
  var kc = document.getElementById('kiotCat');
  if(kc) applyOptionCounts(kc, function(v){ var n = 0; kiots.forEach(function(k){ if(k.cat === v) n++; }); return n; }, kiots.length);
  /* v182: so dem (N) tren cac nut muc con trong switch + 3 option con
     logistics trong loc shop (fShopLogOpt). */
  refreshNewObjCatCounts();
  refreshShopLogOptCounts();
}
/* v111 (muc 1+9): so dem o 2 o dung chung (fUniProv/fUniCat) doi theo tab
   dang chon — truoc day luc nao cung dem theo mau (37) nen o tab Xuong
   "Nam Dinh (0)" sai voi du lieu xuong (3 xuong, gom TBC). Tab Lo/Xuong
   dem theo du lieu cua chinh no (tinh lo quet tu tieu de/meta; tinh xuong
   quy ve ten sau sap nhap qua normProv). */
function uniProvCount(cat, prov){
  var ncfg = NEWOBJ_UNI_CATS[cat];
  if(ncfg) return newObjProvCount(ncfg.type, prov);
  if(cat === 'lot'){ var n = 0; (D.lots || []).forEach(function(l){ if(lotProvOf(l) === prov) n++; }); return n; }
  if(cat === 'factory'){ var nf = 0; (D.factories || []).forEach(function(f){ if(normProv(f.prov) === prov) nf++; }); return nf; }
  return filterModels(D.models || [], {prov: prov}).length;
}
function uniCatCount(cat, code){
  /* v182: o Linh vuc bi khoa khi chon muc con moi nen so dem khong hien —
     tra 0 cho gon (khong anh huong loc). */
  if(NEWOBJ_UNI_CATS[cat]) return 0;
  if(cat === 'lot'){ var n = 0; (D.lots || []).forEach(function(l){ if(l.cat === code) n++; }); return n; }
  if(cat === 'factory'){ var nf = 0; (D.factories || []).forEach(function(f){ if(f.cat === code) nf++; }); return nf; }
  return filterModels(D.models || [], {cat: uniCatToModel(code)}).length;
}
function uniTotal(cat){
  var ncfg = NEWOBJ_UNI_CATS[cat];
  if(ncfg) return newObjCount(ncfg.type);
  if(cat === 'lot') return (D.lots || []).length;
  if(cat === 'factory') return (D.factories || []).length;
  return (D.models || []).length;
}
function refreshUniCounts(cat){
  cat = cat || getUniCat();
  // v118 (P2-9): doi ca danh sach option linh vuc theo tab (xem
  // rebuildUniCatOptions) truoc khi gan so — o loc phai hien dung cac
  // nhom co that trong du lieu cua tab dang chon.
  rebuildUniCatOptions(cat);
  /* v214: danh sach tinh DUNG THEO MUC (chi tinh co du lieu cua muc) thay
     vi chi cap nhat so tren option cung san — truoc day tinh chi co trong
     du lieu cua muc con (vd Thai Nguyen/Hai Phong cua agency, Son La cua
     thiet bi) khong co trong danh sach cung nen khong loc duoc. */
  rebuildProvOptions('fUniProv', cat, function(v){ return uniProvCount(cat, v); }, uniTotal(cat));
  var uc = document.getElementById('fUniCat');
  if(uc) applyOptionCounts(uc, function(v){ return uniCatCount(cat, v); }, uniTotal(cat));
}
/* v182: cap nhat so dem o Tinh cua loc shop theo hang muc dang chon tren
   switch shop (mac dinh dem theo shop; muc con moi dem theo mang cua no). */
function refreshShopProvCounts(cat){
  var sp = document.getElementById('fShProv');
  if(!sp) return;
  var ncfg = NEWOBJ_UNI_CATS[cat];
  /* v214: nhu refreshUniCounts — danh sach tinh dung theo muc (chi tinh co
     du lieu cua muc), khong chi cap nhat so tren option cung. */
  if(ncfg){
    rebuildProvOptions('fShProv', cat, function(v){ return newObjProvCount(ncfg.type, v); }, newObjCount(ncfg.type));
  } else {
    rebuildProvOptions('fShProv', cat, function(v){ return filterShops(D.shops || [], {prov: v}).length; }, (D.shops || []).length);
  }
}
/* v214: danh sach tinh theo MUC DANG CHON — chi hien tinh co du lieu cua muc
   (theo thu tu D.provinces) + so dem that; doi muc thi danh sach doi theo.
   Dung setSelectOptions (mau v118) de giu gia tri dang chon neu van hop le.
   countFn tra so luong theo dung ham loc THAT cua muc (newObjProvCount /
   filterShops / filterModels qua uniProvCount) nen so trong () luon khop
   so the loc ra. */
function provEntriesForCat(cat, countFn){
  var entries = [];
  (D.provinces || []).forEach(function(p){
    var n = countFn(p);
    if(n > 0) entries.push({value: p, text: countLabel(p, n)});
  });
  return entries;
}
function rebuildProvOptions(selId, cat, countFn, total){
  var sel = document.getElementById(selId);
  if(!sel || !sel.options || !sel.options.length) return;
  var allLabel = sel.options[0].textContent.replace(/ \(\d+\)$/, '');
  var defs = [{value: '', text: countLabel(allLabel, total)}].concat(provEntriesForCat(cat, countFn));
  setSelectOptions(sel, defs);
}
/* v182: so dem 3 option con cua muc logistics trong loc shop (fShopLogOpt). */
function refreshShopLogOptCounts(){
  var slo = document.getElementById('fShopLogOpt');
  if(!slo) return;
  applyOptionCounts(slo, function(v){ var n = 0; (D.logistics || []).forEach(function(x){ if(x && x.avatar && x.logisticsOption === v) n++; }); return n; }, newObjCount('logistics'));
}
/* v118 (P2-9): so dem o loc linh vuc phai dem theo linh vuc THAT trong
   data.js. Truoc day o fUniCat dung chung 12 ma uni (shop) cho ca 3 tab:
   5 ma (phu-kien/tpcn/idol/cong-nghe/khac) cung anh xa ve 1 nhom mau
   "Chung / Đa ngành" (25) nen 5 o hien cung (25), tong 222 vuot xa 57
   ho so — trong nhu copy-paste. Tu v118, o linh vuc hien dung cac nhom
   co THAT trong du lieu cua tab dang chon:
   - Tab Tim Mau: 5 nhom mau trong data.js (Thời trang/Mỹ phẩm/Gia dụng/
     Chung / Đa ngành/Thực phẩm), dem 17/10/2/25/3, tong 57.
   - Tab Lo/Xuong: 12 ma uni (lot/factory luu cat bang ma uni), dem theo
     l.cat/f.cat that.
   - Trang Mau (fShCat): 6 nhom shop suy tu san pham (shopCatGroup),
     dem 30/9/7/14/1/35, tong 96. */
function selectHasValue(sel, val){
  if(!sel || !sel.options) return false;
  for(var i = 0; i < sel.options.length; i++){ if(sel.options[i].value === val) return true; }
  return false;
}
function setSelectOptions(sel, defs){
  if(!sel || !sel.options || !defs || !defs.length) return false;
  var cur = null;
  try { cur = sel.value; } catch (e) { cur = null; }
  // Xoa option cu (length=0 chay ca tren HTMLSelectElement that lan
  // mock array trong test), roi them option moi.
  try { sel.options.length = 0; } catch (e) { return false; }
  var doc = (typeof document !== 'undefined') ? document : null;
  defs.forEach(function(d){
    var o = null;
    if(doc && typeof doc.createElement === 'function'){ try { o = doc.createElement('option'); } catch (e) { o = null; } }
    if(!o) o = { value: '', textContent: '' };
    try { if(o.setAttribute) o.setAttribute('value', d.value); } catch (e) {}
    o.value = d.value;
    o.textContent = d.text;
    if(sel.appendChild && typeof sel.appendChild === 'function'){ try { sel.appendChild(o); return; } catch (e) {} }
    try { sel.options.push(o); } catch (e) {}
  });
  // Giu gia tri cu neu van con trong danh sach moi, khong thi ve ''.
  var keep = false;
  for(var i = 0; i < defs.length; i++){ if(defs[i].value === cur){ keep = true; break; } }
  try { sel.value = keep ? cur : ''; } catch (e) {}
  return true;
}
function modelCatOptions(){
  // Nhom mau THAT trong data.js, theo thu tu xuat hien dau tien.
  var seen = [], out = [{ value: '', text: 'Tất cả lĩnh vực' }];
  (D.models || []).forEach(function(m){
    var c = String(m.cat || '').trim();
    if(c && seen.indexOf(c) === -1){ seen.push(c); out.push({ value: c, text: c }); }
  });
  return out;
}
function shopGroupOptions(){
  // Nhom shop THAT suy tu san pham (shopCatGroup), theo thu tu xuat hien.
  var seen = [], out = [{ value: '', text: 'Tất cả lĩnh vực' }];
  (D.shops || []).forEach(function(s){
    var g = shopCatGroup(s.product);
    if(g && seen.indexOf(g) === -1){ seen.push(g); out.push({ value: g, text: g }); }
  });
  return out;
}
// 12 ma uni goc cua o fUniCat (HTML tinh) — dung lai cho tab Lo/Xuong.
var UNI_CAT_DEFS = [
  { value: '', text: 'Tất cả lĩnh vực' },
  { value: 'quan-ao', text: 'Quần áo' },
  { value: 'nam', text: 'Nam' },
  { value: 'nu', text: 'Nữ' },
  { value: 'tre-em', text: 'Trẻ em' },
  { value: 'giay-dep', text: 'Giày dép' },
  { value: 'my-pham', text: 'Mỹ phẩm' },
  { value: 'phu-kien', text: 'Phụ kiện' },
  { value: 'tpcn', text: 'TPCN' },
  { value: 'gia-dung', text: 'Gia dụng & Đời sống' },
  { value: 'idol', text: 'Idol / Streamer' },
  { value: 'cong-nghe', text: 'Công nghệ' },
  { value: 'khac', text: 'Khác' }
];
function rebuildUniCatOptions(cat){
  if (typeof document === 'undefined') return false;
  var sel = document.getElementById('fUniCat');
  if(!sel) return false;
  if(cat === 'model') return setSelectOptions(sel, modelCatOptions());
  return setSelectOptions(sel, UNI_CAT_DEFS);
}
function rebuildShopCatOptions(){
  if (typeof document === 'undefined') return false;
  var sel = document.getElementById('fShCat');
  if(!sel) return false;
  return setSelectOptions(sel, shopGroupOptions());
}
/* v96: thanh truot chon hang muc cho bo loc chung trang Mau (danh-sach-mau.html). A3 10/11 un-swap v96.
   1 khung loc dung chung cho 3 hang muc; truong khong ap dung cho hang muc
   dang chon bi khoa (disabled + mo) va xoa gia tri. Nut Ap dung chay dung bo
   loc cua hang muc dang chon; nut Dat lai xoa toan bo + ve hang muc mac dinh.
   Quy tac khoa: Tinh + Linh vuc dung chung (khong khoa); Sap xep + Gio lam +
   Loai luong + Muc luong toi thieu chi cho Tim Mau; Gia tri lo + So luong lo
   chi cho Lo xa kho; Gia tri don + So luong toi thieu chi cho Xuong may.
   v96-swap (08/11): hang muc Tim Mau render GRID MAU (#listGrid) tren
   chinh trang Shop (doi noi dung 2 trang) — modelRender la ham render
   grid mau cua initList; cong diem dung category 'model'. */
var UNI_LOCKABLE = {
  model: ['fUniCat','fUniSort','fUniShift','fUniPayType','fUniPayMin'],
  lot: ['fUniCat','fUniLotPrice','fUniLotQty'],
  factory: ['fUniCat','fUniFacValue','fUniFacMoq'],
  /* v210: 2 muc lop hoc CHUYEN SANG trang Mau (danh-sach-shop.html) nen
     khong con trong map nay nua; 3 muc shop (su kien/logistics/agency)
     CHUYEN VE trang Shop (danh-sach-mau.html) — chi o Tinh dung chung co
     nghia (fUniProv khong nam trong danh sach khoa nen luon mo); mo them
     o Sap xep theo gia (fShopPriceSort) cho ca 3 muc + o Hinh thuc van
     chuyen (fShopLogOpt) chi cho logistics. */
  'logistics': ['fShopPriceSort', 'fShopLogOpt'],
  'event-mkt': ['fShopPriceSort'],
  'agency-ads': ['fShopPriceSort']
};
var UNI_LOCKABLE_ALL = ['fUniCat','fUniSort','fUniShift','fUniPayType','fUniPayMin','fUniLotPrice','fUniLotQty','fUniFacValue','fUniFacMoq','fShopPriceSort','fShopLogOpt'];
function getUniCat(){
  // v118 (P2-9): phong thu — moi truong test co the khong co
  // document.querySelector; luc do tab mac dinh la 'model' (nhu khi khong
  // co nut .active). Tren trinh duyet that hanh vi khong doi.
  if (typeof document === 'undefined' || typeof document.querySelector !== 'function') return 'model';
  var b = document.querySelector('.uni-cat-btn.active');
  return b ? b.getAttribute('data-uni-cat') : 'model';
}
function setUniCatFieldStates(cat){
  UNI_LOCKABLE_ALL.forEach(function(id){
    var el = document.getElementById(id);
    if(!el) return;
    var allowed = UNI_LOCKABLE[cat] && UNI_LOCKABLE[cat].indexOf(id) !== -1;
    var wrap = el.closest ? el.closest('.uni-field') : null;
    if(id === 'fUniPayMin'){
      /* rieng o luong toi thieu: do mo/khoa theo loai luong (syncPayMin);
         o day chi xu ly khi roi khoi hang muc Tim Mau. */
      if(cat !== 'model'){ el.disabled = true; el.value = ''; if(wrap) wrap.classList.add('locked'); }
      else if(wrap) wrap.classList.remove('locked');
      return;
    }
    if(allowed){ el.disabled = false; if(wrap) wrap.classList.remove('locked'); }
    else { el.disabled = true; el.value = ''; if(wrap) wrap.classList.add('locked'); }
  });
}
/* v96: dong bo khoi hub "Tim mau cho 11.11" theo o Tinh + Linh vuc dung chung
   khi ap dung hang muc Tim Mau — goi truc tiep ham render cua hub (khong qua
   cong diem, vi nut Ap dung da qua cong 'shop'). */
function syncHubFromUni(){
  var hubProv = document.getElementById('hubProv');
  var hubCat = document.getElementById('hubCat');
  var box = document.getElementById('hubResults');
  if(!hubProv || !hubCat || !box) return;
  hubProv.value = document.getElementById('fUniProv').value;
  var mc = uniCatToModel(document.getElementById('fUniCat').value);
  var ok = false;
  for(var i = 0; i < hubCat.options.length; i++){ if(hubCat.options[i].value === mc){ ok = true; break; } }
  hubCat.value = ok ? mc : '';
  if(typeof box._hubRender === 'function'){ box._hubRender(); }
}
function initUniCatSwitch(lotCtl, facCtl, modelRender, syncPayMinFn, onResetFn){
  var btns = document.querySelectorAll('.uni-cat-btn');
  if(!btns.length) return;
  var applyBtn = document.getElementById('uniApplyBtn');
  var resetBtn = document.getElementById('uniResetBtn');
  function collapseSection(id, moreId){
    var s = document.getElementById(id);
    if(s) s.classList.add('collapsed');
    /* v213: 2 muc lop hoc do refreshClassMoreBtn lam chu nut (hien so luong). */
    if(CLASS_MORE[id]){ refreshClassMoreBtn(id); return; }
    var b = moreId ? document.getElementById(moreId) : null;
    if(b){ b.setAttribute('aria-expanded','false'); b.textContent='Xem thêm ↓'; }
  }
  // v111 (muc 1): mo muc (nguoc collapseSection).
  // v139 (11/11/2026): chon doi tuong KHONG cuon man hinh — chi mo/dong
  // muc tai cho; cuon toi ket qua chi xay ra khi bam "Ap dung loc"
  // (gateFilterApply -> scrollToResults / apply() cua section).
  function expandSection(id, moreId){
    var s = document.getElementById(id);
    if(s){
      s.classList.remove('collapsed');
    }
    /* v213: 2 muc lop hoc do refreshClassMoreBtn lam chu nut (mo rong -> "Thu gọn ↑"). */
    if(CLASS_MORE[id]){ refreshClassMoreBtn(id); return; }
    var b = moreId ? document.getElementById(moreId) : null;
    if(b){ b.setAttribute('aria-expanded','true'); b.textContent='Thu gọn ↑'; }
  }
  function clearUniCount(){
    var c = document.getElementById('uniCount'); if(c) c.textContent = '';
    var e = document.getElementById('uniEmpty'); if(e) e.hidden = true;
  }
  function setCat(cat){
    btns.forEach(function(b){
      var on = b.getAttribute('data-uni-cat') === cat;
      b.classList.toggle('active', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    setUniCatFieldStates(cat);
    /* v210: so dem 3 option con cua muc logistics (fShopLogOpt da chuyen
       sang trang Shop cung section) — chi cap nhat khi dang chon logistics. */
    if(cat === 'logistics') refreshShopLogOptCounts();
    if(typeof syncPayMinFn === 'function') syncPayMinFn();
    clearUniCount();
    // v111 (muc 1+9): so dem o dung chung doi theo tab + chuyen tab MO
    // muc tuong ung — truoc day setCat chi doi class active nen muc
    // Lo/Xuong van collapsed (the khong hien) va #listGrid van la 12 the Mau.
    // v139: chon tab chi mo/dong muc, KHONG cuon man hinh.
    refreshUniCounts(cat);
    refreshNewObjCatCounts(); /* v214: an so cua nut vua chon, hien lai so cua nut vua bo chon */
    /* v182: muc con moi — chi hien section cua muc do (an cac section moi
       con lai), mo rong no; thu gon Lo/Xuong + section moi con lai de khi
       quay lai trang thai mac dinh van dung 1 hang. */
    var ncfg = NEWOBJ_UNI_CATS[cat];
    if(ncfg){
      showOnlyNewObjSection(cat);
      collapseSection('lo-hang-xa-kho', 'lotMoreBtn');
      collapseSection('xuong-may-gia-cong', 'factoryMoreBtn');
      collapseSection('su-kien-marketing', 'eventMarketingMoreBtn');
      collapseSection('logistics-trung-viet', 'logisticsMoreBtn');
      collapseSection('agency-ads-livestream', 'agencyAdsMoreBtn');
      expandSection(ncfg.sectionId, ncfg.moreBtnId);
    } else if(cat === 'lot'){
      showAllNewObjSections();
      collapseSection('xuong-may-gia-cong', 'factoryMoreBtn');
      collapseSection('su-kien-marketing', 'eventMarketingMoreBtn');
      collapseSection('logistics-trung-viet', 'logisticsMoreBtn');
      collapseSection('agency-ads-livestream', 'agencyAdsMoreBtn');
      expandSection('lo-hang-xa-kho', 'lotMoreBtn');
    } else if(cat === 'factory'){
      showAllNewObjSections();
      collapseSection('lo-hang-xa-kho', 'lotMoreBtn');
      collapseSection('su-kien-marketing', 'eventMarketingMoreBtn');
      collapseSection('logistics-trung-viet', 'logisticsMoreBtn');
      collapseSection('agency-ads-livestream', 'agencyAdsMoreBtn');
      expandSection('xuong-may-gia-cong', 'factoryMoreBtn');
    } else {
      showAllNewObjSections();
      collapseSection('lo-hang-xa-kho', 'lotMoreBtn');
      collapseSection('xuong-may-gia-cong', 'factoryMoreBtn');
      collapseSection('su-kien-marketing', 'eventMarketingMoreBtn');
      collapseSection('logistics-trung-viet', 'logisticsMoreBtn');
      collapseSection('agency-ads-livestream', 'agencyAdsMoreBtn');
    }
  }
  btns.forEach(function(b){
    b.addEventListener('click', function(){ setCat(b.getAttribute('data-uni-cat')); });
  });
  setUniCatFieldStates(getUniCat());
  if(typeof syncPayMinFn === 'function') syncPayMinFn();
  if(applyBtn){
    applyBtn.addEventListener('click', function(){
      var cat = getUniCat();
      var b = applyBtn;
      /* v182: muc con moi — KHONG qua cong diem (5 loai moi chua co points
         category, giong nut Ap dung rieng cua section).
         v186: loc cua section doc TRUC TIEP tu loc chung tren top (tinh
         fUniProv + sap xep hoc phi fUniClassSort) — khong con dong bo sang
         loc rieng; goi apply cua section (loc dung mang du lieu cua muc
         do, ket hop loc tinh); so dem phan anh sang o dem chung. */
      var ncfg = NEWOBJ_UNI_CATS[cat];
      if(ncfg){
        var h = (typeof window !== 'undefined' && window.V2S_NEWOBJ_FILTERS) ? window.V2S_NEWOBJ_FILTERS[ncfg.sectionId] : null;
        if(h && h.apply) h.apply(true);
        var c = document.getElementById('uniCount');
        var sc = document.getElementById(ncfg.countId);
        if(c && sc) c.textContent = sc.textContent;
        closeFilterOf(b);
        /* v213 (anh Thọ dặn 23:58 ngày 13/11 — TAT CA muc loc sau khi Ap dung
           ra ket qua thi TU CUON toi ket qua): apply(true) da cuon toi the
           khop dau tien / bang "Chua co du lieu" (ghi de phan cam cuon khi
           Ap dung cua v207). Bam hang muc/switch/?newobj= van KHONG cuon. */
        return;
      }
      if(cat === 'lot'){
        if(lotCtl && lotCtl.apply) return gateFilterApply('lot', 'danh-sach-mau.html', function(){ lotCtl.apply(); closeFilterOf(b); }, b);
      } else if(cat === 'factory'){
        if(facCtl && facCtl.apply) return gateFilterApply('factory', 'danh-sach-mau.html', function(){ facCtl.apply(); closeFilterOf(b); }, b);
      }
      return gateFilterApply('model', 'danh-sach-mau.html', function(){
        if(typeof modelRender === 'function') modelRender(1);
        syncHubFromUni();
        collapseSection('lo-hang-xa-kho', 'lotMoreBtn');
        collapseSection('xuong-may-gia-cong', 'factoryMoreBtn');
        closeFilterOf(b);
      }, b);
    });
  }
  if(resetBtn){
    resetBtn.addEventListener('click', function(){
      var card = document.getElementById('uniFilter');
      if(card){ card.querySelectorAll('select, input').forEach(function(el){ el.value = ''; }); }
      if(lotCtl && lotCtl.reset) lotCtl.reset();
      if(facCtl && facCtl.reset) facCtl.reset();
      /* v182: dat lai ca loc cua 5 muc moi (chi nhung section co tren trang
         nay moi co handle — 3 muc shop se la null, bo qua an toan). */
      Object.keys(NEWOBJ_UNI_CATS).forEach(function(k){
        var cfg = NEWOBJ_UNI_CATS[k];
        var hh = (typeof window !== 'undefined' && window.V2S_NEWOBJ_FILTERS) ? window.V2S_NEWOBJ_FILTERS[cfg.sectionId] : null;
        if(hh && hh.reset) hh.reset();
      });
      if(typeof onResetFn === 'function') onResetFn();
      if(typeof modelRender === 'function') modelRender(1);
      setCat('model');
    });
  }
}
/* v96-swap (08/11): doi noi dung 2 trang — grid MAU (#listGrid) do initList
   render tu khung loc chung; initShopPage goi ham render do qua 2 bien
   nay khi bam Ap dung / Dat lai. uniModelCat/uniModelQ giu bo loc tu URL
   (?cat= ten linh vuc mau khong co ma chung, ?q= tu khoa hero search). */
var uniModelCat = null;
var uniModelQ = '';
var modelGridRender = null;
var modelGridClearQ = null;
/* v96-swap (08/11) + A3 un-swap (10/11): doi noi dung 2 trang — trang Shop
   (danh-sach-shop.html) hien DANH SACH SHOP + bo loc shop rieng (fSh*).
   Ham nay chi render grid shop (12/trang + phan trang, dong bo URL);
   phan lo/xuong + khung loc chung chuyen sang initShopPage (trang Mau). */
function initShops(){
  initFilterToggle(); /* v72: nut mo/dong bo loc tren mobile */
  var el=document.getElementById('publicShopsList'); if(!el) return;
  // v118 (P2-9): o linh vuc shop hien dung 6 nhom shop that trong du lieu
  // (thay cho 12 ma uni — 5 ma cung ve "Thời trang" nen so dem lap nhau).
  rebuildShopCatOptions();
  var p=params(); var page=parseInt(p.page||'1',10)||1;
  var perPage=24; /* v157: 4 hang x 6 cot (user 21:06 11/11), truoc 12 = 2 hang */
  /* bo loc shop trang Mau — cung truong + cung gia tri nhu bo loc chung
     (fUni*) nhung id rieng fSh* (khong co thanh truot chon hang muc). */
  function readForm(){return {prov:elVal('fShProv'),cat:uniCatToShop(elVal('fShCat')),sort:elVal('fShSort'),shift:elVal('fShShift'),payType:elVal('fShPayType'),payMin:parseMoneyInput(elVal('fShPayMin'))};}
  // v114 (P2-2): ghi lai bo loc luc render — phan trang chi ap dung
  // thang khi bo loc tren form chua doi; doi roi thi phai qua cong
  // dang nhap (gateFilterApply) nhu nut Ap dung.
  var lastFilterKey = null;
  function render(pg){
    var f=readForm();
    lastFilterKey = JSON.stringify(f);
    var base=f.sort ? sortShopsBy(D.shops||[],f.sort) : defaultShopOrder(D.shops||[]);
    if(!f.sort) base=applyStarOrder(base, STAR_STATS, Date.now()); // v99 (§2): tang sao 60 phut len truoc
    var list=filterShops(base,f);
    /* v197 (MỚI-MC-10): lần render đầu, hash #<id> (từ tim-kiem.html) → về
       đúng trang chứa thẻ. Chỉ nhảy 1 lần; bấm phân trang sau đó không nhảy lại. */
    if(!render._hashDone){
      render._hashDone = true;
      var hid = '';
      try { hid = (location.hash || '').replace(/^#/, ''); } catch (e) {}
      var hp = pageOfId(list, hid, perPage);
      if(hp){ pg = hp; render._hashTarget = hid; }
    }
    /* v115: dong dem theo cong thuc bo loc chung (uniCount) — chi hien khi co tieu chi dang chon. */
    var sc=document.getElementById('shopCount'); if(sc){ var active=!!(f.prov||f.cat||f.sort||f.shift||f.payType||f.payMin); sc.textContent=active?(list.length+' tin tuyển khớp bộ lọc'):''; }
    var totalPages=Math.max(1,Math.ceil(list.length/perPage)); if(pg>totalPages) pg=totalPages; if(pg<1) pg=1;
    el.innerHTML=list.length?list.slice((pg-1)*perPage,pg*perPage).map(shopCardHTML).join(''):emptyResultsHTML('Chưa có tin tuyển khớp bộ lọc. Hãy chọn tỉnh khác, chọn lĩnh vực khác, hoặc bấm Đặt lại.');
    renderPager(document.getElementById('shopPager'),pg,totalPages,list.length,function(np){
      if (JSON.stringify(readForm()) !== lastFilterKey) { gateFilterApply('shop', 'danh-sach-shop.html', function(){ render(np); el.scrollIntoView(); }, document.getElementById('shopApplyBtn')); }
      else { render(np); el.scrollIntoView(); }
    },perPage,'tin tuyển');
    setParams(Object.assign({},f,{page:String(pg)}));
    if(render._hashTarget){ render._hashTarget = null; render._hashJumped = true; scrollToHashedCard(); }
  }
  if(p.prov) document.getElementById('fShProv').value=p.prov;
  // v118 (P2-9): o fShCat gio dung ten nhom shop that (khong con ma uni).
  // ?cat= co the la ten nhom ("Thời trang") hoac ma uni cu ("quan-ao")
  // — doi ma uni ve ten nhom qua uniCatToShop (ten nhom tu qua).
  if(p.cat){ var grp = uniCatToShop(p.cat); var fsc = document.getElementById('fShCat');
    if(fsc && selectHasValue(fsc, grp)) fsc.value = grp;
    else if(fsc && selectHasValue(fsc, p.cat)) fsc.value = p.cat; }
  if(p.sort) document.getElementById('fShSort').value=p.sort;
  if(p.shift) document.getElementById('fShShift').value=p.shift;
  if(p.paytype){ var pt=document.getElementById('fShPayType'); if(pt) pt.value=p.paytype; }
  if(p.paymin){ var pm=document.getElementById('fShPayMin'); if(pm) pm.value=p.paymin; }
  /* v45: o "Muc luong toi thieu" chi nhap duoc sau khi chon loai luong;
     nhan/placeholder doi theo loai; bo chon loai thi khoa + xoa gia tri. */
  function syncPayMin(){
    var pt=elVal('fShPayType');
    fillPayDatalist('fShPayMinList', payLevels('shop', pt), pt); /* v214: goi y muc luong theo loai da chon */
    var inp=document.getElementById('fShPayMin'), lab=document.getElementById('fShPayMinLabel');
    if(!inp||!lab) return;
    if(pt==='hourly'){ lab.textContent='Lương giờ tối thiểu (đ/giờ)'; inp.placeholder='VD: 100000'; inp.disabled=false; }
    else if(pt==='monthly'){ lab.textContent='Lương tháng tối thiểu (triệu/tháng)'; inp.placeholder='VD: 15'; inp.disabled=false; }
    else { lab.textContent='Mức lương tối thiểu'; inp.placeholder='Chọn loại lương trước'; inp.disabled=true; inp.value=''; }
  }
  var fShPayTypeEl=document.getElementById('fShPayType');
  if(fShPayTypeEl) fShPayTypeEl.addEventListener('change',syncPayMin);
  syncPayMin();
  /* v182: switch chon hang muc cho bo loc shop — mac dinh 'shop' (danh sach
     shop); v186: loc 3 muc moi chi con o loc chung tren top (tinh + sap
     xep gia + hinh thuc logistics), option shop khoa khi chon muc moi.
     Chi hien section cua muc dang chon (an cac section moi con lai);
     ve 'shop' thi hien lai tat ca. */
  /* v211: nut chon muc chi con 1 hang — tat ca trong switch chinh (#shopFilterSwitch);
     hang rieng #modelClassesSwitch cua v210 da bo. */
  var shopCatBtns = document.querySelectorAll('#shopFilterSwitch .uni-cat-btn');
  function setShopCat(cat){
    shopCatBtns.forEach(function(b){
      var on = b.getAttribute('data-uni-cat') === cat;
      b.classList.toggle('active', on);
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    var isNew = !!NEWOBJ_UNI_CATS[cat];
    ['fShCat','fShSort','fShShift','fShPayType','fShPayMin'].forEach(function(id){
      var fEl = document.getElementById(id);
      if(!fEl) return;
      var wrap = fEl.closest ? fEl.closest('.uni-field') : null;
      if(isNew){ fEl.disabled = true; fEl.value = ''; if(wrap) wrap.classList.add('locked'); }
      else { fEl.disabled = false; if(wrap) wrap.classList.remove('locked'); }
    });
    /* v211: dong bo o Muc luong toi thieu theo loai luong (nhu trang Shop):
       vong lap tren mo het 5 o ke ca fShPayMin — goi syncPayMin() de khoa
       lai khi chua chon loai luong (placeholder "Chon loai luong truoc"). */
    if(typeof syncPayMin === 'function') syncPayMin();
    /* v210: 2 o fShopLogOpt/fShopPriceSort da chuyen sang trang Shop cung
       3 muc shop (khong con tren trang Mau) — khoi nay bo. Thay vao do:
       o Sap xep theo hoc phi (fUniClassSort, chuyen sang trang Mau cung
       2 muc lop hoc) chi mo khi dang chon class-live/class-makeup. */
    var cs = document.getElementById('fUniClassSort');
    if(cs){
      var cw = cs.closest ? cs.closest('.uni-field') : null;
      if(cat === 'class-live' || cat === 'class-makeup'){ cs.disabled = false; if(cw) cw.classList.remove('locked'); }
      else { cs.disabled = true; cs.value = ''; if(cw) cw.classList.add('locked'); }
    }
    var sc = document.getElementById('shopCount'); if(sc) sc.textContent = '';
    var ncfg = NEWOBJ_UNI_CATS[cat];
    if(ncfg){
      showOnlyNewObjSection(cat);
      ['lop-livestream-mc','lop-makeup'].forEach(function(sid){
        var s = document.getElementById(sid);
        if(s && sid !== ncfg.sectionId) s.classList.add('collapsed');
      });
      var cs = document.getElementById(ncfg.sectionId);
      if(cs) cs.classList.remove('collapsed');
      /* v213: nut cua muc da chon (mo rong) + muc kia (thu gon) deu do
         refreshClassMoreBtn lam chu — muc chon -> "Thu gọn ↑", muc kia ->
         "Xem thêm ↓ (còn N lớp học)" hoac an khi het. */
      refreshClassMoreBtn(ncfg.sectionId);
      ['lop-livestream-mc','lop-makeup'].forEach(function(sid){
        if(sid !== ncfg.sectionId) refreshClassMoreBtn(sid);
      });
    } else {
      showAllNewObjSections();
      ['lop-livestream-mc','lop-makeup'].forEach(function(sid){
        var s = document.getElementById(sid);
        if(s) s.classList.add('collapsed');
        refreshClassMoreBtn(sid);
      });
    }
    refreshShopProvCounts(cat);
    refreshNewObjCatCounts(); /* v214: luat an so cua muc dang chon */
  }
  shopCatBtns.forEach(function(b){
    b.addEventListener('click', function(){ setShopCat(b.getAttribute('data-uni-cat')); });
  });
  setShopCat('shop');
  var applyBtn=document.getElementById('shopApplyBtn');
  if(applyBtn) applyBtn.addEventListener('click',function(){
    var b=applyBtn;
    /* v182: muc con moi — goi apply cua section, khong qua cong diem
       (giong nut Ap dung rieng). v186: loc cua section doc TRUC TIEP tu
       loc chung tren top (tinh fShProv + sap xep gia fShopPriceSort +
       hinh thuc fShopLogOpt) — khong con dong bo sang loc rieng. */
    var cat = getUniCat();
    var ncfg = NEWOBJ_UNI_CATS[cat];
    if(ncfg){
      var h = (typeof window !== 'undefined' && window.V2S_NEWOBJ_FILTERS) ? window.V2S_NEWOBJ_FILTERS[ncfg.sectionId] : null;
      if(h && h.apply) h.apply(true);
      var c = document.getElementById('shopCount');
      var sc2 = document.getElementById(ncfg.countId);
      if(c && sc2) c.textContent = sc2.textContent;
      closeFilterOf(b);
      /* v213 (anh Thọ dặn 23:58 ngày 13/11 — TAT CA muc loc sau khi Ap dung
         ra ket qua thi TU CUON toi ket qua): apply(true) da cuon toi the
         khop dau tien / bang "Chua co du lieu" (ghi de phan cam cuon khi
         Ap dung cua v207). Bam hang muc/switch/?newobj= van KHONG cuon. */
      return;
    }
    return gateFilterApply('shop', 'danh-sach-shop.html', function(){ render(1); closeFilterOf(b); }, b);
  });
  var resetBtn=document.getElementById('shopResetBtn');
  if(resetBtn) resetBtn.addEventListener('click',function(){
    ['fShProv','fShCat','fShSort','fShShift','fShPayType','fShPayMin','fUniClassSort'].forEach(function(id){var el=document.getElementById(id); if(el) el.value='';});
    syncPayMin();
    /* v182: dat lai loc 5 muc moi + ve hang muc mac dinh 'shop'. */
    Object.keys(NEWOBJ_UNI_CATS).forEach(function(k){
      var cfg = NEWOBJ_UNI_CATS[k];
      var hh = (typeof window !== 'undefined' && window.V2S_NEWOBJ_FILTERS) ? window.V2S_NEWOBJ_FILTERS[cfg.sectionId] : null;
      if(hh && hh.reset) hh.reset();
    });
    setShopCat('shop');
    render(1);
  });
  el._shopRender=render; /* v99: initStars goi lai khi nap xong so sao */
  render(page);
  // v91 (9): vào từ link đã lọc sẵn thì hướng ngay tới dòng kết quả /
  // bảng "Chưa có dữ liệu" (như trang Mẫu).
  try {
    if ((p.prov || p.cat || p.sort || p.shift || p.paytype || p.paymin)
      && !render._hashJumped
      && el && typeof el.scrollIntoView === 'function') el.scrollIntoView({ behavior: 'auto', block: 'start' });
  } catch (e) {}
}
/* v214 (diem 6): goi y muc luong theo loai luong da chon — datalist cho o
   luong toi thieu (van go tay duoc). Muc lay TU DU LIEU THAT (data.js):
   - Mau (fUniPayMin): luong gio = cac salaryNum that (hien 120.000,
     250.000); luong thang = khong co muc nao (mau khong co doanh thu da
     xac minh) nen datalist rong, van go tay duoc.
   - Shop (fShPayMin): luong gio = cac parseHourlyMin that trong
     [30.000, 300.000] (loc nhieu do parse quet so — vd "2 video 1 gio"
     doc thanh 1.000); luong thang = cac parseMonthlyMax that (trieu). */
function payLevels(source, payType){
  var s = {}, out = [];
  if(source === 'model'){
    if(payType !== 'hourly') return [];
    (D.models || []).forEach(function(m){ if(typeof m.salaryNum === 'number') s[m.salaryNum] = 1; });
  } else {
    if(payType === 'hourly'){
      (D.shops || []).forEach(function(sh){ var v = parseHourlyMin(sh.salary); if(v != null && v >= 30000 && v <= 300000) s[v] = 1; });
    } else if(payType === 'monthly'){
      (D.shops || []).forEach(function(sh){ var v = parseMonthlyMax(sh.salary); if(v != null) s[v] = 1; });
    } else return [];
  }
  Object.keys(s).forEach(function(k){ out.push(parseFloat(k)); });
  out.sort(function(a, b){ return a - b; });
  return out;
}
function fillPayDatalist(listId, levels, payType){
  var dl = document.getElementById(listId);
  if(!dl) return;
  var html = '';
  levels.forEach(function(v){
    var val, lab;
    if(payType === 'hourly'){ val = String(v); lab = fmtVnd(v) + 'đ/giờ'; }
    /* luong thang nhap theo trieu, dung dau phay thap phan VN ("0,3") vi
       parseMoneyInput hieu dau "." la phan cach hang nghin. */
    else { val = String(v).replace('.', ','); lab = val + ' triệu/tháng'; }
    html += '<option value="' + esc(val) + '">' + esc(lab) + '</option>';
  });
  dl.innerHTML = html;
}
/* v96-swap (08/11) + A3 un-swap (10/11): khoi tao rieng cho trang Mau
   (danh-sach-mau.html) — render the lo/xuong, xoay the, bo loc lo/xuong,
   khung loc chung (uni switch). Grid mau (#listGrid) do initList render;
   nut Ap dung / Dat lai o khung chung goi modelGridRender qua
   initUniCatSwitch. */
function initShopPage(){
  var uni=document.getElementById('uniFilter'); if(!uni) return;
  renderLotSections(); /* v76: render the lo/xuong TRUOC khi bo loc chup danh sach the */
  rotateStaticGrids();
  var lotCtl = initLotFilter();
  var facCtl = initFactoryFilter();
  initFilterToggle(); /* v72: nut mo/dong bo loc tren mobile */
  /* v45: o "Muc luong toi thieu" chi nhap duoc sau khi chon loai luong;
     nhan/placeholder doi theo loai; bo chon loai thi khoa + xoa gia tri.
     v96: chi mo khi dang o hang muc Tim Mau (truong bi khoa o Lo/Xuong). */
  function syncPayMin(){
    var pt=elVal('fUniPayType');
    fillPayDatalist('fUniPayMinList', payLevels('model', pt), pt); /* v214: goi y muc luong theo loai da chon */
    var inp=document.getElementById('fUniPayMin'), lab=document.getElementById('fUniPayMinLabel');
    if(!inp||!lab) return;
    if(getUniCat()!=='model'){ lab.textContent='Mức lương tối thiểu'; inp.placeholder='Chọn loại lương trước'; inp.disabled=true; inp.value=''; return; }
    if(pt==='hourly'){ lab.textContent='Lương giờ tối thiểu (đ/giờ)'; inp.placeholder='VD: 100000'; inp.disabled=false; }
    else if(pt==='monthly'){ lab.textContent='Lương tháng tối thiểu (triệu/tháng)'; inp.placeholder='VD: 15'; inp.disabled=false; }
    else { lab.textContent='Mức lương tối thiểu'; inp.placeholder='Chọn loại lương trước'; inp.disabled=true; inp.value=''; }
  }
  var fUniPayTypeEl=document.getElementById('fUniPayType');
  if(fUniPayTypeEl) fUniPayTypeEl.addEventListener('change',syncPayMin);
  syncPayMin();
  /* v96: thanh truot chon hang muc + khoa/mo truong + nut Ap dung / Dat lai
     dung chung cho ca 3 hang muc; hang muc Tim Mau render grid mau. */
  initUniCatSwitch(lotCtl, facCtl, function(pg){ if(typeof modelGridRender==='function') modelGridRender(pg); }, syncPayMin, function(){ if(typeof modelGridClearQ==='function') modelGridClearQ(); });
  /* v124: tải tin lô/xưởng do thành viên đăng rồi chen lên đầu lưới.
     Truyền lotCtl/facCtl để làm mới snapshot bộ lọc (xem loadUserListings);
     chạy nền, không chặn render tin thu thập. */
  loadUserListings(lotCtl, facCtl);
  // v118 (P2-9): luc mo trang, o linh vuc phai hien dung nhom cua tab
  // mac dinh (Tim Mau) + so dem dung — refreshUniCounts vua doi option
  // vua gan so theo tab.
  refreshUniCounts(getUniCat());
}
/* List page: grid + filters + pagination 12/page, URL-synced */
/* A3 un-swap (10/11, dao v96-swap 08/11): grid MAU gio o trang Mau (danh-sach-mau.html), loc
   bang KHUNG LOC CHUNG (#uniFilter, hang muc Tim Mau) thay cho bo loc mau
   cu (fProv...fQ da bo khoi trang Mau). Anh xa truong chung -> mau: tinh
   truc tiep; linh vuc qua uniCatToModel (tru khi URL ?cat= la ten linh vuc
   mau khong co ma chung, vd "Thực phẩm", thi giu bien rieng uniModelCat);
   sap xep qua uniSortToModelSort; gio lam 'fulltime' bo qua (mau khong co
   fulltime); luong gio -> wageMin, luong thang -> revMin (cung don vi
   trieu). Tu khoa ?q= tu hero search duoc giu den khi bam Dat lai. Gioi
   tinh + o tim kiem rieng cua bo loc cu khong con (khung chung khong co
   2 truong nay). */
function initList(){
  var grid=document.getElementById('listGrid'); if(!grid) return;
  initFilterToggle(); /* v72: nut mo/dong bo loc tren mobile */
  var p=params(); var page=parseInt(p.page||'1',10)||1;
  /* prefill tu URL: ?cat= co the la ten linh vuc mau (hero/chip/hub) hoac
     ma dung chung (link cu); ?q= la tu khoa hero search. */
  if(p.cat){
    var mc = p.cat;
    // v118 (P2-9): o fUniCat gio dung ten nhom mau that (khong con ma uni).
    // ?cat= co the la ten nhom mau ("Thời trang", "Thực phẩm") hoac ma uni
    // cu ("quan-ao") — doi ma uni ve ten nhom qua uniCatToModel (ten nhom
    // tu qua). Khong khop option nao thi giu bien rieng nhu cu.
    var target = uniCatToModel(mc);
    var fc = document.getElementById('fUniCat');
    if(fc && selectHasValue(fc, target)){ fc.value = target; uniModelCat = null; }
    else if(fc && selectHasValue(fc, mc)){ fc.value = mc; uniModelCat = null; }
    else { uniModelCat = mc; }
  }
  if(p.q) uniModelQ=p.q;
  if(p.prov){ var fp=document.getElementById('fUniProv'); if(fp) fp.value=p.prov; }
  if(p.sort){ var fs=document.getElementById('fUniSort'); if(fs) fs.value=p.sort; }
  if(p.shift){ var fh=document.getElementById('fUniShift'); if(fh) fh.value=p.shift; }
  if(p.paytype){ var pt=document.getElementById('fUniPayType'); if(pt) pt.value=p.paytype; }
  if(p.paymin){ var pm=document.getElementById('fUniPayMin'); if(pm) pm.value=p.paymin; }
  /* doi dropdown Linh vuc -> xoa bien rieng (de dropdown quyet dinh). */
  var fUniCatEl=document.getElementById('fUniCat');
  if(fUniCatEl) fUniCatEl.addEventListener('change',function(){ uniModelCat=null; });
  function readForm(){
    var shift=elVal('fUniShift');
    var payType=elVal('fUniPayType');
    var payMin=parseMoneyInput(elVal('fUniPayMin'));
    return {
      prov:elVal('fUniProv'),
      cat:(uniModelCat!==null ? uniModelCat : uniCatToModel(elVal('fUniCat'))),
      gender:'',
      sort:uniSortToModelSort(elVal('fUniSort')),
      shift:shift,
      // v111 (muc 6): truyen loai luong vao filterModels — truoc day chi
      // truyen wageMin/revMin (chi khi nhap muc) nen chon loai luong ma
      // khong nhap muc thi khong loc gi; 'fulltime' khong con bi doi
      // thanh '' (0 mau co ca fulltime nen loc that tra 0, dung du lieu).
      payType:payType,
      revMin:(payType==='monthly' ? payMin : null),
      wageMin:(payType==='hourly' ? payMin : null),
      q:uniModelQ
    };
  }
  // v114 (P2-2): nhu initShops — phan trang chi ap thang khi bo loc chua doi.
  var lastFilterKey = null;
  function render(pg){
    var f=readForm(); lastFilterKey = JSON.stringify(f); var list=filterModels(D.models,f);
    if(f.sort){
      list=sortModelsBy(list,f.sort);
    } else {
      list=defaultModelOrder(list);
      list=applyStarOrder(list, STAR_STATS, Date.now()); // v99 (§2): tang sao 60 phut len truoc
    }
    /* v197 (MỚI-MC-10): lần render đầu, hash #<id> (từ tim-kiem.html) → về
       đúng trang chứa thẻ. Chỉ nhảy 1 lần; bấm phân trang sau đó không nhảy lại. */
    if(!render._hashDone){
      render._hashDone = true;
      var hid = '';
      try { hid = (location.hash || '').replace(/^#/, ''); } catch (e) {}
      var hp = pageOfId(list, hid, 12);
      if(hp){ pg = hp; render._hashTarget = hid; }
    }
    var totalPages=Math.max(1,Math.ceil(list.length/12)); if(pg>totalPages) pg=totalPages; if(pg<1) pg=1;
    grid.innerHTML=list.length?list.slice((pg-1)*12,pg*12).map(cardHTML).join(''):emptyResultsHTML('Chưa có hồ sơ khớp bộ lọc. Hãy chọn tỉnh khác, chọn Toàn quốc / Live online, hoặc bấm Đặt lại.');
    renderPager(document.getElementById('pager'),pg,totalPages,list.length,function(np){
      if (JSON.stringify(readForm()) !== lastFilterKey) { gateFilterApply('model', 'danh-sach-mau.html', function(){ render(np); grid.scrollIntoView(); }, document.getElementById('uniApplyBtn')); }
      else { render(np); grid.scrollIntoView(); }
    },12,'hồ sơ');
    /* URL giu dang ?cat= ten linh vuc mau (nhu hero/chip/hub) + cac khoa
       cua bo loc chung; q chi ghi khi co tu khoa. */
    var sp={prov:f.prov,cat:f.cat,sort:elVal('fUniSort'),shift:elVal('fUniShift'),paytype:elVal('fUniPayType'),paymin:elVal('fUniPayMin'),q:f.q,page:String(pg)};
    setParams(sp);
    if(render._hashTarget){ render._hashTarget = null; render._hashJumped = true; scrollToHashedCard(); }
  }
  modelGridRender=render;
  modelGridClearQ=function(){ uniModelQ=''; uniModelCat=null; };
  grid._modelRender=render;
  grid._modelClearQ=modelGridClearQ;
  render(page);
  // v91 (9): vào từ link đã lọc sẵn (vd tìm kiếm hero trang chủ) thì hướng
  // ngay tới dòng kết quả / bảng "Chưa có dữ liệu", không để người dùng ở
  // đầu trang phải tự cuộn xuống.
  try {
    if ((p.prov || p.cat || p.sort || p.shift || p.paytype || p.paymin || p.q)
      && !render._hashJumped
      && grid && typeof grid.scrollIntoView === 'function') grid.scrollIntoView({ behavior: 'auto', block: 'start' });
  } catch (e) {}
}
/* v63: thu tu mac dinh cua trang Mau (initList): luot xem giam dan, binh luan
   giam dan, roi xoay deu TOAN BO danh sach. v152: xoay 4 lan/ngay theo cua
   so 6 tieng (00:00/06:00/12:00/18:00 gio VN), on dinh trong cua so; BO
   photoTier khoi thu tu (quyet cua user 15:50 11/11 — khong uu tien anh).
   Tach ra ham rieng de khoi hub 11.11 dung DUNG thu tu do — shop khong thay
   hai thu tu khac nhau cho cung mot bo loc. */
function defaultModelOrder(list, date){
  var out=list.slice().sort(function(a,b){return (b.views-a.views)||(b.comments-a.comments);});
  return rotateWindow(out, date);
}
/* v63: khoi "Tim mau cho 11.11 — 3 buoc" tren trang Danh cho Shop (thiet ke
   2026-11-06, design-2026-11-06-tim-mau-nhanh-cho-shop-11-11.md). Chi 1 khoi
   moi tren danh-sach-mau.html + ham render rieng o day + CSS .hub-card
   (A3 10/11: khoi hub hien chua gan tren trang nao — kiem tra 10/11.)
   trong v20.css. Khong doi du lieu js/data.js, bo loc tin tuyen shop, phan
   trang, form ho so shop / dang tin, trang chu, trang mau hay trang chi tiet.
   Khong hua "Con trong"/"San sang 11.11", khong hien luot xem/binh luan (0/0),
   khong hien so rieng cua mau, khong them o loc gio lam / ca toi. */
var HUB_ZALO = 'https://zalo.me/0329983699';
/* v63: tin nhan Zalo soan san cho shop can mau dot 11.11 — dung mau cau cua
   thiet ke 04/11 ("Hoi lich 11.11 qua Zalo", chua code toi 06/11): neu thiet
   ke 04/11 duoc code sau thi tai dung ham nay, khong viet lai ham moi. Chi
   dung Zalo chung Ver2Solution; khong hien so rieng cua mau o bat ky dau
   (ke ca 5 ho so co Zalo cong khai trong du lieu). */
function hubZaloHref(m){
  var msg = 'Chào Ver2Solution, tôi là shop cần mẫu ' + (m.name || '') + ' live ' + (m.cat || '') + ' đợt 11.11 (10–13/11). Nhờ giới thiệu và xác nhận lịch trống giúp tôi.';
  return HUB_ZALO + '?text=' + encodeURIComponent(msg);
}
/* v63: link video demo cua ho so — truong luu tren Supabase la demo_video_url
   (trang-cua-toi.html, uploadDemoVideo tra ve public URL); chap nhan ca ten
   bien the de phong doi ten truong. Hien tai 0/20 ho so co video demo nen
   khong the nao duoc render; khi mau tu dang ky tai video demo len thi link
   tu xuat hien, khong can sua code. */
function demoUrlOf(m){ return (m && (m.demo_video_url || m.demoUrl || m.demo)) || ''; }
/* v63: the ket qua trong khoi hub = the 5 giay cardHTML (v28) nhung nut
   "Nhan Zalo" mo Zalo kem tin nhan soan san (ten that + linh vuc + dot
   11.11) thay cho link Zalo chung tran; them link "Xem video demo" neu co. */
/* v99: the hub = the rut gon (2 dong + sao) + hang nut rieng DUOI the (nhu
   nut Binh luan cua the lo): link Zalo tin nhan soan san + link video demo
   (neu co). Khong chen them link vao trong 2 dong cua the (§1). */
function hubCardHTML(m){
  var z = hubZaloHref(m), d = demoUrlOf(m);
  return '<div class="hub-card">' + cardHTML(m)
    + '<div class="hub-actions"><a class="btn btn-ghost btn-sm" href="'+esc(z)+'" target="_blank" rel="noopener">Nhắn Zalo</a>'
    + (d ? '<a class="btn btn-ghost btn-sm" href="'+esc(d)+'" target="_blank" rel="noopener">▶ Xem video demo</a>' : '')
    + '</div></div>';
}
/* v63: ket qua hub = loc theo tinh + linh vuc (chi 2 o nay, khong loc gio lam
   / luong / doanh thu) roi xep DUNG thu tu mac dinh cua trang Mau. */
function hubResults(prov, cat, date){
  return defaultModelOrder(filterModels(D.models, {prov: prov || '', cat: cat || ''}), date);
}
/* v63: link sang trang danh sach mau (v96-swap: grid mau gio o trang Shop)
   dung tham so prov/cat ma initList da doc + dien san vao bo loc khi tai
   trang (da kiem chung trong code v52). Ca 2 rong thi ve trang Shop khong
   tham so. */
function hubAllLink(prov, cat){
  var qs = [];
  if(prov) qs.push('prov=' + encodeURIComponent(prov));
  if(cat) qs.push('cat=' + encodeURIComponent(cat));
  return 'danh-sach-mau.html' + (qs.length ? '?' + qs.join('&') : ''); // A3 10/11 un-swap v96
}
/* v63: dong trang thai khi to hop 0 mau — chi noi dung su that + duong doi
   lua chon, khong goi y mau sai tinh/linh vuc, khong hien the trong. */
function hubEmptyHTML(prov, cat){
  var total = (D.models || []).length;
  if(prov && cat) return 'Chưa có mẫu ' + esc(cat) + ' ở ' + esc(prov) + '. Thử chọn Toàn quốc / Live online, hoặc <a href="' + hubAllLink('', cat) + '">xem tất cả mẫu ' + esc(cat) + ' →</a>';
  if(prov) return 'Chưa có mẫu ở ' + esc(prov) + '. Thử chọn Toàn quốc / Live online, hoặc <a href="danh-sach-mau.html">xem tất cả ' + total + ' mẫu →</a>';
  if(cat) return 'Chưa có mẫu ' + esc(cat) + '. <a href="danh-sach-mau.html">Xem tất cả ' + total + ' mẫu →</a>';
  return '';
}
function initHub(){
  var box = document.getElementById('hubResults'); if(!box) return;
  var provSel = document.getElementById('hubProv'), catSel = document.getElementById('hubCat');
  var countEl = document.getElementById('hubCount'), sub = document.getElementById('hubSub');
  var total = (D.models || []).length;
  if(sub) sub.textContent = 'Hiện có ' + total + ' mẫu trên sàn. Chọn tỉnh và lĩnh vực rồi xem ngay mẫu phù hợp — chỉ hiện thông tin thật.';
  function render(){
    var prov = provSel ? provSel.value : '', cat = catSel ? catSel.value : '';
    if(!prov && !cat){
      box.innerHTML = '';
      if(countEl) countEl.innerHTML = 'Chọn tỉnh và lĩnh vực ở trên để xem mẫu phù hợp — hoặc <a href="danh-sach-mau.html">xem tất cả ' + total + ' mẫu →</a>';
      return;
    }
    var list = hubResults(prov, cat);
    if(!list.length){
      box.innerHTML = emptyResultsHTML(hubEmptyHTML(prov, cat));
      if(countEl) countEl.innerHTML = hubEmptyHTML(prov, cat);
      return;
    }
    box.innerHTML = list.slice(0, 3).map(hubCardHTML).join('');
    if(countEl) countEl.innerHTML = 'Có ' + list.length + ' mẫu phù hợp. <a href="' + hubAllLink(prov, cat) + '">Xem tất cả ' + list.length + ' mẫu →</a>';
  }
  if(provSel) provSel.addEventListener('change', function(){ return gateFilterApply('model', pointsPageName(), render, provSel); });
  if(catSel) catSel.addEventListener('change', function(){ return gateFilterApply('model', pointsPageName(), render, catSel); });
  /* v96: khung loc chung trang Shop dong bo hub khi ap dung hang muc Tim Mau
     (goi truc tiep, khong qua cong diem). */
  box._hubRender = render;
  render();
}
/* News page: newest first by default, category filter, oldest sort option.
   Sidebar "most read" is NOT a fabricated read count: no verified read numbers
   exist, so every entry is labelled unverified (0) and ordered newest-first as
   a temporary placeholder, exactly as v19 stated. The pinned article is now
   a real internal page (bai-viet-bop-reach.html). */
function initNews(){
  var main=document.getElementById('newsMain'); if(!main) return;
  var catSel=document.getElementById('newsCat'), sortSel=document.getElementById('newsSort');
  var cats=[]; D.articles.forEach(function(a){if(cats.indexOf(a.cat)===-1) cats.push(a.cat);});
  cats.forEach(function(c){var o=document.createElement('option'); o.value=c; o.textContent=c; catSel.appendChild(o);});
  function linkHTML(a){
    return articleLink(a);
  }
  function render(){
    var list=D.articles.slice();
    if(catSel.value) list=list.filter(function(a){return a.cat===catSel.value;});
    list.sort(function(x,y){var dx=x.date||'',dy=y.date||''; return sortSel.value==='oldest' ? (dx<dy?-1:dx>dy?1:0) : (dx>dy?-1:dx<dy?1:0);});
    // v111 (NEW-P2): tieu de muc doi theo che do sap xep — truoc day h2
    // ghi cung "Tin moi nhat" ca khi chon "Cu nhat truoc".
    var titleEl=document.getElementById('newsListTitle');
    if(titleEl) titleEl.textContent = sortSel.value==='oldest' ? 'Tin cũ nhất — xếp cũ nhất trước' : 'Tin mới nhất — xếp mới nhất trước';
    /* v100: danh sach tin dung chung the tin rut gon (1 anh + 2 dong).
       Anh goc / takeaway / nut diem chi con o trang chi tiet bai-viet,
       khong hien trong danh sach nua. Bo loc + sap xep + dem + sidebar giu nguyen. */
    // v223 (S2-6, 14/11/2026): DAO QUYET v114 — so dem = so the trong danh sach
    // chinh (mainList), khong phai tong khop loc. Ly do: nguoi doc chi dem duoc
    // 257 the duoi tieu de "Tin moi nhat" trong khi count ghi 261 (4 bai da hien
    // o hang ghim/moi nhat phia tren) — so dem phai mo ta dung danh sach dang nhin.
    var topIds = renderTopRows(list);
    var mainList = topIds ? list.filter(function(a){ return topIds.indexOf(a) === -1; }) : list;
    main.innerHTML=mainList.map(function(a){ return newsCardHTML(a, null, true); }).join('') || emptyResultsHTML('Chưa có bài báo nào khớp bộ lọc.');
    var cnt=document.getElementById('newsCount'); if(cnt) cnt.textContent=mainList.length+' bài khớp bộ lọc.';
    var most=document.getElementById('mostList');
    if(most) most.innerHTML=D.articles.slice().sort(function(x,y){return (x.date||'')>(y.date||'')?-1:1;}).slice(0,20).map(function(a,i){
      return '<li><span class="rank">'+(i+1)+'</span><span>'+linkHTML(a)+'<span class="meta" style="display:block">'+esc(formatArticleDate(a.date))+'</span></span></li>';
    }).join('');
  }
  /* v105: 2 hang tin tren muc loc (user chot 22:28 08/11) — hang 1 Tin ghim,
     hang 2 Tin moi nhat tiep theo (moi nhat theo date, loai tru bai da hien
     o hang 1 — khong trung bai giua 2 hang). Doc lap voi bo loc ben duoi:
     chi render 1 lan o day, render() cua loc (newsCat/newsSort) khong cham
     toi 2 hang nay. The dung newsCardHTML khong danh so (tranh loi NEW-T1:
     huy hieu 'Tin 1–4' che nhan chuyen muc o hang ghim trang chu).
     v106: hang 1 KHONG dung getPinnedRow() nua — getPinnedRow (v84, dung
     chung cho hang ghim trang chu) lap cho trong bang bai moi THEM VAO WEB
     gan nhat (dao nguoc mang, khong theo date), nen 3 bai lap lech khoi
     thu tu ngay cua trang va bo sot bai moi thu 5, 6 (loi live v105).
     Hang tin tuc nay lap bang BAI MOI NHAT THEO DATE (sortByDateDesc):
     bai ghim (xep pinOrder tang dan roi date giam dan, nhu getPinnedRow)
     len truoc, thieu thi lap bang bai moi nhat theo date; khong co bai
     ghim thi 4 bai moi nhat theo date. getPinnedRow + hang ghim trang chu
     GIU NGUYEN quy tac v84, khong doi.
     v114 (P3-3): 2 hang nay TINH THEO BO LOC — render() goi
     renderTopRows(list) moi lan loc/sap xep doi, va tra ve top1 de
     render() loai khoi danh sach chinh (khong lap bai giua hang ghim
     va Tin moi nhat). */
  function renderTopRows(source){
    var pinRow=document.getElementById('newsPinnedRow');
    var newRow=document.getElementById('newsNewRow');
    if(!pinRow && !newRow) return null;
    var src = source || D.articles || [];
    var pinned=src.filter(function(a){ return !!a.pinned; });
    pinned.sort(function(a, b){
      var ao=(typeof a.pinOrder==='number')?a.pinOrder:Infinity;
      var bo=(typeof b.pinOrder==='number')?b.pinOrder:Infinity;
      if(ao!==bo) return ao-bo;
      return (a.date||'')>(b.date||'')?-1:((a.date||'')<(b.date||'')?1:0);
    });
    var newest=sortByDateDesc(src);
    var top1=pinned.slice(0,4);
    for(var i=0;i<newest.length && top1.length<4;i++){
      if(top1.indexOf(newest[i])===-1) top1.push(newest[i]);
    }
    var rest=newest.filter(function(a){ return top1.indexOf(a)===-1; });
    var top2=rest.slice(0,4);
    if(pinRow) pinRow.innerHTML=top1.map(function(a){ return newsCardHTML(a, null, false, true); }).join(''); // v230 (L12): hang ghim dau trang -> eager
    if(newRow) newRow.innerHTML=top2.map(function(a){ return newsCardHTML(a, null, false, true); }).join(''); // v230 (L12): hang moi nhat dau trang -> eager
    return top1;
  }
  // v111 (NEW-P6): prefill o loc tu ?cat= khi mo truc tiep (vd
  // tin-tuc.html?cat=Dòng tiền) — chi nhan gia tri co that trong danh
  // sach chuyen muc. v176: gon lai bang indexOf (tuong duong vong lap
  // cu); params() tra ve doi tuong thuong (da giai ma), khong phai
  // URLSearchParams, nen qp.cat doc truc tiep duoc.
  var qp = params();
  if (qp.cat && cats.indexOf(qp.cat) !== -1) catSel.value = qp.cat;
  catSel.addEventListener('change',render); sortSel.addEventListener('change',render); render(); // v114 (P3-3): render() da goi renderTopRows(list) o trong
}
/* Detail: 2-column layout + mini-card list of the other 19 (names, never ids) */
function initDetail(){
  var root=document.getElementById('detailRoot'); if(!root) return;
  var id=params().id || D.models[0].id;
  var m=D.models.filter(function(x){return x.id===id;})[0];
  if(!m){root.innerHTML='<p>Không tìm thấy hồ sơ.</p>'; return;}
  root.innerHTML='<div class="detail-layout"><div class="detail-main"><div class="detail-photo">'+photoHTML(m)+'<span class="ph-note" style="position:absolute;left:14px;bottom:14px;background:rgba(0,0,0,.62);color:#fff;border-radius:999px;padding:6px 12px;font-size:13px;font-weight:700">'+photoNote(m)+'</span></div>'
  + '<div class="detail-body"><span class="status" style="position:static;display:inline-flex"><i></i>'+esc(m.status)+'</span>'
  + '<h1>'+esc(m.province)+' — '+esc(m.name)+'</h1><p class="subtitle">'+esc(m.title)+'</p>'
  + '<div class="tags"><span class="tag">📍 '+esc(m.province)+'</span><span class="tag">'+esc(m.cat)+'</span><span class="tag soft">'+esc(m.form)+'</span><span class="tag soft">Giới tính: '+esc(m.gender)+'</span></div>'
  + '<div class="fact-grid">'
  + '<div class="fact"><b>Tỉnh / nơi muốn làm việc</b><span>'+esc(m.province)+'</span></div>'
  + '<div class="fact"><b>Giỏi livestream nhất</b><span>'+esc(m.cat)+'</span></div>'
  + '<div class="fact"><b>Lương mong muốn</b><span>'+esc(m.salary)+'</span></div>'
  + '<div class="fact"><b>Lịch làm việc</b><span>'+esc(m.schedule)+'</span></div>'
  + '<div class="fact"><b>Doanh thu cao nhất</b><span>'+esc(revenueText(m))+'</span></div>'
  + '<div class="fact"><b>Chiều cao / cân nặng</b><span>'+esc(m.height)+'</span></div>'
  + '<div class="fact"><b>Đánh giá</b><span>'+esc(m.rating)+'</span></div>'
  + '<div class="fact"><b>Ngày bài gốc</b><span>'+esc(m.date)+'</span></div></div>'
  + '<h2>Kinh nghiệm</h2><p>'+esc(m.exp)+'</p>'
  + '<p class="warn">⚠ CHƯA XÁC NHẬN ĐỒNG Ý ĐĂNG WEB — hồ sơ từ bài đăng công khai, sẽ xóa khi có hồ sơ mới tự đăng ký thay thế.</p>'
  // v99 (§3): sao dong bo voi the danh sach + mien tru + goi y dang ky/
  // dang nhap de sua ho so va ghim top (nut ghim o hop mountPointsDetail).
  + '<p class="detail-star">Ấn sao để đưa hồ sơ này lên top 60 phút: ' + starButtonHTML('model_profile', m.id) + '</p>'
  + '<p class="disclaimer">'+DISCLAIMER+'</p>'+ownerNoteHTML('model', m.id)+'</div></div>'
  + '<div><div class="contact-card"><h2>Liên hệ trực tiếp với mẫu</h2>'
  + gatedContactsHTML('model_profile', m.id, m.contacts)
  + '<p>Chỉ hiển thị thông tin liên hệ do chính mẫu công khai trong bài đăng hoặc trên kênh công khai của mẫu. Thông tin chưa công khai không hiển thị. Trước khi chốt, shop xác nhận lại lịch làm việc và tình trạng tìm việc với mẫu, vì lịch ghi trong bài là tại thời điểm bài đăng.</p>'
  + '<a class="btn btn-light" data-track="xem-bai-goc-mau" href="'+esc(m.src)+'" target="_blank" rel="noopener">Xem bài gốc trên Facebook →</a>'
  + '<a class="btn btn-light" data-track="nhan-zalo-ver2solution" href="https://zalo.me/0329983699" target="_blank" rel="noopener">Nhắn Zalo Ver2Solution 032 998 3699</a>'
  + '<a class="btn btn-ghost" data-track="yeu-cau-go-ho-so" style="background:transparent;color:#fff;border-color:#fff" href="https://zalo.me/0329983699" target="_blank" rel="noopener">Yêu cầu gỡ hồ sơ</a></div>'
  + '<div class="side-card"><h2 style="margin-top:0">Thông tin thêm</h2><p><b>Hình thức:</b> '+esc(m.form)+'</p><p><b>Giới tính:</b> '+esc(m.gender)+'</p><p><b>Bài gốc:</b> <a href="'+esc(m.src)+'" target="_blank" rel="noopener">Xem bài gốc trên Facebook</a> · Ngày bài: '+esc(m.date)+'</p></div></div></div>';
  var others=document.getElementById('otherGrid');
  if(others) others.innerHTML=D.models.filter(function(x){return x.id!==m.id;}).map(miniHTML).join('');
  var title=document.getElementById('detailTitle'); if(title) title.textContent='Hồ sơ: '+m.province+' — '+m.name;
  mountPointsDetail('model_profile', m.id);
  v2sSignupPopup('detail'); // v185: popup goi y dang ky khi xem chi tiet (chi goi y, khong chan).
}
/* Shop detail (v32): company-page layout after the big job sites
   (VietnamWorks company page: header with big logo + name, key facts,
   contact, then the company's own open jobs). The logo is 96px in
   .company-head — NOT inside .detail-photo, whose img rule (absolute,
   inset 0, cover) would stretch it to fill a 4/3 frame. The h1 is the
   shop name only (company-page pattern); the province stays in the
   subtitle, tags and facts. The fact-grid keeps the full table including
   "Chưa cập nhật" (same rule as the model detail page); the job item
   below hides empty values, like a job card. Each shop has exactly 1
   open job (the collected post) — no extra jobs are invented. */
function initShopDetail(){
  var root=document.getElementById('shopDetailRoot'); if(!root) return;
  var id=params().id || (D.shops[0]||{}).id;
  var s=(D.shops||[]).filter(function(x){return x.id===id;})[0];
  if(!s){root.innerHTML='<p>Không tìm thấy shop.</p>'; return;}
  var loc = esc(s.province)+(s.district && s.district!=='Chưa cập nhật' ? ' — '+esc(s.district) : '');
  var sub = (hasReal(s.product) ? '🎯 '+esc(s.product)+' · ' : '')+'📍 '+loc;
  var meta = [];
  if(hasReal(s.salary)) meta.push('💰 '+esc(s.salary));
  meta.push('📍 '+loc);
  if(hasReal(s.date)) meta.push('🗓 '+esc(s.date));
  var jobTitle = hasReal(s.product) ? 'Tuyển mẫu livestream — '+esc(s.product) : 'Tuyển mẫu livestream';
  root.innerHTML='<div class="detail-layout"><div class="detail-main">'
  + '<div class="company-head">'+shopLogoHTML(s)+'<div><h1>'+esc(s.name)+'</h1>'
  + '<p class="shop-sub">'+sub+'</p>'
  + '<div class="tags"><span class="tag">📍 '+esc(s.province)+'</span>'+(hasReal(s.product) ? '<span class="tag">'+esc(s.product)+'</span>' : '')+(s.shopNameKnown ? '' : '<span class="tag soft">người đăng tin tuyển</span>')+'</div></div></div>'
  + '<div class="detail-body">'
  + '<h2>Thông tin shop</h2>'
  + '<div class="fact-grid">'
  + '<div class="fact"><b>Tỉnh / thành phố</b><span>'+esc(s.province)+'</span></div>'
  + '<div class="fact"><b>Quận / huyện</b><span>'+esc(s.district)+'</span></div>'
  + '<div class="fact"><b>Mặt hàng</b><span>'+esc(s.product)+'</span></div>'
  + '<div class="fact"><b>Mức lương</b><span>'+esc(s.salary)+'</span></div>'
  + '<div class="fact"><b>Yêu cầu chính</b><span>'+esc(s.req)+'</span></div>'
  + '<div class="fact"><b>Kênh livestream</b><span>'+esc(s.channels)+'</span></div>'
  + '<div class="fact"><b>Ngày đăng tin</b><span>'+esc(s.date)+'</span></div></div>'
  + '<h2>Tin tuyển đang mở</h2>'
  + '<p class="job-count">Hiện có 1 tin tuyển đang mở.</p>'
  + '<article class="job-item">'
  + '<h3>'+jobTitle+'</h3>'
  + '<p class="job-meta">'+meta.join(' · ')+'</p>'
  + '<p><b>Yêu cầu:</b> '+esc(s.req)+'</p>'
  + (hasReal(s.channels) ? '<p><b>Kênh livestream:</b> '+esc(s.channels)+'</p>' : '')
  + '<div class="card-actions"><a class="btn btn-primary btn-sm" data-track="xem-bai-tuyen-goc" href="'+esc(s.src)+'" target="_blank" rel="noopener">Xem bài tuyển gốc trên Facebook →</a>'
  + '<a class="btn btn-ghost btn-sm" data-track="nhan-zalo-ver2solution" href="https://zalo.me/0329983699" target="_blank" rel="noopener">Nhắn Zalo Ver2Solution</a></div>'
  + '</article>'
  + '<p class="warn">Shop có thể yêu cầu cập nhật hoặc gỡ tin qua nút Góp ý (💬).</p>'
  // v99 (§3): sao dong bo voi the danh sach + mien tru + goi y dang ky/
  // dang nhap de sua tin va ghim top (nut ghim o hop mountPointsDetail).
  + '<p class="detail-star">Ấn sao để đưa shop này lên top 60 phút: ' + starButtonHTML('shop_profile', s.id) + '</p>'
  + '<p class="disclaimer">'+DISCLAIMER+'</p>'+ownerNoteHTML('shop', s.id)+'</div></div>'
  + '<div><div class="contact-card"><h2>Liên hệ với shop</h2>'
  + gatedContactsHTML('shop_profile', s.id, s.contacts)
  + '<p>Chỉ hiển thị thông tin liên hệ do chính shop công khai trong bài tuyển hoặc trên kênh công khai của shop. Thông tin chưa công khai không hiển thị.</p>'
  + '<a class="btn btn-light" data-track="nhan-zalo-ver2solution" href="https://zalo.me/0329983699" target="_blank" rel="noopener">Nhắn Zalo Ver2Solution 032 998 3699</a></div></div></div>';
  var others=document.getElementById('otherShops');
  if(others) others.innerHTML=(D.shops||[]).filter(function(x){return x.id!==s.id;}).slice(0,6).map(shopCardHTML).join('');
  mountPointsDetail('shop_profile', s.id);
  v2sSignupPopup('detail'); // v185: popup goi y dang ky khi xem chi tiet (chi goi y, khong chan).
}
/* v85: thong bao man hinh ban mobile — dung 2 dong (yeu cau nguoi dung
   13:33 + 13:36 ngay 07/11). Chi hien tren mobile (CSS .mobile-notice
   an mac dinh, chi hien <=768px); thanh nho tren cung, tren header,
   tren MOI trang (chen qua js/app.js — script chung chay moi trang).
   Co nut X de tat; sau khi tat thi khong hien lai trong cung phien
   (sessionStorage 'v2s-mobile-notice' = 'off'); phien moi hien lai.
   Khong chan noi dung, khong che nut Dang nhap/Menu, khong tran ngang
   o 390px (static flow, khong fixed). */
var MOBILE_NOTICE_KEY = 'v2s-mobile-notice';
var MOBILE_NOTICE_LINES = ['Mở web PC để xem chi tiết thông tin hay hữu ích', 'Bản thử nghiệm mọi tính năng hoàn toàn miễn phí'];
function initMobileNotice(){
  if(typeof document === 'undefined' || !document.body || !document.createElement) return;
  if(document.getElementById('mobileNotice')) return;
  try {
    if(typeof sessionStorage !== 'undefined' && sessionStorage.getItem(MOBILE_NOTICE_KEY) === 'off') return;
  } catch (e) { /* sessionStorage khong dung duoc thi van hien banner */ }
  var bar = document.createElement('div');
  bar.className = 'mobile-notice';
  bar.id = 'mobileNotice';
  bar.setAttribute('role', 'note');
  var text = document.createElement('div');
  text.className = 'mobile-notice-text';
  MOBILE_NOTICE_LINES.forEach(function (line) {
    var s = document.createElement('span');
    s.textContent = line;
    text.appendChild(s);
  });
  var close = document.createElement('button');
  close.type = 'button';
  close.className = 'mobile-notice-close';
  close.setAttribute('aria-label', 'Đóng thông báo');
  close.textContent = '✕';
  close.addEventListener('click', function () {
    try { if(typeof sessionStorage !== 'undefined') sessionStorage.setItem(MOBILE_NOTICE_KEY, 'off'); } catch (e) {}
    if(bar.parentNode) bar.parentNode.removeChild(bar);
  });
  bar.appendChild(text);
  bar.appendChild(close);
  document.body.insertBefore(bar, document.body.firstChild);
}
/* v85: header phan anh trang thai dang nhap (loi 3, phat hien qua kiem
   chung E2E 13:48 07/11 — truoc day header trang chu van hien nut
   "Đăng Nhập" du da dang nhap). Cap nhat theo yeu cau nguoi dung 15:52
   07/11 (test tren dien thoai that): sau dang nhap nut "Đăng Nhập" BIEN
   MAT, thay bang TEN nguoi dung da dang nhap — bat buoc, moi trang, ca
   mobile lan desktop. Ten lay theo thu tu: user_metadata.full_name/name
   (tai khoan OAuth) -> profiles.full_name (ho so da dien o Trang cua toi)
   -> shop_profiles.shop_name (v232 S3-10b: TK chi co ho so shop)
   -> phan truoc @ cua email (theo bo sung spec 15:52 07/11); chi khi ca 4
   deu khong co moi du phong "Trang của tôi". Nut van tro toi
   trang-cua-toi.html; chua dang nhap thi giu nut "Đăng Nhập" nhu cu. Dung
   chung trang thai phien tu js/auth-ui.js (getSession/onSessionChange);
   khong co auth-ui.js hoac chua ket noi Supabase thi bo qua lang le,
   khong lam vo header. */
function headerMetaName(user){
  if(!user) return null;
  var md = user.user_metadata || {};
  var n = md.full_name || md.name || '';
  if(typeof n === 'string' && n.trim()) return n.trim();
  return null;
}
function headerDisplayName(user){
  if(!user) return null;
  var n = headerMetaName(user);
  if(n) return n;
  var em = user.email || '';
  var at = em.indexOf('@');
  if(at > 0) return em.slice(0, at);
  return null;
}
function initHeaderAuth(){
  if(typeof document === 'undefined' || !document.querySelector) return;
  // v90 (F): [href*="dang-nhap.html"] de khop ca trang bai-viet (href
  // "../dang-nhap.html?next=...") — truoc day chi khop trang goc.
  // v114 (P2-8): nut header trang Gioi thieu gio la dang-ky.html — khop
  // ca hai, de header khi da dang nhap van doi thanh chip ten + xu.
  var btn = document.querySelector('.site-head .btn[href*="dang-nhap.html"]')
    || document.querySelector('.site-head .btn[href*="dang-ky.html"]');
  if(!btn) return;
  if(!btn._loginLabel) btn._loginLabel = btn.textContent;
  if(!btn._loginHref) btn._loginHref = btn.getAttribute('href');
  // v166 (C1/N1): trước khi session đầu tiên được xác định, nút header
  // KHÔNG hiện "Đăng Nhập" (nhãn tĩnh trong HTML) — Zalo ghi 05:18
  // trang thoáng hiện nút Đăng Nhập rồi mới hiện tên tài khoản, trông
  // như phiên vừa mất. Hiện "…" (đang tải phiên) cho tới khi apply()
  // đầu tiên đặt nhãn đúng; apply() luôn đặt nhãn dứt khoát cả 2 nhánh
  // (đã đăng nhập / chưa đăng nhập) nên trạng thái chờ không kẹt lại.
  try {
    var _A166 = (typeof window !== 'undefined') ? window.V2SAuthUI : null;
    if (_A166 && typeof _A166.getSession === 'function') btn.textContent = '…';
  } catch (e) {}
  // Tien to thu muc ('' o trang goc, '../' o trang bai-viet) de link
  // Trang cua toi / Trang chu khong tro thanh 404 o trang bai-viet.
  var pathPrefix = (btn._loginHref && btn._loginHref.indexOf('../') === 0) ? '../' : '';
  // Xu v2 (GĐ2, 20:22 07/11): khi đã đăng nhập, header hiện số dư xu
  // cạnh tên người dùng, dạng "Tên · 10 xu". Lỗi/mất mạng/RPC chưa có
  // thì KHÔNG hiện số dư (không vỡ header, không hiện 0 giả).
  var headerName = null, headerBalance = null;
  var headerNameUserId = null; // v224 (S3-10): nguoi dung ma headerName dang cho — doi phien thi lookup cu khong duoc ghi de
  var headerBalanceLoading = false; // v114 (P3-4): dang tai so du -> "Ten · …", khong hien 0 gia.
  var headerBalanceSeq = 0; // v117: so thu tu lan doc so du — chi lan doc moi nhat duoc ap dung ket qua.
  var menuEl = null, menuNameEl = null, menuPointsEl = null, menuWrap = null;
  function renderHeaderLabel(){
    if(headerName === null) return;
    btn.textContent = headerName + (headerBalanceLoading ? ' · …' : (headerBalance === null ? '' : ' · ' + headerBalance + ' xu'));
    // v90 (F): dong bo ten + diem vao dropdown dang xuat.
    if(menuNameEl) menuNameEl.textContent = headerName;
    if(menuPointsEl){
      if(headerBalance === null){ menuPointsEl.hidden = true; }
      else { menuPointsEl.hidden = false; menuPointsEl.textContent = 'Còn lại: ' + headerBalance + ' xu'; }
    }
  }
  // v117 (pheu dang ky): chong doc cu thang doc moi — SIGNED_IN kich
  // loadHeaderBalance() doc so du TRUOC khi RPC cong xu dang ky xong
  // (tra 0), trong khi V20HeaderRefresh() sau award doc lai tra 10; neu
  // phan hoi cua lan doc cu ve SAU lan doc moi thi ghi de 0 len 10 va
  // header ket o "0 xu" toi khi tai lai trang. Moi lan doc lay so thu tu
  // moi; chi lan doc moi nhat duoc ap dung ket qua (ca thanh cong lan loi).
  function loadHeaderBalance(){
    var seq = ++headerBalanceSeq;
    try {
      headerBalanceLoading = true; renderHeaderLabel();
      loadPointsScripts().then(function(){
        if(seq !== headerBalanceSeq) return; // da co lan doc moi hon — bo qua
        var R = window.Ver2Reward;
        if(!R || typeof R.getMyPointsBalanceResult !== 'function'){ headerBalanceLoading = false; renderHeaderLabel(); return; }
        R.getMyPointsBalanceResult().then(function (r){
          if(seq !== headerBalanceSeq) return; // ket qua cu — khong ghi de so moi
          headerBalanceLoading = false;
          if(r && r.ok){ headerBalance = Number(r.balance) || 0; }
          renderHeaderLabel();
        }).catch(function () { if(seq !== headerBalanceSeq) return; headerBalanceLoading = false; renderHeaderLabel(); });
      }).catch(function () { if(seq !== headerBalanceSeq) return; headerBalanceLoading = false; renderHeaderLabel(); });
    } catch (e) { if(seq !== headerBalanceSeq) return; headerBalanceLoading = false; /* bo qua — header giu ten khong so du */ }
  }
  // v90: cho phep lam moi so du header sau khi tru diem (reward.js goi
  // window.V20HeaderRefresh() moi khi spendPoints() thanh cong).
  if(typeof window !== 'undefined') window.V20HeaderRefresh = loadHeaderBalance;
  // v117 (pheu dang ky): dat truc tiep so du header = so xu vua duoc cong
  // (tai khoan moi bat dau tu 0 nen so du dung = so xu thuong dang ky),
  // khong cho doc lai tu server — tranh dua voi lan doc SIGNED_IN.
  // Tang seq de vo hieu hoa moi lan doc cu dang bay. auth-ui.js goi sau
  // awardRegistration() thanh cong; V20HeaderRefresh() sau do van chay
  // de xac nhan lai tu server.
  function setHeaderBalance(n){
    try {
      headerBalanceSeq++;
      headerBalance = Math.max(0, Number(n) || 0);
      headerBalanceLoading = false;
      renderHeaderLabel();
    } catch (e) {}
  }
  if(typeof window !== 'undefined') window.V20HeaderSetBalance = setHeaderBalance;
  // v90 (F): dropdown dang xuat duoi vien diem header. Bam vien diem mo
  // dropdown (ten nick + 'Con lai: X diem' + nut Dang xuat); dong khi bam
  // ra ngoai / nhan Escape / sau khi dang xuat. Vien diem do initHeaderAuth
  // tao, dung chung moi trang (goc + bai-viet).
  function toggleMenu(){
    if(!menuEl) return;
    menuEl.hidden = !menuEl.hidden;
  }
  function closeMenu(){
    if(menuEl) menuEl.hidden = true;
  }
  function doSignOut(){
    closeMenu();
    // Cap nhat UI NGAY (giong luong signOut hien co o auth-ui.js:443-462),
    // roi moi doi api().signOut() xong; sau do ve trang chu.
    headerName = null; headerBalance = null;
    try { btn.textContent = btn._loginLabel; btn.setAttribute('href', btn._loginHref); } catch (e) {}
    function goHome(){
      try { if(typeof window !== 'undefined' && window.location) window.location.href = pathPrefix + 'index.html'; } catch (e) {}
    }
    try {
      var M = window.McLivestreamAPI;
      if(M && typeof M.signOut === 'function'){
        var p = M.signOut();
        if(p && typeof p.then === 'function'){ p.then(goHome, goHome); return; }
        goHome(); return;
      }
    } catch (e) {}
    goHome();
  }
  function buildUserMenu(){
    if(menuEl || typeof document === 'undefined' || !document.createElement) return;
    var parent = btn.parentNode;
    if(!parent) return;
    menuWrap = document.createElement('span');
    menuWrap.className = 'user-menu-wrap';
    try { parent.insertBefore(menuWrap, btn); menuWrap.appendChild(btn); } catch (e) { return; }
    menuEl = document.createElement('div');
    menuEl.className = 'user-menu';
    menuEl.hidden = true;
    menuNameEl = document.createElement('a');
    menuNameEl.className = 'user-menu-name';
    menuNameEl.setAttribute('href', pathPrefix + 'trang-cua-toi.html');
    menuEl.appendChild(menuNameEl);
    menuPointsEl = document.createElement('p');
    menuPointsEl.className = 'user-menu-points';
    menuPointsEl.hidden = true;
    menuEl.appendChild(menuPointsEl);
    /* v161 (Rion 9b): menu tai khoan chi co ten + so xu + Dang xuat — them
       2 link tinh Vi diem / Quy tac diem (link tinh nen khong nhap nhay
       theo trang thai tai so du); Rion bao "chua vao duoc Vi diem" cung duoc sua. */
    var walletLink = document.createElement('a');
    walletLink.className = 'user-menu-link';
    walletLink.setAttribute('href', pathPrefix + 'vi.html');
    walletLink.textContent = 'Ví điểm';
    menuEl.appendChild(walletLink);
    var rulesLink = document.createElement('a');
    rulesLink.className = 'user-menu-link';
    rulesLink.setAttribute('href', pathPrefix + 'quy-tac-diem-thuong.html');
    rulesLink.textContent = 'Quy tắc điểm';
    menuEl.appendChild(rulesLink);
    var out = document.createElement('button');
    out.setAttribute('type', 'button');
    out.className = 'user-menu-logout';
    out.textContent = 'Đăng xuất';
    out.addEventListener('click', function(){ doSignOut(); });
    menuEl.appendChild(out);
    menuWrap.appendChild(menuEl);
    btn.addEventListener('click', function (e){
      if(headerName === null) return; // chua dang nhap: de link dang-nhap chay binh thuong
      if(e && typeof e.preventDefault === 'function') e.preventDefault();
      toggleMenu();
    });
    document.addEventListener('click', function (e){
      if(!menuEl || menuEl.hidden) return;
      try { if(menuWrap && menuWrap.contains(e.target)) return; } catch (err) {}
      closeMenu();
    });
    document.addEventListener('keydown', function (e){
      if(e && e.key === 'Escape') closeMenu();
    });
  }
  buildUserMenu();
  function apply(user){
    if(user){
      headerNameUserId = (user && (user.id || user.email)) || null;
      btn.setAttribute('href', pathPrefix + 'trang-cua-toi.html');
      if(headerMetaName(user)){
        headerName = headerDisplayName(user) || 'Trang của tôi';
        renderHeaderLabel();
        loadHeaderBalance();
      } else {
        /* v224 (S3-10): chua co ten that trong metadata thi KHONG render ten
           email-prefix ngay — truoc day header hien "hdfhyu" roi moi doi thanh
           "Muse Test" khi profiles.full_name ve (hoac ket o "hdfhyu" neu lookup
           cham/hong). Giu nut "…" (v166) cho toi khi lookup xong (toi da 3s)
           roi moi render 1 lan, dung ten. Metadata co ten thi render ngay nhu cu. */
        headerName = null;
        var _uid = headerNameUserId;
        var _settled = false;
        var _timer = null;
        function _settle(name){
          if(_settled || headerNameUserId !== _uid) return;
          _settled = true;
          headerName = name || 'Trang của tôi';
          renderHeaderLabel();
        }
        _timer = setTimeout(function(){ _settle(headerDisplayName(user)); }, 3000);
        loadHeaderBalance();
        /* Chua co ten that trong metadata — hoi them bang profiles.full_name;
           co ten that thi doi ten (uu tien hon phan truoc @ cua email). Chi doi
           ten neu van la cung nguoi dung (tranh truong hop doi phien trong luc
           cho ket qua).
           v232 (S3-10b): TK chi co ho so shop (khong co ho so mau) thi
           fetchMyProfile tra null -> hoi them shop_profiles.shop_name
           (fetchMyShopProfile, da co san trong API + RLS cho chu so huu doc)
           truoc khi roi ve phan truoc @ cua email. Thu tu uu tien giu nguyen:
           metadata -> ten mau -> ten shop -> phan truoc @. */
        try {
          var M = window.McLivestreamAPI;
          if(M && typeof M.fetchMyProfile === 'function'){
            M.fetchMyProfile().then(function (p) {
              if(p && p.full_name && String(p.full_name).trim()){
                clearTimeout(_timer);
                _settle(String(p.full_name).trim());
              } else if(typeof M.fetchMyShopProfile === 'function'){
                /* v232 (S3-10b): khong co ten mau -> thu ten shop. */
                M.fetchMyShopProfile().then(function (s) {
                  clearTimeout(_timer);
                  _settle(s && s.shop_name && String(s.shop_name).trim()
                    ? String(s.shop_name).trim()
                    : headerDisplayName(user));
                }).catch(function () { clearTimeout(_timer); _settle(headerDisplayName(user)); });
              } else {
                clearTimeout(_timer);
                _settle(headerDisplayName(user));
              }
            }).catch(function () { clearTimeout(_timer); _settle(headerDisplayName(user)); });
          } else {
            clearTimeout(_timer);
            _settle(headerDisplayName(user));
          }
        } catch (e) {
          clearTimeout(_timer);
          _settle(headerDisplayName(user));
        }
      }
    } else {
      headerName = null; headerNameUserId = null; headerBalance = null;
      closeMenu(); // v90 (F): dang xuat tu noi khac cung dong dropdown
      btn.textContent = btn._loginLabel;
      btn.setAttribute('href', btn._loginHref);
    }
  }
  try {
    var A = window.V2SAuthUI;
    if(!A || typeof A.getSession !== 'function') return;
    A.getSession().then(function (s) { apply(s && s.user ? s.user : null); }).catch(function () {});
    if(typeof A.onSessionChange === 'function') A.onSessionChange(function (user) { apply(user); });
  } catch (e) { /* bo qua — header giu nut Dang Nhap mac dinh */ }
}
/* v96: dai kich hoat ho so tren trang chu (chi index.html co phan tu
   #kich-hoat-ho-so; trang khac khong co thi bo qua lang le). */
function initActivationStrip(){
  if(typeof document === 'undefined' || !document.getElementById) return;
  if(!document.getElementById('kich-hoat-ho-so')) return;
  try {
    var A = (typeof window !== 'undefined') ? window.V2SActivation : null;
    if(A && typeof A.initHomeStrip === 'function') A.initHomeStrip();
  } catch (e) { /* bo qua — dai an mac dinh */ }
}
/* v166 (N10): form bình luận cho trang bài viết chi tiết (bai-viet/...
   html). Trang bài là file tĩnh, không có chỗ bình luận (chỉ có khung
   chia sẻ FB/Zalo/Copy link) — chèn nút Bình luận + khung bình luận
   ngay sau .share-box bằng JS (không sửa 135 file tĩnh), dùng chung
   commentToggleHTML + ủy quyền click của Ver2Comments.initCardComments
   (đã nối ở initPointsUI). target_ref = tên file bài (khớp quy ước
   của js/comments.js: 'article' + tên file). */
function initArticleComments(){
  if(typeof document === 'undefined' || !document.querySelector) return;
  try {
    if (String(location.pathname || '').indexOf('/bai-viet/') === -1) return;
    var shareBox = document.querySelector('.share-box');
    if (!shareBox || shareBox._v2sCommentsAdded) return;
    shareBox._v2sCommentsAdded = true;
    var slug = String(location.pathname || '').split('/').pop() || '';
    if (!slug) return;
    var wrap = document.createElement('div');
    wrap.className = 'v2s-article-comments';
    wrap.innerHTML = commentToggleHTML('article', slug);
    if (shareBox.parentNode) shareBox.parentNode.insertBefore(wrap, shareBox.nextSibling);
  } catch (e) { /* bỏ qua — trang bài vẫn đọc được, chỉ thiếu form bình luận */ }
}
/* ---- Xu thưởng v2: UI chạy lúc tải trang (nút, ghim, bình luận) ---- */
function pointsScriptBase(){
  try { return String(location.pathname || '').indexOf('/bai-viet/') !== -1 ? '../js/' : 'js/'; }
  catch (e) { return 'js/'; }
}
function loadPointsScripts(){
  if (typeof window !== 'undefined' && window.Ver2Reward && window.Ver2Comments) return Promise.resolve(true);
  if (typeof document === 'undefined' || typeof document.createElement !== 'function') return Promise.resolve(false);
  var base = pointsScriptBase();
  function load(src){
    return new Promise(function (resolve){
      if (src.indexOf('reward') !== -1 && window.Ver2Reward) return resolve(true);
      if (src.indexOf('comments') !== -1 && window.Ver2Comments) return resolve(true);
      // Môi trường test (document giả) không có document.head — bỏ qua.
      if (!document.head || typeof document.head.appendChild !== 'function') return resolve(false);
      var s = document.createElement('script'); s.src = src; s.async = false;
      s.onload = function(){ resolve(true); }; s.onerror = function(){ resolve(false); };
      document.head.appendChild(s);
    });
  }
  return load(base + 'reward.js').then(function(){ return load(base + 'comments.js'); });
}
function pointsLoggedIn(){
  try {
    if (window.V2SAuthUI && typeof window.V2SAuthUI.getSession === 'function') {
      return window.V2SAuthUI.getSession().then(function (s){ return !!(s && s.user); }).catch(function(){ return false; });
    }
  } catch (e) {}
  try {
    if (window.McLivestreamAPI && typeof window.McLivestreamAPI.getSession === 'function') {
      return window.McLivestreamAPI.getSession().then(function (s){ return !!(s && s.user); }).catch(function(){ return false; });
    }
  } catch (e) {}
  return Promise.resolve(false);
}
function pointsGuestNoteHTML(){
  return 'Đăng ký / đăng nhập tài khoản để bình luận và các hoạt động khác được cộng xu thưởng, đổi quà. <a href="dang-ky.html">Đăng ký</a> · <a href="dang-nhap.html">Đăng nhập</a>';
}
function pointsSessionUser(){
  // v222 (S1-1): đọc session bền — getSession() 1 lần có thể trả null
  // khi GoTrue chưa khôi phục xong (mở thẳng vi.html bằng phiên cũ),
  // form chuyển xu hiện sai "Cần đăng nhập" dù đã đăng nhập.
  // getSessionRobust thử lại tới ~2 giây rồi mới kết luận null.
  try {
    if (window.V2SAuthUI && typeof window.V2SAuthUI.getSessionRobust === 'function') {
      return window.V2SAuthUI.getSessionRobust(2000).then(function (s){ return (s && s.user) ? s.user : null; }).catch(function(){ return null; });
    }
    if (window.V2SAuthUI && typeof window.V2SAuthUI.getSession === 'function') {
      return window.V2SAuthUI.getSession().then(function (s){ return (s && s.user) ? s.user : null; }).catch(function(){ return null; });
    }
  } catch (e) {}
  try {
    if (window.McLivestreamAPI && typeof window.McLivestreamAPI.getSession === 'function') {
      return window.McLivestreamAPI.getSession().then(function (s){ return (s && s.user) ? s.user : null; }).catch(function(){ return null; });
    }
  } catch (e) {}
  return Promise.resolve(null);
}
function pointsPageName(){
  try { var parts = String(location.pathname || '').split('/'); return parts[parts.length - 1] || 'index.html'; }
  catch (e) { return 'index.html'; }
}
// ---- Xu v2: cong thu xu cho bo loc (1 xu/lan, chot 20:22 07/11) ----
// v139 (11/11/2026): BO CONG LOC — gateFilterApply chi con la ham chuyen
// tiep: goi thang doApply() + cuon toi ket qua, KHONG doi dang nhap,
// KHONG tru xu. Code cu (doi dang nhap / tru 1 xu / mien phi trong 10s)
// da duoc go khoi ham; filterLastCharge/filterNoteCharge giu lai nhu ham
// phu (khong con noi goi trong duong loc).
var lastFilterCharge = {};
function filterLastCharge(category){
  var ts = lastFilterCharge[category] || 0;
  try {
    if (typeof localStorage !== 'undefined') {
      var raw = JSON.parse(localStorage.getItem('v20_filter_charge_v1') || '{}');
      if (raw[category] && Number(raw[category]) > ts) ts = Number(raw[category]);
    }
  } catch (e) {}
  return ts;
}
function filterNoteCharge(category, ts){
  lastFilterCharge[category] = ts;
  try {
    if (typeof localStorage !== 'undefined') {
      var raw = JSON.parse(localStorage.getItem('v20_filter_charge_v1') || '{}');
      raw[category] = ts;
      localStorage.setItem('v20_filter_charge_v1', JSON.stringify(raw));
    }
  } catch (e) {}
}
// v116 (M15): thông báo lọc hiện dạng menu thả xuống (overlay), KHÔNG
// chèn inline vào lưới lọc — quy tắc đã chốt: mọi thông báo/lỗi trong bộ
// lọc PHẢI hiện dạng menu thả xuống. Phần tử .v2s-filter-msg được gắn vào
// .filter-area gần nhất (hoặc phần tử cha của anchor nếu không có
// .filter-area, vd form tìm kiếm ở trang chủ — cha nó là section.hero đã
// position:relative sẵn) và định vị absolute qua CSS; :empty thì ẩn.
function filterMsgEl(anchorEl){
  if (!anchorEl || typeof document === 'undefined') return null;
  var container = null;
  if (typeof anchorEl.closest === 'function') {
    try { container = anchorEl.closest('.filter-area'); } catch (e) { container = null; }
  }
  if (!container) container = anchorEl.parentNode;
  if (!container) return null;
  var existing = null;
  if (typeof container.querySelector === 'function') {
    try { existing = container.querySelector('.v2s-filter-msg'); } catch (e) { existing = null; }
  }
  if (!existing && container.children && typeof container.children.length === 'number') {
    for (var i = 0; i < container.children.length; i++) {
      var c = container.children[i];
      if (c && c.className && String(c.className).indexOf('v2s-filter-msg') !== -1) { existing = c; break; }
    }
  }
  if (existing) return existing;
  if (typeof document.createElement !== 'function') return null;
  var p = document.createElement('p');
  p.className = 'v2s-filter-msg';
  p.setAttribute('role', 'status');
  if (typeof container.appendChild === 'function') container.appendChild(p);
  else if (typeof container.insertBefore === 'function') container.insertBefore(p, null);
  else return null;
  return p;
}
// v90 (3): sau khi loc ap dung thanh cong, cuon trang toi dau khu vuc ket
// qua (trang danh sach mau/shop — doApply() o day chi render, khong cuon).
// Lo/xuong KHONG cuon o day: apply() cua section da cuon toi the khop dau
// tien (v72); cuon them se ghi de vi tri do. Chi cuon khi loc ap dung
// thanh cong — gate chan (chua dang nhap / het diem / loi) thi khong cuon.
function scrollToResults(category){
  try {
    if (typeof document === 'undefined') return;
    var sel = null;
    if (category === 'model') sel = '#listGrid, #hubResults';
    else if (category === 'shop') sel = '#publicShopsList';
    else return; // 'lot'/'factory': apply() cua section da cuon (v72)
    var el = document.querySelector(sel);
    if (!el || typeof el.scrollIntoView !== 'function') return;
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } catch (e) { /* loi cuon khong bao gio lam vo loc */ }
}
/* v118 (P2-4): goi y "Cần đăng nhập — ..." chi hien khi CHUA dang nhap.
   Trang thai doi trong phien (dang nhap/xuat o form cuoi trang) thi an/
   hien theo qua onSessionChange; luc mo trang kiem tra 1 lan qua
   getSession. Khong co V2SAuthUI thi giu nguyen hien thi (mac dinh an toan). */
function initFilterHint(){
  if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return;
  function apply(loggedIn){
    var hints = document.querySelectorAll('.filter-hint');
    for (var i = 0; i < hints.length; i++) { hints[i].hidden = !!loggedIn; }
  }
  try {
    var A = window.V2SAuthUI;
    if (A && typeof A.getSession === 'function') {
      A.getSession().then(function (s){ apply(!!(s && s.user)); }).catch(function(){ /* giu hien */ });
    }
    if (A && typeof A.onSessionChange === 'function') {
      A.onSessionChange(function (user){ apply(!!user); });
    }
  } catch (e) { /* giu hien — goi y khong bao gio lam vo trang */ }
}
/* v139 (11/11/2026): BO CONG LOC — loc KHONG can dang nhap, KHONG tru xu.
   Truoc day ham nay chan khach vang lai (doi dang nhap) roi tru 1 xu moi
   lan ap dung (tru khi co FREE_SERVICES / trong 10s sau lan tru truoc).
   Tu v139, bo loc mo cho moi nguoi: goi thang doApply() roi cuon toi ket
   qua (scrollToResults — chi cuon khi bam Ap dung / doi trang, khong
   cuon khi chon doi tuong o menu loc). Giu nguyen chu ky ham (category,
   page, doApply, msgAnchor) + tra Promise<true> de cac noi goi (nut Ap
   dung, phan trang, doi select, tim kiem hero) khong can sua. */
async function gateFilterApply(category, page, doApply, msgAnchor){
  var msgEl = msgAnchor ? filterMsgEl(msgAnchor) : null;
  if (msgEl) msgEl.innerHTML = '';
  try { doApply(); } catch (e) {}
  scrollToResults(category);
  return Promise.resolve(true);
}
/* Đọc pin đang chạy qua RPC get_active_pins(p_category) — KHÔNG SELECT
   trực tiếp bảng pinned_posts (RLS owner-only, client không đọc được pin
   của người khác). RPC là SECURITY DEFINER, chỉ trả pin đang active
   (is_active và pinned_until > now()), không trả user_id/points_spent.
   Category dùng đúng enum M7.2: mau/shop/lo/xuong/bai-viet/kiot.
   RPC lỗi/không có dữ liệu → [] → danh sách giữ thứ tự thường, không lỗi. */
function fetchActivePins(category){
  try {
    var A = window.McLivestreamAPI;
    if (!A || !A.client) return Promise.resolve([]);
    return A.client.rpc('get_active_pins', { p_category: category })
      .then(function (res){ if (res.error) return []; return res.data || []; })
      .catch(function(){ return []; });
  } catch (e) { return Promise.resolve([]); }
}
// Xếp lại các thẻ ĐANG HIỂN THỊ trong 1 container: bài được ghim (còn hạn)
// lên trước theo pinned_until giảm dần, còn lại giữ nguyên thứ tự.
// M7/policy SELECT chưa có → pins rỗng → giữ nguyên thứ tự, không báo lỗi.
function applyPinnedOrder(container, pins){
  if (!container || !pins || !pins.length) return;
  var R = window.Ver2Reward;
  var now = new Date();
  var active = pins.filter(function (p){ return R && typeof R.isPinActive === 'function' ? R.isPinActive(p, now) : new Date(p.pinned_until) > now; });
  if (!active.length) return;
  active.sort(function (a, b){ return new Date(b.pinned_until) - new Date(a.pinned_until); });
  var order = {};
  active.forEach(function (p, i){ order[String(p.target_id)] = i; });
  var kids = Array.prototype.slice.call(container.children);
  var has = kids.some(function (el){ return order[String(el.getAttribute('data-v2s-id'))] !== undefined; });
  if (!has) return;
  kids.sort(function (a, b){
    var ra = order[String(a.getAttribute('data-v2s-id'))];
    var rb = order[String(b.getAttribute('data-v2s-id'))];
    if (ra === undefined) ra = Infinity;
    if (rb === undefined) rb = Infinity;
    return ra - rb;
  });
  kids.forEach(function (el){ container.appendChild(el); });
}
function applyPinnedOrderToLists(){
  // Category = enum M7.2 (trang danh sách): mau/shop/lo/xuong/bai-viet/kiot.
  var jobs = [
    ['listGrid', 'mau'], ['publicShopsList', 'shop'],
    ['newsMain', 'bai-viet'], ['lotGrid1', 'lo'], ['lotGrid2', 'lo'],
    ['lotGrid3', 'lo'], ['factoryGrid', 'xuong']
  ];
  jobs.forEach(function (job){
    var el = document.getElementById(job[0]);
    if (!el) return;
    fetchActivePins(job[1]).then(function (pins){ applyPinnedOrder(el, pins); });
  });
  // Kiot (thanh-ly-kiot.html) dùng chung lưới lô — xếp theo category 'kiot'.
  ['lotGrid1', 'lotGrid2', 'lotGrid3'].forEach(function (id){
    var el = document.getElementById(id);
    if (!el) return;
    fetchActivePins('kiot').then(function (pins){ applyPinnedOrder(el, pins); });
  });
}
// Hộp ghim + mục bình luận trên trang chi tiết (ho-so / chi-tiet-shop) và
// trang bài báo. Gọi sau khi trang chi tiết đã render xong.
// v91 (BUG-10): giờ hết hạn ghim hiện giờ Việt Nam dễ đọc ("00:41 ngày
// 08/11") thay vì timestamp ISO UTC thô. R.formatVnDateTime (reward.js)
// chưa có thì rơi về chuỗi gốc.
function pinUntilText(until, R) {
  if (!until) return '';
  try { if (R && typeof R.formatVnDateTime === 'function') return R.formatVnDateTime(until); } catch (e) {}
  return String(until);
}
function mountPointsDetail(targetType, targetId){
  if (typeof document === 'undefined' || typeof document.createElement !== 'function') return;
  var anchor = document.getElementById('detailRoot') || document.getElementById('shopDetailRoot');
  var articleEl = null;
  if (!anchor) {
    // Trang bài báo tĩnh: chỉ gắn khi document hỗ trợ querySelector
    // (bộ test vm dùng document giả không có querySelector — bỏ qua).
    if (typeof document.querySelector !== 'function') return;
    articleEl = document.querySelector('.form-card.article article[itemtype], article[itemtype*="NewsArticle"]');
    if (!articleEl) return;
    targetType = 'article';
    try { var parts = String(location.pathname || '').split('/'); targetId = parts[parts.length - 1] || targetId; } catch (e) {}
  }
  if (!targetId) return;
  if (document.getElementById('v2sPinBox')) return; // chỉ gắn 1 lần
  var wrap = document.createElement('div');
  wrap.innerHTML = '<section class="v2s-pin-box" id="v2sPinBox" data-v2s-target-type="'+esc(targetType)+'" data-v2s-target-id="'+esc(targetId)+'">'
    + '<h2>📌 Ghim lên top</h2>'
    + '<p class="v2s-pin-balance">Số dư xu của bạn: <b>…</b></p>'
    + '<p>Ghim đang <b>tạm thời miễn phí</b> (giá thường 1 xu = 1 giờ). Sau khi hết hạn ghim, bài trở về thứ tự thường.</p>'
    + '<label>Số giờ ghim (1–720)<input type="number" class="v2s-pin-hours" min="1" max="720" value="24"></label> '
    + '<button class="btn btn-primary btn-sm" type="button" data-v2s-pin-confirm>Ghim lên top</button>'
    + '<p class="v2s-pin-msg" role="status"></p></section>'
    + '<div class="v2s-comments-mount" id="v2sCommentsMount"></div>';
  if (anchor && typeof anchor.insertAdjacentElement === 'function') anchor.insertAdjacentElement('afterend', wrap);
  else if (articleEl && typeof articleEl.insertAdjacentElement === 'function') articleEl.insertAdjacentElement('afterend', wrap);
  else return;
  loadPointsScripts().then(function(){
    var R = window.Ver2Reward, C = window.Ver2Comments;
    var box = document.getElementById('v2sPinBox');
    if (!box) return;
    pointsLoggedIn().then(function (loggedIn){
      var bal = box.querySelector('.v2s-pin-balance');
      var msg = box.querySelector('.v2s-pin-msg');
      var btn = box.querySelector('[data-v2s-pin-confirm]');
      if (!loggedIn) {
        if (bal) bal.innerHTML = pointsGuestNoteHTML();
        // Khách vãng lai: KHÔNG disable nút Ghim — bấm nút sẽ hiện ghi chú
        // "Bạn cần đăng nhập tài khoản để ghim bài" (handler
        // data-v2s-pin-confirm dưới đây kiểm tra đăng nhập trước khi gọi RPC).
        if (msg) msg.textContent = '';
        return;
      }
      if (R && typeof R.getMyPointsBalance === 'function') {
        R.getMyPointsBalance().then(function (b){ if (bal) bal.innerHTML = 'Số dư xu của bạn: <b>' + b + ' xu</b>'; });
      } else if (bal) { bal.textContent = 'Hệ thống xu thưởng chưa bật (đang chờ migration M7).'; }
    });
    var mount = document.getElementById('v2sCommentsMount');
    if (mount && C && typeof C.renderComments === 'function') C.renderComments(targetType, targetId, mount);
  });
}
function initPointsUI(){
  if (typeof document === 'undefined') return;
  // Nút thích/chia sẻ/ghim trên mọi thẻ (ủy quyền click — thẻ render lại
  // khi lọc/phân trang vẫn chạy).
  document.addEventListener('click', function (e){
    // Xem liên hệ 1 hồ sơ — v92: TẠM MIỄN PHÍ (cờ V20_FREE_SERVICES ở
    // js/reward.js): đã đăng nhập thì hiện ngay, không trừ xu, không kiểm
    // tra v20_contact_viewed_v1 nữa. Khách vãng lai vẫn thấy lời mời đăng
    // ký (cửa đăng nhập giữ nguyên). Code trừ xu giữ nguyên để mở lại
    // chỉ bằng 1 cờ.
    var vc = e.target && e.target.closest ? e.target.closest('[data-v2s-view-contact]') : null;
    if (vc) {
      var wrap = vc.closest ? vc.closest('.v2s-contacts-gated') : null;
      if (!wrap) return;
      e.preventDefault();
      var tt = wrap.getAttribute('data-v2s-target-type'), ti = wrap.getAttribute('data-v2s-target-id');
      var hidden = wrap.querySelector('.v2s-contacts-hidden');
      var cmsg = wrap.querySelector('.v2s-contact-msg');
      // v114 (P2-6): phan hoi DONG BO ngay khi bam — truoc day chuoi async
      // khong co .catch nen khach bam "Xem lien he" thay nhu chet.
      if (cmsg) cmsg.textContent = 'Đang kiểm tra đăng nhập…';
      var reveal = function(){ if (hidden) hidden.hidden = false; vc.style.display = 'none'; if (cmsg) cmsg.textContent = ''; };
      loadPointsScripts().then(function(){
        return pointsSessionUser().then(function (user){
          if (!user) { if (cmsg) cmsg.innerHTML = 'Hãy <a href="dang-ky.html">đăng ký</a> để xem liên hệ — đăng ký đủ nhận 10 xu! <a href="dang-nhap.html">Đăng nhập</a>';
            // v118 (P2-6): them toast — dong thong bao inline tren the
            // chi tiet tung bi mo (chu #0b5d4e tren nen xanh dam, da sua
            // mau o v20.css) nen nguoi dung tuong nut khong phan hoi;
            // toast dam bao phan hoi luon thay duoc.
            v2sToast('Hãy đăng ký để xem liên hệ — đăng ký đủ nhận 10 xu!');
            return; }
          var R = window.Ver2Reward;
          if (R && R.FREE_SERVICES === true) { reveal(); return; } // v92: miễn phí
          if (R && typeof R.hasViewedContactToday === 'function' && R.hasViewedContactToday(tt, ti)) { reveal(); return; }
          if (!R || typeof R.spendPoints !== 'function') { if (cmsg) cmsg.textContent = 'Hệ thống xu chưa bật (đang chờ migration M7), chưa xem được liên hệ.'; return; }
          var day = (typeof R.dayKeySaigon === 'function') ? R.dayKeySaigon(new Date()) : '';
          var key = (typeof R.contactViewKey === 'function') ? R.contactViewKey(tt, ti, day) : '';
          R.spendPoints('contact_view', 5, tt, ti, key).then(function (res){
            if (res && res.ok) { if (typeof R.markContactViewed === 'function') R.markContactViewed(tt, ti, day); reveal(); }
            else if (res && res.code === 'insufficient_balance') { if (cmsg) cmsg.innerHTML = 'Bạn đã hết xu để xem liên hệ. <a href="huong-dan-diem.html">Xem cách kiếm xu →</a>'; }
            else { if (cmsg) cmsg.textContent = 'Chưa xem được liên hệ: ' + ((res && res.error) || 'hệ thống xu chưa bật.'); }
          }).catch(function(){ if (cmsg) cmsg.textContent = 'Chưa xem được liên hệ: lỗi mạng, thử lại sau.'; });
        });
      }).catch(function(){ if (cmsg) cmsg.textContent = 'Không kiểm tra được đăng nhập, thử tải lại trang rồi bấm lại.'; });
      return;
    }
    // Nút "Ghim lên top" trong hộp ghim trang chi tiết.
    var pc = e.target && e.target.closest ? e.target.closest('[data-v2s-pin-confirm]') : null;
    if (pc) {
      var box = pc.closest ? pc.closest('.v2s-pin-box') : null;
      if (!box) return;
      e.preventDefault();
      var hoursInput = box.querySelector('.v2s-pin-hours');
      var pinMsg = box.querySelector('.v2s-pin-msg');
      var hours = hoursInput ? Number(hoursInput.value) : 0;
      loadPointsScripts().then(function(){
        return pointsLoggedIn().then(function (loggedIn){
          if (!loggedIn) { if (pinMsg) pinMsg.textContent = 'Bạn cần đăng nhập tài khoản để ghim bài'; return; }
          var R = window.Ver2Reward;
          if (!R) { if (pinMsg) pinMsg.textContent = 'Hệ thống xu thưởng chưa bật (đang chờ migration M7).'; return; }
          R.pinPost(box.getAttribute('data-v2s-target-type'), box.getAttribute('data-v2s-target-id'), box.getAttribute('data-v2s-target-type'), hours).then(function (r){
            if (!pinMsg) return;
            if (r && r.ok) {
              var until = r.pin && (r.pin.pinned_until || (Array.isArray(r.pin) && r.pin[0] && r.pin[0].pinned_until));
              pinMsg.textContent = 'Đã ghim lên top' + (until ? ' đến ' + pinUntilText(until, R) : '') + ((r && r.cost === 0) ? ' (miễn phí).' : ' (' + hours + ' xu).');
            } else { pinMsg.textContent = 'Chưa ghim được: ' + ((r && r.error) || 'hệ thống xu chưa bật.'); }
          });
        });
      });
      return;
    }
    var t = e.target && e.target.closest ? e.target.closest('[data-v2s-like],[data-v2s-share],[data-v2s-pin]') : null;
    if (!t) return;
    var row = t.closest ? t.closest('.v2s-points-row') : null;
    if (!row) return;
    var type = t.hasAttribute('data-v2s-like') ? 'like' : (t.hasAttribute('data-v2s-share') ? 'share' : 'pin');
    var targetType = row.getAttribute('data-v2s-target-type');
    var targetId = row.getAttribute('data-v2s-target-id');
    var msg = row.querySelector('.v2s-points-msg');
    function say(html){ if (msg) msg.innerHTML = html; }
    e.preventDefault();
    loadPointsScripts().then(function(){
      return pointsLoggedIn().then(function (loggedIn){
        if (!loggedIn) { say(type === 'pin' ? 'Bạn cần đăng nhập tài khoản để ghim bài' : pointsGuestNoteHTML()); return; }
        var R = window.Ver2Reward;
        if (!R) { say('Hệ thống xu thưởng chưa bật (đang chờ migration M7).'); return; }
        if (type === 'pin') {
          // Form ghim inline trên thẻ: nhập giờ + xác nhận, hiện số dư.
          if (row.querySelector('.v2s-pin-form')) return;
          var form = document.createElement('span');
          form.className = 'v2s-pin-form';
          form.innerHTML = '<input type="number" min="1" max="720" value="24" aria-label="Số giờ ghim"> giờ · <button class="btn btn-primary btn-sm" type="button">Ghim</button> <span class="v2s-pin-balance">…</span>';
          row.appendChild(form);
          var inp = form.querySelector('input');
          var bal = form.querySelector('.v2s-pin-balance');
          if (typeof R.getMyPointsBalance === 'function') R.getMyPointsBalance().then(function (b){ if (bal) bal.textContent = 'Số dư: ' + b + ' xu'; });
          form.querySelector('button').addEventListener('click', function(){
            var hours = Number(inp.value);
            R.pinPost(targetType, targetId, targetType, hours).then(function (r){
              if (r && r.ok) {
                var until = r.pin && (r.pin.pinned_until || (Array.isArray(r.pin) && r.pin[0] && r.pin[0].pinned_until));
                say('Đã ghim lên top' + (until ? ' đến ' + esc(pinUntilText(until, R)) : '') + ((r && r.cost === 0) ? ' (miễn phí).' : ' (' + hours + ' xu).'));
                form.remove();
              } else { say('Chưa ghim được: ' + esc((r && r.error) || 'hệ thống xu chưa bật.')); }
            });
          });
          return;
        }
        R.awardInteraction(type, targetType, targetId).then(function (r){
          // v114 (P3-6): nut Chia se vo hieu hoa ngay sau khi RPC tra ok,
          // giong nut Thich (markLiked) — truoc day chi doi trang thai Like.
          if (r && r.ok && Number(r.points) > 0) { if (type === 'like') markLiked(t); else if (type === 'share') markShared(t); say('+' + Number(r.points) + ' xu (1 lần/ngày)'); }
          else if (r && r.ok) { if (type === 'like') markLiked(t); else if (type === 'share') markShared(t); say(type === 'like' ? 'Đã tính xu thích hôm nay' : 'Đã tính xu chia sẻ hôm nay'); }
          else say('Chưa tính được xu: ' + esc((r && r.error) || 'hệ thống xu chưa bật.'));
        });
      });
    });
  });
  // Trang bài báo tĩnh (bai-viet/*.html): gắn hộp ghim + bình luận sau bài.
  if (typeof document.querySelector === 'function'
    && document.querySelector('.form-card.article article[itemtype], article[itemtype*="NewsArticle"]')) {
    mountPointsDetail('article', '');
  }
  // Xếp lại danh sách theo ghim đang hoạt động (lỗi/lưới vắng → giữ nguyên).
  // v92 (C2): bình luận dưới mỗi thẻ lô/xưởng/kiot — gắn listener nút toggle
  // + đếm số bình luận đã duyệt (Ver2Comments.initCardComments).
  loadPointsScripts().then(function(){
    applyPinnedOrderToLists();
    var C = window.Ver2Comments;
    if (C && typeof C.initCardComments === 'function') C.initCardComments();
  });
}
/* ---- Chuyển xu trên trang ví (vi-tien-ao.html, chốt 20:23 + 20:25) ---- */
function initTransferForm(){
  if (typeof document === 'undefined') return;
  var form = document.getElementById('transferForm');
  if (!form) return;
  var streakEl = document.getElementById('transferStreak');
  var msgEl = document.getElementById('transferMsg');
  var histEl = document.getElementById('transferHistory');
  var submitBtn = document.getElementById('transferSubmit');
  var emailEl = document.getElementById('transferEmail');
  var amountEl = document.getElementById('transferAmount');
  var noteEl = document.getElementById('transferNote');
  var balEl = document.getElementById('transferBalance');
  // v91 (BUG-08): trạng thái phiên hiện tại + cờ đã gắn submit (gắn 1 lần
  // duy nhất dù refreshTransfer chạy nhiều lần khi phiên đổi).
  var streak = null, balance = 0, currentUser = null, submitWired = false;
  function say(t){ if (msgEl) msgEl.textContent = t || ''; }
  function streakText(st){
    if (!st || !st.ok) return 'Chưa tải được chuỗi online (hệ thống xu chưa bật hoặc mất mạng).';
    if (st.eligible) return 'Đã online liên tiếp ' + st.current_streak + '/30 ngày — bạn đã đủ điều kiện chuyển xu.';
    return 'Đã online liên tiếp ' + st.current_streak + '/30 ngày — còn ' + st.days_remaining + ' ngày nữa mới được chuyển xu.';
  }
  function histHTML(items){
    if (!items || !items.length) return '<p>Chưa có lần chuyển xu nào.</p>';
    return '<ul class="v2s-transfer-history">' + items.map(function (it){
      // get_my_transfer_history() trả direction 'sent'/'received', amount âm
      // khi gửi (-delta), dương khi nhận; counterparty_email là email bên kia.
      var dir = (it.direction === 'received' || it.direction === 'in' || it.type === 'transfer_in') ? 'Nhận' : 'Gửi';
      var other = esc(it.counterparty_email || it.other_email || it.recipient_email || it.sender_email || '');
      var amt = Math.abs(Number(it.amount || it.points || 0));
      var when = '';
      try { when = it.created_at ? new Date(it.created_at).toLocaleDateString('vi-VN') : ''; } catch (e) {}
      return '<li><b>' + dir + ' ' + amt + ' xu</b>' + (other ? ' — ' + other : '') + (when ? ' · ' + esc(when) : '') + (it.note ? '<br><span>' + esc(it.note) + '</span>' : '') + '</li>';
    }).join('') + '</ul>';
  }
  // v91 (BUG-08): tải lại số dư/chuỗi/lịch sử chuyển xu mỗi khi phiên đổi
  // (đăng nhập/đăng xuất) thay vì chỉ tải 1 lần lúc mở trang — dòng "Cần
  // đăng nhập..." phải biến mất ngay khi đã đăng nhập và hiện lại khi đăng
  // xuất, không cần tải lại trang.
  function refreshTransfer(){
  loadPointsScripts().then(function(){
    return pointsSessionUser().then(function (user){
      currentUser = user || null;
      var R = window.Ver2Reward;
      if (!user) {
        streak = null; balance = 0;
        if (streakEl) streakEl.innerHTML = 'Cần <a href="dang-nhap.html">đăng nhập</a> để chuyển xu. Chưa có tài khoản? <a href="dang-ky.html">Đăng ký đủ nhận 10 xu</a>.';
        if (balEl) balEl.textContent = 'Cần đăng nhập để xem số dư xu.';
        if (histEl) histEl.innerHTML = '<p>Chưa tải được lịch sử chuyển xu.</p>';
        if (submitBtn) submitBtn.disabled = true;
        return;
      }
      if (!R) { if (streakEl) streakEl.textContent = 'Hệ thống xu chưa bật (đang chờ migration M7).'; return; }
      // v166 (N9): đã đăng nhập thì KHÔNG để nguyên dòng mặc định
      // "Cần đăng nhập để xem số dư xu." trong lúc chờ RPC — hiện
      // "Đang tải…" ngay, và RPC lỗi thì báo rõ lỗi tải (trước đây
      // RPC lỗi im lặng nên trang giữ nguyên dòng "Cần đăng nhập" dù
      // user đã đăng nhập, đúng mẫu Zalo gặp 03:47 ngày 12/11).
      if (balEl) balEl.textContent = 'Đang tải số dư xu…';
      if (histEl) histEl.innerHTML = '<p>Đang tải lịch sử chuyển xu…</p>';
      if (typeof R.getMyPointsBalanceResult === 'function') {
        R.getMyPointsBalanceResult().then(function (r){
          if (balEl && r && r.ok) balEl.textContent = 'Số dư xu của bạn: ' + (Number(r.balance) || 0) + ' xu.';
          else if (balEl) balEl.textContent = 'Chưa tải được số dư xu, hãy tải lại trang.';
        }).catch(function () { if (balEl) balEl.textContent = 'Chưa tải được số dư xu, hãy tải lại trang.'; });
      }
      var jobs = [];
      if (typeof R.getMyTransferStreak === 'function') {
        jobs.push(R.getMyTransferStreak().then(function (st){ streak = st; if (streakEl) streakEl.textContent = streakText(st); if (submitBtn && st && !st.eligible) submitBtn.disabled = true; }).catch(function () { if (streakEl) streakEl.textContent = 'Chưa tải được chuỗi online, hãy tải lại trang.'; }));
      }
      if (typeof R.getMyTransferHistory === 'function') {
        jobs.push(R.getMyTransferHistory(20).then(function (h){
          if (histEl && h && h.ok) histEl.innerHTML = histHTML(h.items);
          else if (histEl) histEl.innerHTML = '<p>Chưa tải được lịch sử chuyển xu, hãy tải lại trang.</p>';
        }).catch(function () { if (histEl) histEl.innerHTML = '<p>Chưa tải được lịch sử chuyển xu, hãy tải lại trang.</p>'; }));
      }
      if (typeof R.getMyPointsBalanceResult === 'function') {
        jobs.push(R.getMyPointsBalanceResult().then(function (r){ if (r && r.ok) balance = Number(r.balance) || 0; }));
      }
      Promise.all(jobs).catch(function () {});
      if (submitWired) return;
      submitWired = true;
      form.addEventListener('submit', function (e){
        e.preventDefault();
        say('');
        var err = (typeof R.validateTransfer === 'function') ? R.validateTransfer({
          recipientEmail: emailEl ? emailEl.value : '',
          amount: amountEl ? Number(amountEl.value) : 0,
          balance: balance, myEmail: (currentUser && currentUser.email) || ''
        }) : null;
        if (err) { say(err); return; }
        if (streak && !streak.eligible) { say('Chưa đủ 30 ngày online liên tiếp nên chưa chuyển được xu (còn ' + streak.days_remaining + ' ngày nữa).'); return; }
        if (submitBtn) submitBtn.disabled = true;
        R.transferPoints(emailEl.value, Number(amountEl.value), noteEl ? noteEl.value : '').then(function (res){
          if (submitBtn) submitBtn.disabled = !(streak && streak.eligible);
          if (res && res.ok) {
            say('Đã chuyển ' + Number(amountEl.value) + ' xu cho ' + emailEl.value.trim() + '.');
            if (typeof R.getMyTransferHistory === 'function') R.getMyTransferHistory(20).then(function (h){ if (histEl && h && h.ok) histEl.innerHTML = histHTML(h.items); });
            if (typeof R.getMyPointsBalanceResult === 'function') R.getMyPointsBalanceResult().then(function (r){ if (balEl && r && r.ok) { balance = Number(r.balance) || 0; balEl.textContent = 'Số dư xu của bạn: ' + balance + ' xu.'; } });
            form.reset();
          } else if (res && res.code === 'not_eligible') {
            say('Chưa đủ 30 ngày online liên tiếp (đã ' + (res.current_streak || 0) + '/30 ngày — còn ' + (res.days_remaining || 0) + ' ngày nữa).');
          } else if (res && res.code === 'recipient_not_found') {
            say('Không tìm thấy tài khoản có email này.');
          } else if (res && res.code === 'cannot_transfer_to_self') {
            say('Không chuyển xu cho chính mình.');
          } else if (res && res.code === 'amount_below_minimum') {
            say('Chuyển xu tối thiểu 10 xu/lần.');
          } else if (res && res.code === 'insufficient_balance') {
            say('Số dư xu của bạn không đủ để chuyển.');
          } else if (res && res.code === 'rpc_missing') {
            say('Hệ thống chuyển xu chưa bật (đang chờ migration M7).');
          } else {
            say('Chưa chuyển được xu: ' + ((res && (res.message || res.error)) || 'hệ thống xu chưa bật.'));
          }
        });
      });
    });
  });
  }
  refreshTransfer();
  try {
    var A = window.V2SAuthUI;
    if (A && typeof A.onSessionChange === 'function') A.onSessionChange(function () { refreshTransfer(); });
  } catch (e) { /* bỏ qua — vẫn tải 1 lần lúc mở trang */ }
}
/* v176: dropdown "Tin tức" trên nav — 10 CHUYÊN MỤC + số bài + "Xem tất cả tin →".
   Thay dropdown 8 bài mới nhất (v175) theo yêu cầu của anh Thọ 12/11:
   overlay chuyên mục giống cách danh sách bộ lọc chuyên mục làm
   (tên + số bài, vd "Việc Làm (16)"), hoàn thiện đẹp hơn.
   Markup nav trong HTML KHÔNG đổi (7 mục, byte-identical toàn site — quy tắc 9);
   JS tự chèn dropdown vào mục "Tin tức" lúc chạy, render từ data.js.
   Tên 10 chuyên mục ghi cứng theo thứ tự cố định; SỐ BÀI tính lúc chạy
   từ D.articles (như applyOptionCounts), không ghi cứng số đếm.
   Mỗi dòng link tới tin-tuc.html?cat=<tên đã mã hoá URL>; initNews (v111)
   đã đọc ?cat= để chọn sẵn bộ lọc. Trang đã có V20_DATA thì dựng ngay;
   trang chưa có (đa số bai-viet/*, hoi-dap, dang-ky...) thì chỉ tải data.js
   khi người dùng chạm vào mục Tin tức (hover/focus/click) để lần tải trang
   đầu không nặng thêm. Desktop: hover/focus mở. Mobile/cảm ứng: chạm lần 1
   mở, chạm lần 2 đi tới trang lọc; bấm ngoài hoặc Esc để đóng. */
var NEWS_DROPDOWN_CATS = ['Việc Làm', 'Livestream', 'Phân tích', 'Thị trường', 'Công nghệ', 'Dòng tiền', 'Xu hướng', 'Hàng hoá', 'Đang hot', 'Đời Sống'];
var _newsDropdownReady = false; /* khung DOM đã chèn xong */
var _newsDropdownFilled = false; /* đã đổ đủ 10 chuyên mục vào panel */
var _newsDataLoading = false; /* đang tải data.js (chỉ 1 lần) */
function newsDropdownCounts(articles){
  var counts = {};
  NEWS_DROPDOWN_CATS.forEach(function(c){ counts[c] = 0; });
  (articles || []).forEach(function(a){
    if (a && a.cat && counts.hasOwnProperty(a.cat)) counts[a.cat]++;
  });
  return counts;
}
function newsDropdownRoot(newsLink){
  var h = newsLink ? (newsLink.getAttribute('href') || '') : '';
  return h.replace(/tin-tuc\.html$/, ''); /* '' ở trang gốc, '../' ở bai-viet/* — đúng cả khi deploy ở subpath */
}
function newsDropdownHTML(counts, root){
  var items = NEWS_DROPDOWN_CATS.map(function(c){
    var href = root + 'tin-tuc.html?cat=' + encodeURIComponent(c);
    return '<a class="nav-news-item nav-news-cat" href="' + esc(href) + '">'
      + '<span class="nav-news-cat-name">' + esc(c) + '</span>'
      + '<span class="nav-news-cat-count">' + (counts[c] || 0) + '</span></a>';
  }).join('');
  return '<div class="nav-news-head">Chuyên mục tin tức</div>' + items
    + '<a class="nav-news-item nav-news-all" href="' + esc(root + 'tin-tuc.html') + '">Xem tất cả tin →</a>';
}
function initNewsDropdown(){
  if (typeof document === 'undefined') return;
  var nav = document.getElementById('mainNav');
  if (!nav) return;
  var link = null, i, as = nav.getElementsByTagName('a');
  for (i = 0; i < as.length; i++){
    if (/tin-tuc\.html$/.test(as[i].getAttribute('href') || '')){ link = as[i]; break; }
  }
  if (!link) return;
  /* v176: idempotent — nếu nav đã được gắn dropdown (gọi 2 lần / tải lại)
     thì không chèn thêm. */
  if (link.getAttribute('aria-haspopup') === 'true') return;
  var root = newsDropdownRoot(link);
  var wrap = document.createElement('div');
  wrap.className = 'nav-news-wrap';
  link.parentNode.insertBefore(wrap, link);
  wrap.appendChild(link);
  var caret = document.createElement('span');
  caret.className = 'nav-news-caret';
  caret.setAttribute('aria-hidden', 'true');
  caret.textContent = '▾';
  link.appendChild(caret);
  link.setAttribute('aria-haspopup', 'true');
  link.setAttribute('aria-expanded', 'false');
  var panel = document.createElement('div');
  panel.className = 'nav-news-dropdown';
  panel.innerHTML = '<span class="nav-news-loading">Đang tải chuyên mục…</span>';
  wrap.appendChild(panel);
  _newsDropdownReady = true;
  function fill(){
    if (_newsDropdownFilled) return;
    var arts = (window.V20_DATA && window.V20_DATA.articles) || D.articles || [];
    panel.innerHTML = newsDropdownHTML(newsDropdownCounts(arts), root);
    _newsDropdownFilled = true;
  }
  function hasData(){
    return !!(window.V20_DATA && window.V20_DATA.articles && window.V20_DATA.articles.length);
  }
  function ensureData(){
    if (_newsDropdownFilled) return;
    if (hasData()){ fill(); return; }
    if (_newsDataLoading) return;
    _newsDataLoading = true;
    var s = document.createElement('script');
    s.src = root + 'js/data.js';
    s.onload = function(){ fill(); };
    s.onerror = function(){ panel.innerHTML = '<span class="nav-news-loading">Chưa tải được chuyên mục.</span>'; };
    document.head.appendChild(s);
  }
  function closeDropdown(){
    wrap.classList.remove('open');
    link.setAttribute('aria-expanded', 'false');
  }
  function openDropdown(){
    wrap.classList.add('open');
    link.setAttribute('aria-expanded', 'true');
  }
  if (hasData()){ fill(); }
  else {
    /* Chưa có dữ liệu: chỉ tải khi người dùng chạm vào mục Tin tức. */
    wrap.addEventListener('mouseenter', ensureData);
    wrap.addEventListener('focusin', ensureData);
    link.addEventListener('click', ensureData);
  }
  /* Chạm (mobile / màn cảm ứng / menu mobile đang mở): lần 1 mở dropdown,
     lần 2 mới đi tới tin-tuc.html. Desktop chuột: hover đã mở, click đi thẳng. */
  link.addEventListener('click', function(e){
    var touch = false;
    try { touch = !!(window.matchMedia && window.matchMedia('(hover: none)').matches); } catch (err) {}
    var mobileOpen = nav.classList.contains('open');
    if ((touch || mobileOpen) && !wrap.classList.contains('open')){
      e.preventDefault();
      ensureData();
      openDropdown();
    }
  });
  document.addEventListener('click', function(e){
    if (wrap.classList.contains('open') && !wrap.contains(e.target)) closeDropdown();
  });
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape' && wrap.classList.contains('open')){
      closeDropdown();
      try { link.focus(); } catch (err) {}
    }
  });
  var mb = document.getElementById('menuBtn');
  if (mb) mb.addEventListener('click', function(){
    /* Listener này đăng ký TRƯỚC handler toggle của menuBtn nên chạy
       trước khi nav đổi class: nav đang mở = sắp đóng -> dọn dropdown. */
    if (nav.classList.contains('open')) closeDropdown();
  });
}
/* v176: bọc từng init trong try/catch — 1 init ném lỗi không được chặn
   các init sau (nghi ngờ gây lỗi tải lạnh v175: dropdown nằm cuối chuỗi
   init nên 1 lỗi trước đó làm nó không chạy, hover lần đầu không mở). */
function safeInit(fn){
  try { fn(); } catch (e) { try { console.error('[init]', e && e.stack ? e.stack : e); } catch (_) {} }
}
if(typeof document!=='undefined') document.addEventListener('DOMContentLoaded',function(){
  /* v176: 4 init dau cung boc safeInit — truoc day goi tran, 1 loi o day
     (vd initMobileNotice) lam CHET CA CHUOI, ke ca initNewsDropdown o cuoi. */
  safeInit(initMobileNotice); safeInit(initHeaderAuth); safeInit(initActivationStrip); safeInit(showPendingToast); /* v117: toast cho tu trang truoc (sau dang ky) */
  /* v96-swap: initShopPage TRUOC initList — renderLotSections dung lai
     option cua #fUniProv theo D.provinces (v111); prefill URL cua initList
     phai chay sau thi gia tri moi giu duoc. */
  safeInit(initHome); safeInit(initShopPage); safeInit(initNewObjSections); /* v179: render + loc 5 danh muc moi (sau initShopPage vi renderLotSections chay trong do) */ safeInit(initList); safeInit(initNews); safeInit(initModelNewsRow); /* v100: hang tin trang Mau */ safeInit(initShopNewsRow); /* v123: hang tin trang Shop */ safeInit(initKiotNewsRow); /* v123: hang tin trang Kiot */ safeInit(function(){ initBottomNewsList('shopBottomNews',['Đời Sống','Việc Làm']); }); safeInit(function(){ initBottomNewsList('kiotBottomNews',['Đang hot','Livestream']); }); /* v157: 3 hang tin duoi danh sach */ safeInit(initDetail); safeInit(initShopDetail); safeInit(initShops); safeInit(initHub); safeInit(initFaqToggle); safeInit(initArticleComments); /* v166 (N10): form binh luan trang bai chi tiet */ safeInit(initPointsUI); safeInit(initTransferForm); safeInit(initStars); /* v99: nap so sao + uy thac click nut sao */ safeInit(initLotFactoryDetail); /* v135: khung chi tiet lo/xuong/kiot tren trang (modal) */ safeInit(initOptionCounts); /* v103: so luong that trong () o moi option loc */ safeInit(initFilterHint); /* v118 (P2-4): an goi y "Can dang nhap" khi da dang nhap */ safeInit(initNewsDropdown); /* v176: dropdown Tin tức (10 chuyên mục) */ safeInit(scrollToHashedCard); /* v197 (MỚI-MC-10): cuộn tới thẻ hash sau khi các lưới render xong (lô/xưởng/kiot) */
  var mb=document.getElementById('menuBtn');
  if(mb) mb.addEventListener('click',function(){var n=document.getElementById('mainNav'); var o=n.classList.toggle('open'); mb.setAttribute('aria-expanded',o?'true':'false');});
  var fab=document.getElementById('gopyFab');
  if(fab){ /* GOPY-1311: nut hien san trong markup (khong con hidden) — chi gan mo form; v161 (Rion S1-3) tung phai go hidden bang JS vi khong JS nao go, nay markup da bo hidden nen khong phu thuoc JS nua */ fab.addEventListener('click',function(){document.getElementById('gopyOverlay').classList.add('open');}); }
  var ov=document.getElementById('gopyOverlay');
  if(ov) ov.addEventListener('click',function(e){if(e.target===ov) ov.classList.remove('open');});
  var gf=document.getElementById('gopyForm');
  if(gf) gf.addEventListener('submit',function(e){e.preventDefault(); var msg=document.getElementById('gopyMsg');
    var run=async function(){
    var data={name:gf.gopyName.value.trim(), kind:gf.gopyKind.value, rating:null, content:gf.gopyContent.value.trim(), page:location.pathname};
    if(!data.content){ if(msg) msg.textContent='Bạn nhập nội dung góp ý trước nhé.'; return; }
    try{
      var API=window.McLivestreamAPI;
      if(API && API.submitFeedback){ await API.submitFeedback(data); if(msg) msg.textContent='Cảm ơn bạn! Góp ý đã gửi về Ver2Solution để tổng hợp.'; gf.reset(); return; }
    }catch(err){ var fe=((window.McLivestreamAPI&&McLivestreamAPI.friendlyError)?McLivestreamAPI.friendlyError(err):'Đã có lỗi xảy ra, hãy thử lại sau.'); fe=String(fe||'').replace(/[.]+$/,''); /* v161 (Rion S3-2): friendlyError tra ve cau ket thuc bang '.' roi code cong them '.' -> '..' */ /* v166: cau cu "Góp ý đã lưu tạm" la NOI SAI — submitFeedback loi (RLS chan) thi khong co gi duoc luu; chi huong user gui qua Zalo. */ if(msg) msg.textContent='Chưa gửi được: '+fe+'. Bạn gửi thêm qua Zalo giúp mình nhé.'; }
    if(msg && !msg.textContent) msg.textContent='Cảm ơn bạn! Bạn gửi thêm qua Zalo giúp mình nhé để Ver2Solution tổng hợp ngay.'; gf.reset();};
    if(window.V2SAuthUI) V2SAuthUI.guardSubmit(gf, run); else run();});
});
/* v176: lưới an toàn cho dropdown — nếu chuỗi DOMContentLoaded vì lý do
   nào đó không gắn được dropdown, thử lại khi trang tải xong.
   initNewsDropdown idempotent nên gọi 2 lần không chèn trùng. */
if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') window.addEventListener('load', function(){ safeInit(initNewsDropdown); });
window.V20 = {esc:esc, cardHTML:cardHTML, photoNote:photoNote, decisionHTML:decisionHTML, hasRealValue:hasReal, verifiedRevenue:verifiedRevenue, revenueText:revenueText, headerDisplayName:headerDisplayName, headerMetaName:headerMetaName, initMobileNotice:initMobileNotice, initHeaderAuth:initHeaderAuth, initActivationStrip:initActivationStrip, MOBILE_NOTICE_LINES:MOBILE_NOTICE_LINES, MOBILE_NOTICE_KEY:MOBILE_NOTICE_KEY, miniHTML:miniHTML, filterModels:filterModels, filterShops:filterShops, shopCatGroup:shopCatGroup, withPhotoFirst:withPhotoFirst, clean:clean, shopCardHTML:shopCardHTML, shopDecisionHTML:shopDecisionHTML, shopLogoHTML:shopLogoHTML, contactsBlockHTML:contactsBlockHTML, contactNoteHTML:contactNoteHTML, contactItemHTML:contactItemHTML, sortShopsNewest:sortShopsNewest, articleLink:articleLink, articleHref:articleHref, sortByDateDesc:sortByDateDesc, sortByDMYDesc:sortByDMYDesc, renderHomeSection:renderHomeSection, articleTarget:articleTarget, articleTitleHTML:articleTitleHTML, articleMediaHTML:articleMediaHTML, imgFallback:imgFallback, getPinnedRow:getPinnedRow, pinCardHTML:pinCardHTML, newsCardHTML:newsCardHTML, formatArticleDate:formatArticleDate, initModelNewsRow:initModelNewsRow, initShopNewsRow:initShopNewsRow, initKiotNewsRow:initKiotNewsRow, pickMostViewedArticle:pickMostViewedArticle, newsRowNewest:newsRowNewest, newsRowFinalList:newsRowFinalList, newsDropdownCounts:newsDropdownCounts, newsDropdownHTML:newsDropdownHTML, newsDropdownRoot:newsDropdownRoot, initNewsDropdown:initNewsDropdown, NEWS_DROPDOWN_CATS:NEWS_DROPDOWN_CATS, dayOfYear:dayOfYear, rotateDaily:rotateDaily, rotateWindow:rotateWindow, window6h:window6h, photoTier:photoTier, homeModels12:homeModels12, countLabel:countLabel, applyOptionCounts:applyOptionCounts, initOptionCounts:initOptionCounts, refreshUniCounts:refreshUniCounts, uniProvCount:uniProvCount, uniCatCount:uniCatCount, uniTotal:uniTotal, defaultShopOrder:defaultShopOrder, logoTier:logoTier, rotateStaticGrids:rotateStaticGrids, lotMatches:lotMatches, facMatches:facMatches, inRange:inRange, initLotFilter:initLotFilter, initFactoryFilter:initFactoryFilter, initSectionFilter:initSectionFilter, initLotPageFilter:initLotPageFilter, initFactoryPageFilter:initFactoryPageFilter, lotSortComparator:lotSortComparator, facSortComparator:facSortComparator, findLotFactoryKiot:findLotFactoryKiot, findDetailItem:findDetailItem, lotFactoryKiotDetailHTML:lotFactoryKiotDetailHTML, openLotFactoryKiotDetail:openLotFactoryKiotDetail, closeLotFactoryKiotDetail:closeLotFactoryKiotDetail, initLotFactoryDetail:initLotFactoryDetail, initFilterToggle:initFilterToggle, filterSectionOf:filterSectionOf, closeFilters:closeFilters, closeFilterOf:closeFilterOf, initShopDetail:initShopDetail, initDetail:initDetail, trustStats:trustStats, renderTrustStats:renderTrustStats, parseMonthlyMax:parseMonthlyMax, parseRevenue:parseRevenue, fmtVnd:fmtVnd, parseHourlyMin:parseHourlyMin, sortModelsBy:sortModelsBy, sortShopsBy:sortShopsBy, parseMoneyInput:parseMoneyInput, ownerNoteHTML:ownerNoteHTML, defaultModelOrder:defaultModelOrder, hubZaloHref:hubZaloHref, hubCardHTML:hubCardHTML, hubResults:hubResults, hubAllLink:hubAllLink, hubEmptyHTML:hubEmptyHTML, demoUrlOf:demoUrlOf, initHub:initHub, initFaqToggle:initFaqToggle, parseVnDate:parseVnDate, lotActive:lotActive, lotsByGroup:lotsByGroup, lotFactoryStats:lotFactoryStats, lotFactoryPhotoHTML:lotFactoryPhotoHTML, lotCardHTML:lotCardHTML, factoryCardHTML:factoryCardHTML, renderLotSections:renderLotSections, userListingToLot:userListingToLot, userListingToFactory:userListingToFactory, userListingToKiot:userListingToKiot, registerUserListing:registerUserListing, loadUserListings:loadUserListings, toggleUserListingPanel:toggleUserListingPanel, closeUserListingPanel:closeUserListingPanel, userListingPanelHTML:userListingPanelHTML, userListingBadgeHTML:userListingBadgeHTML, userListingShopLineHTML:userListingShopLineHTML, pointsButtonsHTML:pointsButtonsHTML, articleRef:articleRef, fetchActivePins:fetchActivePins, applyPinnedOrder:applyPinnedOrder, mountPointsDetail:mountPointsDetail, initPointsUI:initPointsUI, gatedContactsHTML:gatedContactsHTML, gateFilterApply:gateFilterApply, initFilterHint:initFilterHint, filterMsgEl:filterMsgEl, selectHasValue:selectHasValue, setSelectOptions:setSelectOptions, modelCatOptions:modelCatOptions, shopGroupOptions:shopGroupOptions, rebuildUniCatOptions:rebuildUniCatOptions, rebuildShopCatOptions:rebuildShopCatOptions, UNI_CAT_DEFS:UNI_CAT_DEFS, UNI_LOCKABLE:UNI_LOCKABLE, UNI_LOCKABLE_ALL:UNI_LOCKABLE_ALL, initTransferForm:initTransferForm, emptyResultsHTML:emptyResultsHTML, pinUntilText:pinUntilText, initArticleComments:initArticleComments, markLiked:markLiked, LIKE_STORE_KEY:LIKE_STORE_KEY, likedToday:likedToday, markLikedToday:markLikedToday, markShared:markShared, SHARE_STORE_KEY:SHARE_STORE_KEY, sharedToday:sharedToday, markSharedToday:markSharedToday, commentToggleHTML:commentToggleHTML, uniCatToShop:uniCatToShop, uniCatToModel:uniCatToModel, uniCatToLotFac:uniCatToLotFac, shopCatToUni:shopCatToUni, uniProvToFactory:uniProvToFactory, getUniCat:getUniCat, setUniCatFieldStates:setUniCatFieldStates, syncHubFromUni:syncHubFromUni, setParams:setParams, initUniCatSwitch:initUniCatSwitch, initShopPage:initShopPage, uniSortToModelSort:uniSortToModelSort, MODEL_CAT_TO_UNI:MODEL_CAT_TO_UNI, newObjCardHTML:newObjCardHTML, newObjPriceText:newObjPriceText, renderNewObjSections:renderNewObjSections, initNewObjSections:initNewObjSections, initNewObjSection:initNewObjSection, newObjMatches:newObjMatches, NEWOBJ_TYPES:NEWOBJ_TYPES, NEWOBJ_ARRAYS:NEWOBJ_ARRAYS, NEWOBJ_SECTIONS:NEWOBJ_SECTIONS, NEWOBJ_LOGISTICS_OPTIONS:NEWOBJ_LOGISTICS_OPTIONS, NEWOBJ_UNI_CATS:NEWOBJ_UNI_CATS, newObjUniCatCfg:newObjUniCatCfg, newObjCount:newObjCount, newObjProvCount:newObjProvCount, refreshNewObjCatCounts:refreshNewObjCatCounts, showOnlyNewObjSection:showOnlyNewObjSection, showAllNewObjSections:showAllNewObjSections, refreshClassMoreBtn:refreshClassMoreBtn, refreshShopProvCounts:refreshShopProvCounts, refreshShopLogOptCounts:refreshShopLogOptCounts, rebuildProvOptions:rebuildProvOptions, provEntriesForCat:provEntriesForCat, kiotPriceRange:KIOT_PRICE_RANGE, setKiotPriceRange:setKiotPriceRange, payLevels:payLevels, fillPayDatalist:fillPayDatalist, NEWOBJ_NO_COUNT:NEWOBJ_NO_COUNT, dedupeProfiles:dedupeProfiles, profileKey:profileKey, sortNewObjByDateDesc:sortNewObjByDateDesc, renderHomeNewObj:renderHomeNewObj, HOME_NEWOBJ_SECTIONS:HOME_NEWOBJ_SECTIONS, pageOfId:pageOfId, scrollToHashedCard:scrollToHashedCard,
/* v99 (the rut gon + sao len top) */
catLabel:catLabel, sourceDetailLink:sourceDetailLink, findProvinceInText:findProvinceInText, normProv:normProv, normProvKiot:normProvKiot, lotProvOf:lotProvOf, MERGED_PROV:MERGED_PROV, modelFields:modelFields, modelFieldLine:modelFieldLine, modelLocationLine:modelLocationLine, shopLocationLine:shopLocationLine, shopSalaryLine:shopSalaryLine, lotLocationLine:lotLocationLine, lotValueLine:lotValueLine, factoryLocationLine:factoryLocationLine, factoryItemsLine:factoryItemsLine, kiotLocationLine:kiotLocationLine, kiotTypeLine:kiotTypeLine, CAT_LABELS:CAT_LABELS, STAR_STORE_KEY:STAR_STORE_KEY, STAR_WINDOW_MS:STAR_WINDOW_MS, STAR_LIMIT_MS:STAR_LIMIT_MS, starPlace:starPlace, starStoreRead:starStoreRead, starStoreWrite:starStoreWrite, starKey:starKey, starTodayStr:starTodayStr, starredWithin12h:starredWithin12h, markStarred:markStarred, starredToday:starredToday, markStarredToday:markStarredToday, starCountOf:starCountOf, starButtonHTML:starButtonHTML, starTierOf:starTierOf, applyStarOrder:applyStarOrder, refreshStarCounts:refreshStarCounts, fetchStarStats:fetchStarStats, starClick:starClick, starToast:starToast, v2sSignupPopup:v2sSignupPopup, v2sToast:v2sToast, showPendingToast:showPendingToast, initStars:initStars, DISCLAIMER:DISCLAIMER, PIN_LONGER_HTML:PIN_LONGER_HTML};
if(typeof module!=='undefined' && module.exports) module.exports = window.V20;
})();

