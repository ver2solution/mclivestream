// Test tĩnh gói v274 — khối "Lịch sale" trang chủ (thiết kế design-2026-11-15-lich-sale-trang-chu.md).
// Chạy: node tools/test-v274-lich-sale.mjs   (từ thư mục gốc của gói)
// Không cần server, không chạm live (trừ các URL đã kiểm chứng bằng curl trước khi code).
import { readFileSync, existsSync } from 'node:fs';
import vm from 'node:vm';

const ROOT = new URL('..', import.meta.url).pathname;
const html = readFileSync(ROOT + 'index.html', 'utf8');
let pass = 0, fail = 0;
function check(name, ok, extra = '') {
  if (ok) { pass++; console.log('PASS  ' + name); }
  else { fail++; console.log('FAIL  ' + name + (extra ? ' — ' + extra : '')); }
}

// 1. Đủ 6 hàng mốc, đúng ngày + nhãn + data-track
const rows = [...html.matchAll(/<a class="sale-row"[\s\S]*?<\/a>/g)];
check('du 6 hang moc', rows.length === 6, 'co ' + rows.length);
const SALE = 'bai-viet/lich-sale-cuoi-nam-2026-11-11-12-12-giang-sinh-tet-2027.html';
const expect = [
  ['2026-11-15', 'HÔM NAY 15/11', 'lich-sale-moc-15-11', '#nam-moc'],
  [null, '15–30/11', 'lich-sale-moc-phong-vu', '#nam-moc'],
  ['2026-11-25', '25/11', 'lich-sale-moc-25-11', '#nam-moc'],
  ['2026-11-27', '27/11', 'lich-sale-moc-27-11', '#black-friday'],
  ['2026-11-30', '30/11', 'lich-sale-moc-30-11', '#nam-moc'],
  ['2026-12-12', '12/12', 'lich-sale-moc-12-12', '#1212'],
];
expect.forEach(([date, label, track, anchor], i) => {
  const r = rows[i] ? rows[i][0] : '';
  check('hang ' + (i + 1) + ' nhan "' + label + '"', r.includes('>' + label + '<'));
  check('hang ' + (i + 1) + ' track ' + track, r.includes('data-track="' + track + '"'));
  check('hang ' + (i + 1) + ' href ' + SALE + anchor, r.includes('href="' + SALE + anchor + '"'));
  if (date) check('hang ' + (i + 1) + ' data-date ' + date, r.includes('data-date="' + date + '"'));
});
check('hang Phong Vu co data-date-start/end', rows[1][0].includes('data-date-start="2026-11-15"') && rows[1][0].includes('data-date-end="2026-11-30"'));

// 2. Mọi href tồn tại trong repo + anchor tồn tại trong bài đích
check('file bai lich sale ton tai trong repo', existsSync(ROOT + SALE));
const article = readFileSync(ROOT + SALE, 'utf8');
['nam-moc', 'black-friday', '1212'].forEach(a =>
  check('anchor #' + a + ' ton tai trong bai', article.includes('id="' + a + '"')));
check('"Xem lich day du" tro bai lich sale', html.includes('data-track="lich-sale-xem-lich"') && html.includes('href="' + SALE + '#nam-moc" data-track="lich-sale-xem-lich">Xem lịch đầy đủ'));

// 3. Nút 11.11 đã gỡ khỏi trang chủ, trang tinh-lai-1111.html vẫn còn
const loTrinh = html.split('<section class="section" id="lo-trinh">')[1].split('</section>')[0];
check('nut 11.11 khong con trong #lo-trinh', !loTrinh.includes('tinh-lai-1111.html'));
check('nut "Xem tat ca tin" van con', loTrinh.includes('href="tin-tuc.html">Xem tất cả tin →'));
check('trang tinh-lai-1111.html van ton tai (khong xoa trang)', existsSync(ROOT + 'tinh-lai-1111.html'));

// 4. Số voucher khớp nguồn nghiên cứu 15/11 §1.1, mốc chưa công bố không hiện số giảm
const row1 = html.split('lich-sale-moc-15-11')[1].split('</a>')[0];
check('Shopee 50% toi da 500K', row1.includes('50% tối đa 500K'));
check('Lazada TMall 30–50% toi da 1,5 trieu', row1.includes('30–50% tối đa 1,5 triệu'));
check('TikTok Shop 25–35%', row1.includes('25–35%'));
check('Shopee ma 0h', row1.includes('mã 0h'));
['25/11', '27/11', '30/11', '12/12'].forEach((d, i) => {
  const seg = html.split('lich-sale-moc-' + ['25-11', '27-11', '30-11', '12-12'][i])[1].split('</a>')[0];
  check('moc ' + d + ' khong hien so giam (%)', !seg.includes('%'));
});
check('dong chu thich nguon co mat', html.includes('Số liệu theo công bố của sàn'));

// 5. CẤM tự cuộn: khối mới không dùng scrollIntoView / smooth-scroll
const block = html.split('<div class="sale-calendar"')[1].split('</section>')[0];
check('khoi moi khong co scrollIntoView', !block.includes('scrollIntoView'));
check('khoi moi khong co smooth-scroll', !/scroll-behavior\s*:\s*smooth/.test(block));

// 6. Không thêm section/H2/menu; menu vẫn 7 mục
const nav = html.split('<nav class="main-nav"')[1].split('</nav>')[0];
check('menu van 7 muc', (nav.match(/<a /g) || []).length === 7, 'co ' + (nav.match(/<a /g) || []).length);
check('khoi dung h3 (khong them h2)', loTrinh.includes('<h3>🗓️ Lịch sale') && (loTrinh.match(/<h2/g) || []).length === 1);
check('khong them <section (HEAD co 20, nay van 20)', (html.match(/<section/g) || []).length === 20);

// 7. Class CSS dùng trong HTML đều được định nghĩa trong <style> inline
const style = html.split('<style>')[1].split('</style>')[0];
['sale-calendar', 'sale-cal-head', 'sale-rows', 'sale-row', 'sale-date', 'sale-body', 'sale-arrow', 'sale-note', 'today', 'next', 'past']
  .forEach(c => check('CSS .' + c + ' co dinh nghia', style.includes('.' + c)));
check('CSS co 2 cot tu 768px', style.includes('@media(min-width:768px){.sale-rows{grid-template-columns:1fr 1fr}}'));
check('CSS co xe doc <360px', style.includes('@media(max-width:359px)'));

// 8. Logic JS inline: chạy thật với từng ngày (stub document tối thiểu)
const js = html.split('/* v274-lich-sale (15/11/2026): danh dau moc')[1].split('</script>')[0];
// Lấy nguyên đoạn script (từ "/* v274" tới trước </script>)
const scriptText = '/* v274-lich-sale (15/11/2026): danh dau moc' + js;
function runJsFor(dateISO) {
  const state = expect.map(([date, label], i) => ({
    ref: date || '2026-11-15', // hàng Phong Vũ: ref = data-date-start
    start: i === 1 ? '2026-11-15' : date,
    classes: new Set(),
  }));
  // Hàng Phong Vũ không có data-date mà có data-date-start — stub trả đúng theo code thật
  const fakeRows = state.map((s, i) => ({
    getAttribute: (k) => (k === 'data-date' ? (i === 1 ? null : s.ref) : (k === 'data-date-start' ? (i === 1 ? '2026-11-15' : null) : null)),
    classList: { add: (c) => s.classes.add(c) },
  }));
  const sandbox = {
    document: {
      querySelectorAll: () => fakeRows,
      querySelector: (sel) => (sel === '#saleCalendar .sale-row.today' ? (state.some(s => s.classes.has('today')) ? {} : null) : null),
    },
    Intl,
    Date: class extends Date { constructor(...a) { super(...(a.length ? a : [dateISO + 'T08:00:00+07:00'])); } },
    console,
  };
  vm.createContext(sandbox);
  vm.runInContext(scriptText, sandbox);
  return state.map(s => [...s.classes].sort().join(',') || '-');
}
const t1511 = runJsFor('2026-11-15');
check('15/11: hang 15/11 + Phong Vu today, cac hang khac binh thuong',
  t1511[0] === 'today' && t1511[1] === 'today' && t1511.slice(2).every(c => c === '-'), JSON.stringify(t1511));
const t1611 = runJsFor('2026-11-16');
check('16/11: khong today, 25/11 la next', t1611[2] === 'next' && !t1611.some(c => c === 'today'), JSON.stringify(t1611));
const t2811 = runJsFor('2026-11-28');
check('28/11 (§5.5): 15/11, 25/11, 27/11 past; 30/11 next',
  t2811[0] === 'past' && t2811[2] === 'past' && t2811[3] === 'past' && t2811[4] === 'next', JSON.stringify(t2811));
const t1212 = runJsFor('2026-12-12');
check('12/12: hang 12.12 today', t1212[5] === 'today', JSON.stringify(t1212));
const t1213 = runJsFor('2026-12-13');
check('13/12: tat ca past, khong hang nao bien mat', t1213.every(c => c === 'past'), JSON.stringify(t1213));
check('JS dung gio Asia/Ho_Chi_Minh (khong UTC)', scriptText.includes("timeZone:'Asia/Ho_Chi_Minh'"));

// Tổng kết
console.log('\n' + pass + ' PASS, ' + fail + ' FAIL');
process.exit(fail ? 1 : 0);
