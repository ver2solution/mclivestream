# NOTES v274 — Khối "Lịch sale" trên trang chủ (15/11/2026)

- **Nhiệm vụ:** thiết kế `design-2026-11-15-lich-sale-trang-chu.md` (agent-design 13:21 ngày 15/11 — cải tiến giao diện thường lệ, chuyển thẳng cho developer, không chờ anh Thọ duyệt).
- **Gói deploy riêng (CHƯA DEPLOY — chỉ bản local):** 1 file `index.html` (+33/−1 dòng so với live HEAD `4d5cb8d` v273). Không đụng `js/data.js`, `js/app.js`, `js/search.js`, `sw.js`, không bump CACHE, không đổi schema/DB.
- **Thay đổi:**
  1. Xóa nút "🧮 Tính lãi sau phí sàn 11.11 →" khỏi `.section-foot` của `#lo-trinh` (trang `tinh-lai-1111.html` vẫn còn nguyên, mở trực tiếp được).
  2. Chèn khối `.sale-calendar` giữa `#homeNews` và `.section-foot`: tiêu đề `<h3>`, link "Xem lịch đầy đủ →", 6 hàng mốc (15/11 sale giữa tháng · 15–30/11 Phong Vũ · 25/11 sale lương · 27/11 Black Friday · 30/11 Cyber Monday · 12/12 sale 12.12), dòng chú thích nguồn.
  3. CSS khối mới trong `<style>` inline sẵn có của `index.html` (theo tiền lệ v116-game-entry — không sửa `v20.css` nên không lo cache CSS cũ): 1 cột mobile, 2 cột từ 768px, xếp dọc <360px; `.today` nổi bật, `.past` mờ 55%, `.next` là mốc đơn gần nhất sắp tới.
  4. JS inline ~10 dòng ngay sau khối: đánh dấu `today`/`past`/`next` theo giờ Việt Nam (`Asia/Ho_Chi_Minh`, không dùng UTC). Không dùng `scrollIntoView` ở bất cứ đâu trong khối.
- **Test tĩnh: `tools/test-v274-lich-sale.mjs` — 66/66 PASS** (chạy `node tools/test-v274-lich-sale.mjs`): đủ 6 mốc + track + href; mọi href trỏ file có thật trong repo + anchor có thật trong bài; số voucher khớp nghiên cứu 15/11 §1.1; mốc chưa công bố không hiện %; menu vẫn 7 mục; không thêm section/H2; HTML parse 0 lỗi/0 thẻ chưa đóng; JS thật được chạy thử với ngày 15/11, 16/11, 28/11, 12/12, 13/12 (đúng §5.5: ngày 28/11 thì 15/11, 25/11, 27/11 mờ, 30/11 nổi bật).

## 2 phát hiện lúc code (đã xử lý trong gói, QA lưu ý)

1. **Thiết kế giả định sai đường dẫn bài đích.** Thiết kế ghi bài lịch sale cuối năm ở `lich-sale-cuoi-nam-...html` (gốc) — thực tế file đó KHÔNG có ở gốc repo và live trả **404**; nó nằm ở `bai-viet/lich-sale-cuoi-nam-2026-11-11-12-12-giang-sinh-tet-2027.html` (live **200**). Tương tự `black-friday-2026.html` và `sale.html` ở gốc đều 404 (chỉ có trong sitemap, không có trong repo). Gói đã dùng đúng đường dẫn `bai-viet/...` + anchor thật trong bài (`#nam-moc`, `#black-friday`, `#1212` — đã kiểm chứng tồn tại). **Hệ quả:** sitemap đang liệt kê URL gốc không tồn tại — cần cron bài báo/sitemap rà lại, không thuộc gói này.
2. **`gio-vang-1111.html` CHƯA được chuyển thành trang lịch sale** (vẫn là "Bảng giờ vàng 11.11", 0 lần nhắc "Lịch sale") — đúng như thiết kế dự phòng, gói giữ href bài lịch sale cuối năm, không trỏ trang 11.11 cũ.
3. **Quy tắc mốc khoảng ngày:** JS xét mốc khoảng (Phong Vũ 15–30/11) theo **ngày bắt đầu** — qua ngày bắt đầu thì mờ (`past`), để đúng ví dụ §4.4/§5.5 của thiết kế (ngày 28/11: 30/11 phải là mốc nổi bật). Hệ quả: từ 16–30/11 hàng Phong Vũ mờ dù sale vẫn chạy — thiết kế/QA xem lại nếu muốn đổi sang xét theo ngày kết thúc (khi đó ngày 28/11 hàng 30/11 sẽ không còn là mốc nổi bật duy nhất).

## Chưa làm / chờ QA (18:51) + deploy

- **Chưa kiểm chứng bằng trình duyệt thật** (không có Chromium local trong VM): QA kiểm tra trực quan desktop 1440×900 + mobile 390×844 + <360px (không tràn ngang, chữ không cắt, 2 cột đúng khung `#lo-trinh`), bấm từng hàng tới đúng bài, đổi ngày hệ thống sang 28/11.
- **Chưa deploy.** Deploy (khi được duyệt): 1 commit chỉ `index.html` lên main, kiểm chứng live theo §5 thiết kế rồi mới báo; hoàn tác bằng `git revert`. LƯU Ý: v229 vẫn chưa deploy và gói đã cũ (thiết kế §0) — không gộp v229 vào gói này; nếu deploy v229 sau thì rebase lên nền live mới nhất trước.
- Đo sau deploy: pv trang lịch sale ngày 15/11 ≥30; click `data-track="lich-sale-*"` > 0 trong ngày đầu.

- **Lưu trữ:** gói đầy đủ tại `~/workspace/v274-lich-sale-prep/` (clone live HEAD 4d5cb8d + chỉ `index.html` sửa) và bản sao `index.html` + NOTES tại `hidden_files/v274-lich-sale/`; file zip `~/workspace/v274-lich-sale.zip` chỉ chứa `index.html` + NOTES + test (bản sao lưu, không chứa toàn bộ repo — test phải chạy từ thư mục gốc của gói/clone).
