/* v2 — Mục bình luận GĐ2 (mới, 07/11/2026).
   Dùng chung cho trang chi tiết hồ sơ mẫu (ho-so.html), chi tiết shop
   (chi-tiet-shop.html) và trang bài báo (bai-viet/*.html, tin-tuc.html).
   Bảng `comments` (M6): target_type IN ('model_profile','shop_profile',
   'article'), target_ref = id data.js (th-…/sh-…) hoặc tên file bài báo.
   v92 (08/11/2026): mở rộng thêm 3 loại mục — 'lot' (lô xả kho),
   'factory' (xưởng may), 'kiot' (thanh lý kiot) — cho các thẻ trên
   trang thanh-ly-kiot (kiot) + mục lô/xưởng trên danh-sach-shop (lô/
   xưởng không có trang chi tiết riêng). Cần migration M10 nới CHECK
   target_type của bảng comments (file riêng, CHƯA chạy live) thì 3 loại
   mới mới INSERT được; client đã chấp nhận trước để không chặn UI.
   - v355 (19/11/2026, anh Thọ 13:45): BỎ chờ duyệt — bình luận mới tạo ở
     trạng thái approved (hiện ngay công khai), điểm cộng NGAY ở server
     (submit_comment gọi credit_comment_points sau INSERT, y hệt
     approve_comment trước đây). Client KHÔNG gọi award_interaction_points()
     lúc gửi (điểm do server cộng 1 lần duy nhất).
   - Chỉ hạn chế bằng CHE TỪ KHÓA khi hiển thị (maskSensitive): từ khóa
     nhạy cảm / lừa đảo / chửi bậy / không phù hợp văn hoá thành *** với
     người xem; dữ liệu gốc trong DB không đổi nên admin vẫn đọc đầy đủ
     trong console (js/admin.js chỉ esc(), không che).
   - v95: khách vãng lai bình luận ĐƠN GIẢN — chỉ 1 ô bình luận, không cần
     tên, không luật 20 ký tự (chỉ cần ≥2 ký tự, khớp CHECK của bảng
     comments), ghi chú rõ không cần đăng nhập; tên mặc định "Khách Vãng
     Lai", 0 xu. Người đã đăng nhập giữ form đầy đủ + luật ≥20 ký tự
     để tính xu +1.
   - Client không bao giờ đọc/ghi points_ledger hay wallet_balances.
   RPC/bảng chưa có (M6/M7 chưa chạy) thì form báo lỗi rõ, không vỡ trang. */
(function () {
  'use strict';
  var GUEST_NOTE = 'Đăng ký / đăng nhập tài khoản để bình luận và các hoạt động khác được cộng xu thưởng, đổi quà.';
  // v95: ghi chú cho form khách đơn giản — rõ ràng là KHÔNG cần đăng nhập.
  // GUEST_NOTE cũ giữ lại (đã export) để không vỡ code khác, nhưng form
  // khách không dùng nữa.
  var GUEST_SIMPLE_NOTE = 'Bình luận với tên Khách Vãng Lai — không cần đăng nhập.';
  var LOGGED_IN_NOTE = 'Bình luận từ 20 ký tự được cộng điểm ngay khi đăng (theo luật điểm thưởng). Mỗi tài khoản chỉ được 1 bình luận trong 60 giây (tối đa 30 bình luận trong 5 phút cho cùng 1 mục).'; /* v260 (MC-95): ghi luat chan ngay duoi form — truoc day nguoi dung gui lien tiep moi bi chan (loi tho), khong bao truoc. */
  var VALID_TYPES = ['model_profile', 'shop_profile', 'article', 'lot', 'factory', 'kiot'];
  var COUNT_CACHE_KEY = 'v2s-comment-counts-v1';

  // v118 (09/11/2026, anh giao 22:55) + v355 (19/11/2026, anh Thọ 13:45):
  // ẩn từ khoá nhạy cảm thành *** khi HIỂN THỊ bình luận (và tin chat).
  // Chỉ khớp từ/phrase đứng riêng (có ranh giới từ 2 đầu) để không ẩn
  // nhầm từ lành chứa chuỗi con trùng (vd "các", "đi", "dù", "buổi",
  // "lớn", "cắt") — vì vậy KHÔNG liệt kê các dạng không dấu ngắn dễ nhầm
  // (cac/di/du/buoi/lon/cut). Chỉ giữ dạng có dấu + dạng không dấu dài,
  // không gây nhầm. KHÔNG liệt kê dạng không dấu của cụm mà từ đứng riêng
  // đã là cụm lành (vd 'du ma' = "dư mà", 'an chan' = "ăn chan canh",
  // 'anh nong' = "anh nóng", 'do cho'/'thang cho' = "do/thang cho...",
  // 'con chó' = con chó nhà nuôi) và KHÔNG liệt kê cụm 2 nghĩa trong mua
  // bán ('cọc trước', 'chuyển khoản trước' — shop thu cọc là bình thường).
  // Thêm/bớt từ thì sửa mảng này.
  var SENSITIVE_WORDS = [
    'địt', 'dit', 'đéo', 'deo', 'lồn', 'cặc', 'buồi', 'đĩ', 'cứt', 'đụ',
    'mẹ kiếp', 'khốn nạn', 'chó chết',
    /* v355: chửi bậy thêm */
    'đm', 'địt mẹ', 'dit me', 'đụ má', 'đụ mẹ', 'vãi lồn', 'vai lon',
    'đồ chó', 'thằng chó', 'cút đi', 'cut di', 'bố mày', 'bo may',
    'óc chó', 'oc cho',
    /* v355: lừa đảo */
    'lừa đảo', 'lua dao', 'lừa tiền', 'lua tien', 'lừa gạt', 'lua gat',
    'mạo danh', 'mao danh', 'giả mạo', 'gia mao', 'ăn chặn',
    'chiếm đoạt', 'chiem doat',
    /* v355: nội dung sex / không phù hợp văn hoá */
    'phim sex', 'clip sex', 'ảnh nóng', 'khiêu dâm', 'khieu dam'
  ];
  function escapeRegExp(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  function maskSensitive(text) {
    var out = String(text == null ? '' : text);
    for (var i = 0; i < SENSITIVE_WORDS.length; i++) {
      var w = SENSITIVE_WORDS[i];
      if (!w) continue;
      var re;
      try {
        re = new RegExp('(^|[^\\p{L}\\p{N}])(' + escapeRegExp(w) + ')(?=[^\\p{L}\\p{N}]|$)', 'giu');
      } catch (e) {
        re = new RegExp('(^|[^A-Za-z0-9À-ỹ])(' + escapeRegExp(w) + ')(?=[^A-Za-z0-9À-ỹ]|$)', 'gi');
      }
      out = out.replace(re, function (m, pre) { return pre + '***'; });
    }
    return out;
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function api() { return (typeof window !== 'undefined' && window.McLivestreamAPI) ? window.McLivestreamAPI : null; }
  function reward() { return (typeof window !== 'undefined' && window.Ver2Reward) ? window.Ver2Reward : null; }
  // v166 (C1/N1): đọc session qua V2SAuthUI (1 nguồn đúng duy nhất) khi
  // có — tránh trường hợp UI hiện tài khoản A (cache) nhưng bình luận
  // gửi dưới tài khoản B (đọc trực tiếp qua API). Không có auth-ui thì
  // vẫn đọc trực tiếp như cũ.
  async function currentUser() {
    try {
      var A = (typeof window !== 'undefined') ? window.V2SAuthUI : null;
      if (A && typeof A.getSession === 'function') {
        var s2 = await A.getSession();
        if (s2 && s2.user) return s2.user;
      }
    } catch (e) { /* rơi về đọc trực tiếp bên dưới */ }
    var a = api();
    if (!a || typeof a.getSession !== 'function') return null;
    try {
      var s = await a.getSession();
      return (s && s.user) ? s.user : null;
    } catch (e) { return null; }
  }
  // v297 (MC-99, P1 — rò email, 16/11/2026): tên hiển thị của tài khoản
  // KHÔNG BAO GIỜ lấy từ email. Thứ tự: user_metadata.display_name /
  // full_name / name → profiles.full_name (cùng nguồn header dùng, qua
  // McLivestreamAPI.fetchMyProfile) → '' (để trống, form hiện placeholder
  // "Khách Vãng Lai"). Email chỉ dùng để đăng nhập, không phải tên công khai.
  async function resolveDisplayName(user) {
    if (!user) return '';
    var md = user.user_metadata || {};
    var n = md.display_name || md.full_name || md.name || '';
    if (typeof n === 'string' && n.trim()) return n.trim();
    try {
      var M = api();
      if (M && typeof M.fetchMyProfile === 'function') {
        var p = await M.fetchMyProfile();
        if (p && p.full_name && String(p.full_name).trim()) return String(p.full_name).trim();
      }
    } catch (e) { /* bỏ qua — rơi xuống '' */ }
    return '';
  }
  // Tên người dùng tự gõ (hoặc metadata lạ) mà chứa '@' thì coi như email
  // → bỏ, để chuỗi fallback quyết định (tên hồ sơ hoặc "Khách Vãng Lai").
  function sanitizeDisplayName(name) {
    var s = String(name || '').trim();
    if (!s || s.indexOf('@') !== -1) return '';
    return s;
  }
  function loginHref() {
    try {
      var p = String(location.pathname || '');
      var next = p.split('/').pop() || 'index.html';
      return 'dang-nhap.html?next=' + encodeURIComponent(next);
    } catch (e) { return 'dang-nhap.html'; }
  }

  // Đọc các bình luận ĐÃ DUYỆT, chưa bị xóa mềm, mới nhất trước.
  async function loadComments(targetType, targetRef) {
    var a = api();
    if (!a || !a.client) throw new Error('Chưa kết nối được Supabase, hãy thử lại sau.');
    var res = await a.client.from('comments').select('id,commenter_name,comment,created_at')
      .eq('target_type', targetType).eq('target_ref', String(targetRef))
      .eq('moderation_status', 'approved').is('deleted_at', null)
      .order('created_at', { ascending: false }).limit(50);
    if (res.error) throw res.error;
    return res.data || [];
  }
  function commentsListHTML(list) {
    if (!list || !list.length) return '<p class="v2s-comments-empty">Chưa có bình luận nào.</p>';
    return '<ul class="v2s-comments-list">' + list.map(function (c) {
      var when = '';
      try { when = c.created_at ? new Date(c.created_at).toLocaleDateString('vi-VN') : ''; } catch (e) {}
      /* v353 (19/11/2026, M-02 lịch sử tương tác): neo id cho từng bình luận
         để link lịch sử (#comment-<id>) cuộn đúng vị trí. */
      return '<li' + (c.id ? ' id="comment-' + c.id + '"' : '') + '><b>' + esc(c.commenter_name || 'Khách Vãng Lai') + '</b>'
        + (when ? ' <span class="v2s-comments-date">' + esc(when) + '</span>' : '')
        + '<p>' + esc(maskSensitive(c.comment)) + '</p></li>';
    }).join('') + '</ul>';
  }

  // Gửi 1 bình luận: gọi RPC submit_comment (SECURITY DEFINER, bypass RLS
  // — sửa NEW-01: INSERT trực tiếp bị RLS chặn 42501). Validate: đã đăng
  /* v260 (MC-95): cooldown phia client — 1 binh luan/60 giay/tai khoan
     (luat cong bo o quy-tac-diem-thuong.html). Ghi thoi diem gui THANH CONG
     gan nhat theo uid; gui lai trong 60s thi bao than thien kem so giay con
     lai, KHONG goi RPC. Chi ap cho tai khoan dang nhap (luat noi "moi tai
     khoan"); khach vang lai RPC tu xu ly. */
  var COMMENT_COOLDOWN_MS = 60000;
  function commentCooldownKey(uid){ return 'v2s_comment_last_' + String(uid || ''); }
  function commentCooldownLeftMs(uid){
    if(!uid || typeof localStorage === 'undefined') return 0;
    try{ var t = parseInt(localStorage.getItem(commentCooldownKey(uid)) || '0', 10); if(!t) return 0; return Math.max(0, COMMENT_COOLDOWN_MS - (Date.now() - t)); }catch(e){ return 0; }
  }
  function commentCooldownMark(uid){
    if(!uid || typeof localStorage === 'undefined') return;
    try{ localStorage.setItem(commentCooldownKey(uid), String(Date.now())); }catch(e){}
  }
  /* v260 (MC-95): dich loi chan spam cua RPC sang cau than thien — loi goc
     la ma/thong bao ky thuat cua server (vd M7.9b). */
  function friendlyCommentError(err){
    var m = String((err && err.message) || err || '');
    if (/rate|429|too many|quá nhanh|chờ|giây|second|spam|M7\.9b/i.test(m)) return 'Bạn gửi bình luận quá nhanh — mỗi tài khoản chỉ được 1 bình luận trong 60 giây, vui lòng đợi một lát rồi gửi lại nhé.';
    return 'Chưa gửi được bình luận: ' + m;
  }

  // nhập → ≥20 ký tự (validateComment của js/reward.js, để tính xu);
  // khách vãng lai → chỉ cần viết gì đó (≥2 ký tự, v95 — khớp CHECK của
  // bảng comments; chặn link + chống spam do RPC lo).
  // Trả {ok, points, message} — KHÔNG ném lỗi.
  // v355 (19/11/2026): KHONG cong xu o client — diem do server cong ngay
  // trong submit_comment (credit_comment_points sau INSERT, 1 lan duy
  // nhat nho khoa idempotency). points luon 0 o day.
  async function submitComment(targetType, targetRef, text, displayName) {
    if (VALID_TYPES.indexOf(targetType) === -1) return { ok: false, points: 0, message: 'Loại mục bình luận không hợp lệ.' };
    if (!targetRef) return { ok: false, points: 0, message: 'Thiếu mục bình luận.' };
    var a = api();
    if (!a || !a.client) return { ok: false, points: 0, message: 'Chưa kết nối được Supabase, hãy thử lại sau.' };
    var user = await currentUser();
    var R = reward();
    if (user) {
      var err = R && typeof R.validateComment === 'function' ? R.validateComment(text) : null;
      if (err) return { ok: false, points: 0, message: err };
    } else if (String(text || '').trim().length < 2) {
      return { ok: false, points: 0, message: 'Hãy viết nội dung bình luận.' };
    }
    // v297 (MC-99): tên hiển thị KHÔNG BAO GIỜ lấy từ email — ô tên đã
    // sanitize (chặn '@') → tên metadata/hồ sơ → "Khách Vãng Lai".
    var name = sanitizeDisplayName(displayName)
      || await resolveDisplayName(user) || 'Khách Vãng Lai';
    if (user) {
      var leftMs = commentCooldownLeftMs(user.id);
      if (leftMs > 0) return { ok: false, points: 0, message: 'Bạn vừa gửi bình luận, vui lòng đợi ' + Math.ceil(leftMs / 1000) + ' giây nữa rồi gửi tiếp nhé (mỗi tài khoản chỉ được 1 bình luận trong 60 giây).' };
    }
    // NEW-01 (08/11): INSERT trực tiếp bị RLS chặn (42501) dù policy cho
    // phép — gửi bình luận qua RPC SECURITY DEFINER submit_comment() thay
    // cho INSERT trực tiếp. RPC tự validate + chống spam (luật M7.9b);
    // v355 (19/11): bình luận tạo ở trạng thái approved (hiện ngay, không
    // chờ duyệt) và điểm cộng ngay ở server.
    // p_auth_user_id: uid của tài khoản đang đăng nhập, null khi khách vãng lai.
    try {
      var res = await a.client.rpc('submit_comment', {
        p_target_type: targetType, p_target_ref: String(targetRef),
        p_comment: String(text).trim(), p_commenter_name: name.slice(0, 100),
        p_auth_user_id: user ? user.id : null
      });
      if (res.error) return { ok: false, points: 0, message: friendlyCommentError(res.error) };
    } catch (e) {
      return { ok: false, points: 0, message: friendlyCommentError(e) };
    }
    if (user) commentCooldownMark(user.id);
    // v355 (19/11/2026): bình luận đã hiện ngay + điểm (nếu đủ điều kiện)
    // đã cộng ở server. KHÔNG gọi awardInteraction ở đây.
    return { ok: true, points: 0, message: user ? 'Bình luận đã đăng. Bình luận từ 20 ký tự được cộng điểm ngay theo luật điểm thưởng.' : 'Bình luận đã đăng.' };
  }

  // Vẽ mục bình luận (form + danh sách) vào 1 phần tử. container: element
  // hoặc id. Trả promise (xong khi đã tải danh sách, lỗi tải thì vẫn hiện form).
  async function renderComments(targetType, targetRef, container) {
    var el = typeof container === 'string' ? document.getElementById(container) : container;
    if (!el) return false;
    var user = await currentUser();
    // v95: khách vãng lai thấy form ĐƠN GIẢN — chỉ 1 ô bình luận, không ô
    // tên, không minlength, ghi chú rõ không cần đăng nhập. Người đã đăng
    // nhập giữ form đầy đủ (ô tên + minlength=20 để tính xu).
    var note, formHTML;
    if (user) {
      note = '<p class="v2s-note">' + esc(LOGGED_IN_NOTE) + '</p>';
      // v244 (MB-15): điền sẵn tên hiển thị của tài khoản đang đăng nhập.
      // v297 (MC-99): KHÔNG dùng email nữa — metadata → profiles.full_name
      // (resolveDisplayName, cùng nguồn header dùng); không có tên thì để
      // trống, form hiện placeholder "Khách Vãng Lai".
      var displayName = await resolveDisplayName(user);
      formHTML = '<form class="v2s-comment-form"><label>Tên hiển thị<input name="v2sName" maxlength="100" placeholder="Khách Vãng Lai" value="' + esc(displayName) + '"></label>'
        + '<label>Bình luận *<textarea name="v2sText" rows="3" required minlength="20" placeholder="Viết bình luận từ 20 ký tự trở lên…"></textarea></label>'
        + '<p class="v2s-comment-msg" role="status"></p>'
        + '<button class="btn btn-primary btn-sm" type="submit">Gửi bình luận</button></form>';
    } else {
      note = '<p class="v2s-note">' + esc(GUEST_SIMPLE_NOTE) + '</p>';
      formHTML = '<form class="v2s-comment-form">'
        + '<label>Bình luận *<textarea name="v2sText" rows="3" required placeholder="Viết bình luận…"></textarea></label>'
        + '<p class="v2s-comment-msg" role="status"></p>'
        + '<button class="btn btn-primary btn-sm" type="submit">Gửi bình luận</button></form>';
    }
    el.innerHTML = '<section class="v2s-comments"><h2>Bình luận</h2>' + note + formHTML
      + '<div class="v2s-comments-list-wrap"><p>Đang tải bình luận…</p></div></section>';
    var form = el.querySelector('.v2s-comment-form');
    var msgEl = el.querySelector('.v2s-comment-msg');
    var listWrap = el.querySelector('.v2s-comments-list-wrap');
    async function refreshList() {
      try { listWrap.innerHTML = commentsListHTML(await loadComments(targetType, targetRef)); }
      catch (e) { listWrap.innerHTML = '<p class="v2s-comments-empty">Chưa tải được bình luận (hệ thống bình luận chưa bật).</p>'; }
    }
    form.addEventListener('submit', async function (e) {
      e.preventDefault();
      var btn = form.querySelector('button[type="submit"]');
      if (btn) btn.disabled = true;
      var text = form.v2sText.value;
      var name = form.v2sName ? form.v2sName.value : ''; // form khách v95 không có ô tên
      var out = await submitComment(targetType, targetRef, text, name);
      if (msgEl) msgEl.textContent = out.message;
      if (out.ok) { form.v2sText.value = ''; }
      if (btn) btn.disabled = false;
    });
    await refreshList();
    return true;
  }

  // ---- v92 (C2): bình luận dưới mỗi thẻ lô/xưởng/kiot ----
  // Số bình luận ĐÃ DUYỆT theo từng mục (target_type:target_ref), đếm bằng
  // 1 query duy nhất cho cả 3 loại mới, cache theo phiên (sessionStorage)
  // để không truy vấn lại khi cuộn/lọc render lại thẻ. Lỗi mạng → {} (nút
  // vẫn hiện "Bình luận" không số, bấm vẫn mở form bình thường).
  function readCountCache() {
    try {
      if (typeof sessionStorage === 'undefined') return null;
      var raw = sessionStorage.getItem(COUNT_CACHE_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function writeCountCache(counts) {
    try {
      if (typeof sessionStorage === 'undefined') return;
      sessionStorage.setItem(COUNT_CACHE_KEY, JSON.stringify({ at: Date.now(), counts: counts || {} }));
    } catch (e) { /* bỏ qua — lần sau đếm lại */ }
  }
  async function getCommentCounts(types) {
    var wanted = (types && types.length ? types : ['lot', 'factory', 'kiot']);
    var cached = readCountCache();
    if (cached && cached.counts) return cached.counts;
    var a = api();
    if (!a || !a.client) return {};
    try {
      var res = await a.client.from('comments').select('target_type,target_ref')
        .in('target_type', wanted).eq('moderation_status', 'approved').is('deleted_at', null).limit(1000);
      if (res.error) return {};
      var counts = {};
      (res.data || []).forEach(function (row) {
        var k = String(row.target_type) + ':' + String(row.target_ref);
        counts[k] = (counts[k] || 0) + 1;
      });
      writeCountCache(counts);
      return counts;
    } catch (e) { return {}; }
  }
  // Cập nhật nhãn "Bình luận (N)" cho mọi nút toggle trong root (mặc định
  // document). Nút nào chưa có số thì giữ nhãn "Bình luận".
  function countLabel(n) { return n > 0 ? '💬 Bình luận (' + n + ')' : '💬 Bình luận'; }
  async function refreshCommentCounts(root) {
    var doc = root || (typeof document !== 'undefined' ? document : null);
    if (!doc || typeof doc.querySelectorAll !== 'function') return {};
    var counts = await getCommentCounts();
    var btns = doc.querySelectorAll('[data-v2s-comment-toggle]');
    for (var i = 0; i < btns.length; i++) {
      var b = btns[i];
      if (b.getAttribute('data-v2s-comments-open') === '1') continue; // đang mở: giữ nhãn "Đóng bình luận"
      var k = b.getAttribute('data-v2s-target-type') + ':' + b.getAttribute('data-v2s-target-id');
      var n = counts[k] || 0;
      b.setAttribute('data-v2s-comments-count', String(n)); // để đóng/mở lại vẫn giữ số
      b.textContent = countLabel(n);
    }
    return counts;
  }
  // Gắn 1 lần listener ủy quyền cho nút toggle bình luận dưới thẻ lô/xưởng/
  // kiot (gọi từ js/app.js initPointsUI sau khi trang render xong). Bấm lần
  // đầu: mở khung + renderComments (lazy-load); bấm lại: đóng/mở, không tải
  // lại. 2 thẻ khác nhau không lẫn nhau (mỗi khung gắn đúng target_ref).
  var cardCommentsWired = false;
  function initCardComments(root) {
    var doc = root || (typeof document !== 'undefined' ? document : null);
    if (!doc || cardCommentsWired) return false;
    if (typeof doc.addEventListener !== 'function') return false;
    cardCommentsWired = true;
    doc.addEventListener('click', function (e) {
      var btn = e.target && e.target.closest ? e.target.closest('[data-v2s-comment-toggle]') : null;
      if (!btn) return;
      e.preventDefault();
      // v166 (N11): nút Bình luận trong dialog lô/xưởng/kiot không nằm
      // trong thẻ <article> (dialog là .detail-box) nên closest('article')
      // trả null và nút chết lặng — trước đây chỉ tìm mount trong thẻ.
      // Tìm lần lượt: thẻ chứa nút → hộp dialog → toàn document (theo
      // đúng target type:id). Thứ tự này tránh nhầm mount của thẻ cùng
      // id đang nằm sau dialog.
      var sel = '[data-v2s-comments-for="' + btn.getAttribute('data-v2s-target-type') + ':' + btn.getAttribute('data-v2s-target-id') + '"]';
      var mount = null;
      var card = btn.closest ? btn.closest('article') : null;
      if (card && typeof card.querySelector === 'function') mount = card.querySelector(sel);
      if (!mount) {
        var box = btn.closest ? btn.closest('.detail-box') : null;
        if (box && typeof box.querySelector === 'function') mount = box.querySelector(sel);
      }
      if (!mount && doc && typeof doc.querySelector === 'function') mount = doc.querySelector(sel);
      if (!mount) return;
      var open = btn.getAttribute('data-v2s-comments-open') === '1';
      if (open) {
        mount.hidden = true;
        btn.setAttribute('data-v2s-comments-open', '0');
        btn.textContent = countLabel(Number(btn.getAttribute('data-v2s-comments-count') || 0));
        return;
      }
      mount.hidden = false;
      btn.setAttribute('data-v2s-comments-open', '1');
      btn.textContent = '💬 Đóng bình luận';
      if (mount.getAttribute('data-v2s-loaded') !== '1') {
        mount.setAttribute('data-v2s-loaded', '1');
        renderComments(btn.getAttribute('data-v2s-target-type'), btn.getAttribute('data-v2s-target-id'), mount);
      }
    });
    refreshCommentCounts(doc);
    return true;
  }

  var API = {
    GUEST_NOTE: GUEST_NOTE, GUEST_SIMPLE_NOTE: GUEST_SIMPLE_NOTE, LOGGED_IN_NOTE: LOGGED_IN_NOTE,
    loadComments: loadComments, submitComment: submitComment,
    renderComments: renderComments, commentsListHTML: commentsListHTML,
    getCommentCounts: getCommentCounts, refreshCommentCounts: refreshCommentCounts,
    initCardComments: initCardComments, VALID_TYPES: VALID_TYPES,
    maskSensitive: maskSensitive, SENSITIVE_WORDS: SENSITIVE_WORDS
  };
  if (typeof window !== 'undefined') window.Ver2Comments = API;
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
})();
